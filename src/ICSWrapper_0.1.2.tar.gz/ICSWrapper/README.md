# Mouse microglia regional heterogeneity in single cell resolution



### Installation

1. Donwload and unzip the latest tar file which you can find in tags-releases.

2. library(devtools)

3. install.deps("path_of_the_unzip_package")
(It takes time. I should check again If i am installing something that does not need.)

4. install.packages("ICSWrapper_0.1.???.tar.gz",type="source")

it should work.


#### R session information

For requirements, please see the file RNA-seq_sessionInfo.txt for specific R packages and their versions.

#### Preprocessing
....

#### Figures

We additionally provide scripts to reproduce most of the main figures.
The R code can be found in the figure_src directory and is split into individual files.

### Citation

Please refer to the following research article when using data from this repository:

...

## Overview


