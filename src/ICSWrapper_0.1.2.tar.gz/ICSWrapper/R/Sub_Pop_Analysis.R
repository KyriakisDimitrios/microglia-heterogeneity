#' Subsetting  Object
#' @author Dimitrios Kyriakis
#'
#' @param object : CellDataSet class from Monocle.
#' @param Conditions : Vector with the Conditions to keep.
#' @param Clusters : Vector with the Clusters to keep.
#' @param Cell_Types : Vector with the Cell_Types to keep.
#' @param tool : Monocle/Seurat
#' @export
#'
#' @return A subset of the Monocle Object.
#' @examples
#' object_subset(object,Conditions,Clusters,tool="monocle")
object_subset <- function(object,Conditions=NULL,Clusters=NULL,Cell_Types=NULL,re_project=TRUE){
    tool <- object_identifier(object)
    if(is.null(Conditions)){
        Conditions <- as.vector(unique(object$condition))
    }
    if(is.null(Clusters)){
        Clusters <- as.vector(unique(object$Cluster))
    }
    if(is.null(Cell_Types)){
        Cell_Types <- as.vector(unique(object$Cell_Type))
    }

    if(tolower(tool)=="monocle"){
        indexes <- object$Cluster%in%Clusters & object$condition%in%Conditions & object$Cell_Type%in%Cell_Types
        sub_CellType <- object[,indexes]
        print(dim(sub_CellType))
        sub_CellType@reducedDimA <- sub_CellType@reducedDimA[,indexes]
        # Re-factor the conditions
        sub_CellType$condition <- factor(sub_CellType$condition)
        sub_CellType$Cluster <- factor(sub_CellType$Cluster)
        sub_CellType$Cell_Type <- factor(sub_CellType$Cell_Type)
    }else{
        # if(!is.null(Conditions)){
        #     Idents(object) <- object[["condition"]]
        #     sub_CellType <- SubsetData(object = object, ident.use = Conditions)
        # }else{
        #     sub_CellType <- object
        # }
        # if(!is.null(Clusters)){
        #     Idents(sub_CellType) <- sub_CellType[["Cluster"]]
        #     sub_CellType <- SubsetData(object = sub_CellType, ident.use = Clusters)
        # }
        # if(!is.null(Cell_Types)){
            # Idents(object) <- object[["Cell_Type"]]
            # sub_CellType <- SubsetData(object = object, ident.use = Cell_Types)
        # }
        cells_index <- object$Cell_Type%in%Cell_Types & object$condition%in%Conditions &  object$Cluster%in%Clusters
        sub_CellType<- subset(x=object,cells=colnames(object)[cells_index])
    }
    # ============== Re_Project ==================
    if(re_project){
      sub_CellType <- reduce_dim(sub_CellType,project=project)$Combined
    }
    # --------------------------------------------
  return(sub_CellType)
}

