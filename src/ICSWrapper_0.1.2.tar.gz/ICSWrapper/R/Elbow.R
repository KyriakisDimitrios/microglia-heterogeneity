#' Elbow Calculation
#' @author Dimitrios Kyriakis
#'
#' @param object: Gene expression matrix.
#' @param condition_names: Condition names.
#' @param iter_qc: Iteration.
#'
#' @return Gene expression Matrix
#' @examples elbow_calc(object,condition_names,iter_qc)
elbow_calc <- function(object,condition_names,iter_qc){
    require(ecp)
    #====================== ELBOW ==========================================
    pdf(paste(Sys.Date(),"QC_Kneeplot_Zeros",condition_names[iter_qc],".pdf",sep="_"))
    # Knee plot
    knee_data <- object
    # plot(colSums(is.na(knee_data)),main="Number of missing genes per cell",ylab="Number of missing genes",xlab="Cells")
    knee_data[is.na(knee_data)] <- 0
    plot(colSums(knee_data == 0),main=condition_names[iter_qc],ylab="Number of non expressed genes",xlab="Cells")
    # print("No memory error")
    # ============== Elbow Analysis ============= #
    
    y<- cumsum(sort(colSums(knee_data),TRUE))
    x<-c(1:length(y))
    y1<- as.matrix(y)
    y2<- as.matrix(y[500:length(y)])
    
    real_index <- e.divisive(diff(y1),k=1,min.size=2)
    real_index <- real_index$considered.last
    print(paste("The real elbow value is ",real_index))
    
    # pdf("knee.pdf")
    plot(x, y, pch=19,xlab="Cells",ylab="Cumulative Total mRNA")
    if (real_index<500){
      y2<- as.matrix(y[real_index:length(y)])
      indicies <- e.divisive(diff(y2),k=1,min.size=2)$considered.last +500
      print(paste("The elbow value adjusted to be between 500 and 1000. The new value is ",indicies))
      points(x[indicies], y[indicies], pch=19, col='red')
    }else{
      indicies <- real_index
    }
    
    points(x[real_index], y[real_index], pch=19, col='lightblue')
    abline(v=500,col="red")
    abline(v=1000,col="red")
    # dev.off()
    if(indicies>1000& real_index<1000){
      object<- object[,1:700]
    }else{
      object<- object[,1:indicies]
    }
    
    # ---------------------------------------------
    dev.off()
    return(object)
}

