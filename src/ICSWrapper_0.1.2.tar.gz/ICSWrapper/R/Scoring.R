#' cell_type_assignment.
#' @export
#' @param object: object class from Monocle/Seurat.
#' @param tab_name: The name of the Tab in the object to store the assignment
#' @param file: .file path with the markers
#'
#' @return Gene expression Matrix without Outliers
#' @examples
#' cell_type_assignment(object,tab_name,file)
cell_type_assignment <- function(object,tab_name,file,assign=TRUE){
    tool <- object_identifier(object)
    if(tolower(tool)=="monocle"){
        GE_matrix <- data.matrix(object, rownames.force = NA)
        Normilize_Vector <- pData(object)[, 'Size_Factor']
        count_matrix <- as.matrix(sweep(GE_matrix,2,Normilize_Vector,"/"))
    }else{
        count_matrix <- as.matrix(object@assays$RNA@data)
    }
    astro <-as.matrix(read.delim2(file,header=F))
    r_annot <- astro[,1]
    gene_list <- toupper(astro[,2])
    cell_type_list <- list()

    df_cell_type = data.frame(matrix(vector(), dim(object)[2]))

    for (cell_type in unique(r_annot)){
        print(cell_type)
        cell_type_list<- list(c(gene_list[grep(cell_type,r_annot)]))
        indexes <- cell_type_list[[1]]%in% rownames(object)
        gene_list_s <- cell_type_list[[1]][indexes]
        ctls <- length(cell_type_list[[1]])

        if(length(gene_list_s)==0){
            cat(yellow("Warning :")  %+% "This Cell Type skipped due to no genes found\n")
        }else if(length(gene_list_s)==1){
            df_cell_type[[cell_type]] <- as.vector((count_matrix[gene_list_s,]))
        }else{
            df_cell_type[[cell_type]] <- as.vector(colSums(count_matrix[gene_list_s,]))/length(gene_list_s)
        }

        if(length(gene_list_s)!=0){
            a <- 1:length(gene_list_s)
            n <- length(a)
            k <- 4
            splited_l <- split(a, rep(1:ceiling(n/k), each=k)[1:n])

            print_fun<-function(x) {
                if(tolower(tool)=="monocle"){
                    plot(plot_cell_clusters(object, x = 1, y = 2, markers = gene_list_s[x]))
                }else{
                    print(FeaturePlot(object = object, features = gene_list_s[x],reduction = "tsne"))
                }

            }

            pdf(paste(Sys.Date(),"Scat",project,cell_type,"tsne.pdf",sep="_"))
            lapply(splited_l,print_fun)
            dev.off()

            # print_fun<-function(x) {
            #     if(tolower(tool)=="monocle"){
            #         plot_cell_clusters(object, x = 1, y = 2, markers = gene_list_s[x])
            #     }else{
            #         print(FeaturePlot(object = object, features = gene_list_s[x],reduction = "tsne"))
            #     }
            #   print(FeaturePlot(object = object, features = gene_list_s[x]))
            # }

            # pdf(paste(Sys.Date(),"Scat",project,cell_type,"umap.pdf",sep="_"))
            # lapply(splited_l,print_fun)
            # dev.off()
        }

    }

    cell_type_vector<-as.vector(object$Cluster)
    df_cl_cell_type = data.frame(matrix(vector(),nrow = dim(df_cell_type)[2]))
    rownames(df_cl_cell_type)<- colnames(df_cell_type)
    max_num_cell_type <- list()
    for (cl in levels(object$Cluster)){
        Cluster_score <- colSums(df_cell_type[object$Cluster==cl,])
        cl_cell_type <- colnames(df_cell_type)[which.max(Cluster_score)]

        max_num <- Cluster_score[which.max(Cluster_score)]
        name_cell <- names(max_num)
        if(name_cell%in%names(max_num_cell_type)){
          if(max_num>=max_num_cell_type[name_cell]){
            max_num_cell_type[name_cell] <- max_num
            cell_type_vector[object$Cluster==cl] <- cl_cell_type
          }else{
            cell_type_vector[object$Cluster==cl] <- "Hybrid"
          }
        }else{
          max_num_cell_type[name_cell] <- max_num
          cell_type_vector[object$Cluster==cl] <- cl_cell_type
        }

        # print(cl_cell_type)
        #
        #
        # print("ok")
        df_cl_cell_type[,cl] <- c(Cluster_score)
    }

    if (assign){
        object[[tab_name]] <- cell_type_vector

        # pdf(paste(Sys.Date(),"_TSNE_",project,"_",tab_name,".pdf",sep=""))
        plot_cells(object,target=tab_name,reduction="tsne",leg_pos="right",save=TRUE,ncol=1)
        # dev.off()

        # pdf(paste(Sys.Date(),"_UMAP_",project,"_",tab_name,".pdf",sep=""))
        # Idents(object) <- object[[tab_name]]
        # plot(DimPlot(object,reduction = "umap",cols =color_cells))
        # dev.off()


        annotated_heat(object=object,
                     row_annotation=as.vector(r_annot),
                     gene_list=gene_list,
                     gene_list_name="Markers",
                     title="Cell Type Markers",
                     ordering="Cluster")
    }

    return(list("object"=object,"r_annot"=r_annot))
}

#' garnett_assignment
#' @export
garnett_assignment <- function(object ,organism="mouse",check_markers=FALSE){
    tool <- object_identifier(object)
    if(tool=="seurat"){
        pbmc_cds <- seurat_to_monocle(object)
    }else{
        pbmc_cds <- object
    }
    organism <- tolower(organism)

    if(organism=="human"){
        library(org.Hs.eg.db)
        db=org.Hs.eg.db
    }else if (organism =="mouse"){
        library(org.Mm.eg.db)
        marker_file_path <- "C:/Users/dimitrios.kyriakis/Desktop/PhD/Scripts/ICSWrapper/markers_test1.txt"
        marker_file_path <- "C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/Gene_Lists/markers_test_garnnett.txt"
        db=org.Mm.eg.db
    }else if(organism=="rat"){
        library(org.Rn.eg.db)
        marker_file_path <- "C:/Users/dimitrios.kyriakis/Desktop/PhD/Scripts/ICSWrapper/markers_test1.txt"
        db=org.Rn.eg.db
    }else{
        marker_file_path <- "C:/Users/dimitrios.kyriakis/Desktop/PhD/Scripts/ICSWrapper/markers_test1.txt"
        db="none"
    }


    row_names <- rownames(pbmc_cds)
    rownames(pbmc_cds) = unlist(lapply(tolower(as.vector(row_names)),simpleCap))
    if(organism=="human"){
        row_names <- rownames(pbmc_cds)
        rownames(pbmc_cds) = toupper(as.vector(row_names))
    }else{
        row_names <- rownames(pbmc_cds)
        rownames(pbmc_cds) = unlist(lapply(tolower(as.vector(row_names)),simpleCap))
    }

    if(check_markers){
        marker_check <- check_markers(pbmc_cds,marker_file_path ,
                                  db=db,
                                  cds_gene_id_type = "SYMBOL",
                                  marker_file_gene_id_type = "SYMBOL")
        pdf("Checking_Markers.pdf")
        print(plot_markers(marker_check))
        dev.off()
    }

    pbmc_classifier <- train_cell_classifier(cds = pbmc_cds,
                                             marker_file = marker_file_path,
                                             db=db,
                                             cds_gene_id_type = "SYMBOL",
                                             num_unknown = 50,
                                             marker_file_gene_id_type = "SYMBOL")

    pbmc_cds <- classify_cells(pbmc_cds, pbmc_classifier,
                               db = db,
                               cluster_extend = TRUE,
                               cds_gene_id_type = "SYMBOL")

    object$cell_type <- pbmc_cds$cell_type
    object$cluster_ext_type <- pbmc_cds$cluster_ext_type
    object$garnett_cluster <- pbmc_cds$garnett_cluster
    return(object)
}
