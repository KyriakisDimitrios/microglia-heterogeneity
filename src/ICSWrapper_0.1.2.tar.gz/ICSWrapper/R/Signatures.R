#' Differential expression analysis between Conditions and Clusters.
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param CDSC : CellDataSet class from Monocle.
#' @param target : Target for the differential expression Cluster/Condition/State.
#' @param colorby : Colored by Cluster/Condition/State.
#' @param scale : Scale the values zscore/minmax (Default=zscore).
#' @param alter : Alternative Color to the heatmap.
#' @param qval_thres : Q-value Threshold.
#' @param n_cores : Number of cores (Cores=1 for Windows OS).
#'
#' @return Differential expression Genes
#' @return Matrix used for Heatmap
#' @examples
#' df_ses(CDSC, target="Conditions", colorby="Cluster",scale="zscore",qval_thres=0.01,n_cores=4)
df_ses <- function(CDSC, target="Conditions", colorby="Cluster",scale="zscore",qval_thres=0.01,n_cores=4,tool="seurat"){
  cat(paste(cyan("Differential Expression Analysis Using SES: ") ,"Started at",as.character(Sys.time())))
  tic()
  target_name <- target
  Conditions<-CDSC$condition
  Clusters <- CDSC$Cluster
  library(MXM)

  # == Scaled Data
  if(tool=="monocle"){
    GE_matrix<- data.matrix(CDSC, rownames.force = NA)
    Normilize_Vector <- pData(CDSC)[, 'Size_Factor']
    Norm1 <- as.matrix(sweep(GE_matrix,2,Normilize_Vector,"/"))

    # ======== Scale
    print(paste("Scale",scale))
    if (scale=="minmax"){
      test0 <- t(apply(Norm1, 1, function(x)(x-min(x))/(max(x)-min(x))))
    } else{
      test0<- t(scale (t(Norm1),center = TRUE, scale = TRUE))
    }
    test0[is.na(test0)]<- 0
  }else{

  }
  target <- as.factor(CDSC[[target]])

  # ======= Classification
  ses_res <- SES(target,as.matrix(t(test0)),max_k=3,threshold=qval_thres,ncores=n_cores)
  Sign <- ses_res@signatures
  if(length(Sign)==0){print("No DF gene found");return(Sign)}
  print(Sign)
  All_vars <- unique(c(Sign))

  # Find gene names
  Index_genes <- factor(fData(CDSC)$gene_short_name[as.vector(All_vars)])
  Top_DF_Cond <- test0[as.vector(All_vars),]
  rownames(Top_DF_Cond)<-Index_genes
  print("OK")
  # ========== Heatmap Ordered by Conditions
  # Order the GEM based on conditons and the clusters
  if (target_name=="condition"){
    ordering  <- order(Conditions,Clusters)
    Condi <- Conditions[ordering]
    clusts    <- Clusters[ordering]
    annotation = data.frame(Condition = Condi, Cluster = clusts)
  } else if (target_name=="Cluster"){
    ordering  <- order(Clusters,Conditions)
    Condi <- Conditions[ordering]
    clusts <- Clusters[ordering]
    annotation = data.frame(Cluster = clusts,Condition = Condi)
  } else{
    my_target <- CDSC$Conditions
    ordering  <- order(my_target,CDSC$Cluster)
    Targets <- my_target[ordering]
    Condi <- CDSC$condition[ordering]
    clusts <- CDSC$Cluster[ordering]
    annotation = data.frame(Target=Targets,Cluster = clusts,Condition = Condi)
  }

  # ================ Plots
  # Heatmap
  aheatmap(as.matrix(Top_DF_Cond)[,ordering], annCol = annotation,
           color=jcolors(palette = "pal12"), Colv = NA,
           main="Differential expression between Conditions",
           filename=paste("SES_",target_name,"_Heat_DEG_.pdf",sep=""))
  print("OK2")
  # Jitter
  Cond_DEG_FC <- CDSC[fData(CDSC)$gene_short_name %in% rownames(Top_DF_Cond),]
  pdf(paste('SES_',target_name,'_DEG_genes_jitter.pdf',sep=""),height=12, width=24)
  plot_genes_jitter(Cond_DEG_FC, grouping=target, ncol=4,color_by=colorby,plot_trend=TRUE)
  dev.off()
  print("OK3")
  # Plot scatter plot for every deg gene
  plot_scatter(CDSC, Top_DF_Cond,title=paste("SES_Scat_DEG_",target_name,sep=""))
  # ----------------------
  cat(cyan("Finished") %+% as.character(Sys.time()))
  return(list("DF_Genes" = Index_genes,"Matrix"=Cond_DEG_FC))
}



#' Orthogonal Matching Persuit (OMP)
#'
#' @author Dimitrios Kyriakis
#' @export
#' @param X : Gene expression Matrix
#' @param target : Dependent Variable
#' @param batch_effect : The formula of the batch effects
#' @param converter : Monocle remove Batch or Log10 Counts (Default Monocle)
#' @param BIC_thres : Terminate OMP BIC threshold
#'
#' @return Returns the selected variables
#' @examples omp_glmm(X,target,batch_effect,converter="pca_like",BIC_thres=1)
#'
omp_glmm<-function(X,target,batch_effect,converter="pca_like",BIC_thres=1,quasi=FALSE){
  target=target

  if(converter=="pca_like"){
    # =============================== LM ==================================
    cat(paste(cyan("\nOMP using LM :"),"Started at ",as.character(Sys.time())))
    form = paste("target ~ 1")
    # Initialize
    m1 = glm.nb(target ~ 1)

  }else{
    # =========================== GLMM ==================================
    cat(paste(cyan("\nOMP using GLMM :"),"Started at ",as.character(Sys.time())))

    batch_effect <- paste("(1|",paste(batch_effect,collapse = ")+(1|"),")",sep="")

    form = paste("target ~ 1+",batch_effect)
    print(form)
    # Initialize

    if(quasi){
      m1 <- glmer(as.formula(form),family=quasipoisson(link="log"))
    }else{
      m1 = glmer.nb(as.formula(form),nAGQ=0,control=glmerControl(optimizer = "nloptwrap"))
    }
    # m1 <- glmer(form,family=poisson(link=log),nAGQ=0,control=glmerControl(optimizer = "nloptwrap"))
    # m1 = glmer.nb(form,REML=FALSE)

  }


  #  ============================ OMP Iteration ======================================
  BIC_old = BIC(m1)
  Diffe = 5
  counter= 0
  list_var= c()
  X = as.data.frame(X)
  X <- t(X)

  while (Diffe >BIC_thres){
    col_names = colnames(X)
    counter = counter+1
    cor_vals = c(cor(resid(m1),X))
    a = which.max(abs(cor_vals))
    list_var[counter]  = col_names[a]
    form_vars <- paste(lapply(list_var,FUN = function(x) paste("X[,'",x,"']",sep="")),collapse = "+")

    if(converter=="pca_like"){
      form = paste("target ~ ",form_vars)
      tryCatch({
        m1 = glm.nb(as.formula(form))
      },error=function(e){
        cat(red("Error"))
        print(form)
      })
    }else{
      batch_effect <- paste(batch_effect,collapse = ")+(1|")
      form = paste("target ~ ",form_vars ,"+",batch_effect)
      cat(form)
      tryCatch({
        # m1 <- glmer(form,family=poisson(link=log),nAGQ=0,control=glmerControl(optimizer = "nloptwrap"))
        if(quasi){
          m1 <- glmer(as.formula(form),family=quasipoisson(link="log"))
        }else{
          m1 = glmer.nb(form,REML=FALSE,nAGQ=0,control=glmerControl(optimizer = "nloptwrap"))
        }
      },error=function(e){
        cat(red("Error"))
        print(form)
      })

    }

    BIC_new = BIC(m1)
    Diffe = BIC_old - BIC_new
    BIC_old = BIC_new

  }
  # Final model
  selected_vars = list_var[-length(list_var)]
  cat(paste(cyan("\nFinished : "),as.character(Sys.time())))
  return(selected_vars)
}
