#' Dropout Imputation
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param object: object class from Monocle/Seurat.
#' @param method: Saver/My/DrImpute
#'
#' @return Gene expression Matrix
#' @examples
#' dropout_imputation(object,method)
#'
dropout_imputation <- function(object,method="saver"){
    object3 <- object[1:100,]
    count_matrix <- object3@assays$RNA@counts[1:100,]
    dim(count_matrix)
    method <- tolower(method)
    count_matrix[is.na(count_matrix)] <- 0
    if (method=="saver"){
        require(SAVER)
        cortex.saver <- saver(count_matrix, ncores = 5)
        imp_count_matrix<-as.matrix(cortex.saver$estimate)
    }else{
        CLMMI.output <- CLMMI(count_matrix, ncores = 5)
        imp_count_matrix<-as.matrix(CLMMI.output$estimate)
    }
    imp_count_matrix[is.na(imp_count_matrix)] <- 0
    object2 <- SubsetData(object3, cells = colnames(object)[which(colnames(object)%in%colnames(imp_count_matrix))])
    object2[["RNA2"]] <- imp_count_matrix
    return(object2)
}


#' Dropout Imputation
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param object: object class from Monocle/Seurat.
#' @param ncores: Number of Cores
#'
#' @return Gene expression Matrix
#' @examples
#' CLMMI(object,ncores)
#'
CLMMI<-function(object,ncores){
    # =========== Libraries ================== #

    require(MXM)
    require(lme4)
    # ---------------------------------------- #

    # ======= Identify Core Matrix =========== #
    cells_index <- get.pred.cells(object)
    genes_index <- get.pred.genes(object)
    core_object <- object[genes_index,cells_index]
    print("The Dimensions of the core object is:")
    print(dim(core_object))
    # ---------------------------------------- #
    # ========================================= Gene Loop ================================================== #
    genes_index <-1
    gene <- object[gene_indx,]
    temp_object <- object[-gene_indx,]



    #=============================================== CROSS VALIDATION ===================================================== #

    train_matrix <- object[,-out[[1]]]
    test_matrix <- object[,out[[1]]]
    # ========= Feature Selection ============ #
    selected_vars <- MMPC.glmm(dataset=train_matrix,
                               target=gene,
                               group = cluster,
                               max_k = 3,threshold = 0.05,ncores = ncores)
    Signature <- unique(c(selected_vars@selectedVars))
    # ---------------------------------------- #

    # ============= Prediction =============== #
    formula = paste("gene~",paste(Signature,sep = "+"),"+ (1|cluster_id)")
    model = glmer.nb(as.formula(form),nAGQ=0,control=glmerControl(optimizer = "nloptwrap"))
    predicted_vals <- model.predict(test_matrix)


    # ---------------------------------------- #
}



#' get.pred.cells
#' @author Dimitrios Kyriakis
#' @export
get.pred.cells <- function(pred.cells, ncells) {
    if (!is.null(pred.cells)) {
        if (min(pred.cells) < 1 |
            max(pred.cells) > ncells) {
            stop("pred.cells must be column indices of x")
        }
    } else {
        pred.cells <- 1:ncells
    }
    pred.cells
}

#' get.pred.genes
#' @author Dimitrios Kyriakis
#' @export
get.pred.genes <- function(object, pred.genes, npred, ngenes) {
    nFeatures.percent <- rowSums(object != 0)/dim(object)[1]

    if (!is.null(pred.genes)) {
        if (min(pred.genes) < 1 |
            max(pred.genes) > ngenes) {
            stop("pred.genes must be row indices of x")
        }
    } else if (is.null(npred)) {
        pred.genes <- (1:ngenes)[Matrix::rowSums(x) != 0]
    } else if (npred < ngenes) {
        npred <- min(sum(Matrix::rowSums(x) != 0), npred)
        pred.genes <- order(Matrix::rowMeans(x), decreasing = TRUE)[1:npred]
    } else {
        stop("npred must be less than number of rows in x")
    }
    pred.genes
}



#' Gene Prediction
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param object: Gene expression Matrix
#' @param index: Gene index
#'
#' @return Indexes for Cross Validation
#' @examples
#' gene_prediction(object,index)
#'
gene_prediction <- function(object,index){
    genes_index <-index
    gene <- object[gene_indx,]
    temp_object <- object[-gene_indx,]

    # ======= Prepare Cross Validation ======= #
    indexes <- stratified_kfold(object=temp_object,
                                cluster=cluster,
                                Min_Folds=5)
    # ---------------------------------------- #

}




#' Stratified K-Fold
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param object: Gene expression Matrix
#' @param cluster: Clusters/Groups of Cells
#'
#' @return Indexes for Cross Validation
#' @examples
#' stratified_kfold(object,cluster,Min_Folds=5)
#'
stratified_kfold <-function(cluster,Min_Folds=5){
    require(rBayesianOptimization)
    if (Min_Folds<5){
        print("Number of Folds Changed due to stratification")
        Min_Folds<- min(table(Cluster))
    }
    indexes <- KFold(cluster, nfolds = Min_Folds, stratified = TRUE, seed = 123)
    return(indexes)
}

#
#
#
#
# setwd("C:/Users/dimitrios.kyriakis/Desktop/Imputation")
# require(MXM)
# library(stringr)
# file <- "C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/RAT_Data/DATA/RATB1_S1_DGE.txt"
# object <- read.csv(file,header=T,row.names=1, sep='\t')
# object <- object[,order(colSums(object),decreasing=T)]
# rows_nms <- str_replace_all( toupper(rownames(object)),"-",".")
# rownames(object) <- rows_nms
#
# # ====================== SEURAT ================================
# metrics_output <- metrics_calc(object,remove_mt,remove_ribsomal)
# object <- metrics_output$object
# percent.mito <- metrics_output$percent.mito
# percent.rb <-  metrics_output$percent.rb
#
# Seurat <- CreateSeuratObject(counts = object, project = "imputation",
#                              min.cells = 5,
#                              min.features = 200,
#                              meta.data = data.frame(percent.mito = percent.mito,percent.rb=percent.rb))
# Seurat$stim <- "imputation"
# Seurat$condition <- rep("imputation",dim(Seurat)[2])
#
# Outlier_object <- Outlier_detection(Seurat,outlier_detector="MAD")
# Seurat <- Outlier_object$object_filtered
# oultliers_index <- Outlier_object$oultliers_index
#
# Seurat <- Seurat [Matrix::rowSums(Seurat) != 0,]
# MAT2 <- as.matrix(Seurat@assays$RNA@counts)
#
# MAT <- MAT2[Matrix::rowSums(Seurat) != 0,]
# # =================. Impute missing gene expressions with SAVER
# if (imputation ==TRUE) {
#     cat(green("\nImputation with SAVER\n"))
#     library(SAVER)
#     allcells <- Seurat@assays$RNA@counts
#     allcells[is.na(allcells)] <- 0
#     cortex.saver <- saver(allcells, ncores = 5)
#     allcells<-as.matrix(cortex.saver$estimate)
#     allcells[is.na(allcells)] <- 0
#     Seurat <- SetAssayData(object = Seurat, slot = "counts", new.data = MAT3)
#     Seurat <- SetAssayData(object = Seurat, slot = "data", new.data = MAT3)
# }
# # --------------------------------------------------------------------------------------
#
#
# # ====== Identification of highly variable features (feature selection)
# Seurat <- NormalizeData(object = Seurat, normalization.method = "LogNormalize", scale.factor = 10000)
# Seurat <- FindVariableFeatures(object = Seurat, selection.method = "vst", nfeatures = 2000)
# Seurat <- ScaleData(object = Seurat, vars.to.regress = c("nUMI", "percent.mito"), display.progress = FALSE)
# Seurat <- reduce_dim(Seurat,project="imputation")$Combined
#
# Seurat$Cluster[Seurat$Cluster%in%c(6,7)] <- 0
# plot_cells(Seurat,target="condition",leg_pos="right",save=FALSE,ncol=1)
# plot_cells(Seurat,target="Cluster",leg_pos="right",save=FALSE,ncol=1)
#
# # -----------------------------------------------------------
#
# table(Matrix::rowSums(Seurat) != 0)
#
# MAT2 <- as.matrix(Seurat@assays$RNA@counts)
# MAT <- MAT2[Matrix::rowSums(Seurat) != 0,]
# dim(MAT)
# dim(MAT2)
#
# # ================== FROM SEURAT =====================================
# calc.size.factor <- function(x) {
#     sf <- Matrix::colSums(x)/mean(Matrix::colSums(x))
#     return(sf)
# }
# # assign size factor
# sf.out <- calc.size.factor(x, size.factor, ncells)
# sf <- sf.out[[1]]
# scale.sf <- sf.out[[2]]
# good.genes <- which(Matrix::rowMeans(sweep(x, 2, sf, "/")) >= 0.1)
# x.est <- t(as.matrix(log(sweep(x[good.genes, ] + 1, 2, sf, "/"))))
# # --------------------------------------------------------------------
#
# cluster <- as.vector(Seurat$Cluster)
#
# dim(MAT)
# length(rowSums(MAT))
# hist(rowSums(MAT),1000)
# complete <- rowSums(MAT != 0)
# table(complete>=dim(MAT)[2])
#
# Core_MAT <- MAT[complete==dim(MAT)[2],]
#
# Pred_MAT <- MAT[complete!=dim(MAT)[2],]
# Pred_MAT <- Pred_MAT[order(rowSums(Pred_MAT),decreasing = TRUE),]
# dim(Core_MAT)
# dim(Pred_MAT)
#
#
# range_genes <- range(dim(Pred_MAT)[1])
# range_genes <- c(1,2)
#
# # ======================== FOR LOOP FOR EACH GENE TO PREDICT ==============================
# # for (i in range_genes){
#     i=3
#     gene <- as.vector(Pred_MAT[i,])
#
#     # ===== TRAINIG SET ============
#     temp_mat <- Core_MAT[,gene!=0]
#     temp_cluster <- cluster[gene!=0]
#     temp_values <- gene[gene!=0]
#     dim(temp_mat)
#     length(temp_cluster)
#     length(temp_values)
#
#     # ====== Hiddden Set ===========
#     hidden_mat <- Core_MAT[,gene==0]
#     hidden_cluster <- cluster[gene==0]
#     hidden_values  <- gene[gene==0]
#
#     dim(hidden_mat)
#
#     indexes <- stratified_kfold(cluster=temp_cluster)
#     # for (j in indexes){
#         j=1
#         train_matrix <- t(temp_mat[,-j])
#         train_family <- temp_cluster[-j]
#         train_values <- temp_values[-j]
#         dim(train_matrix)
#         length(train_family)
#         length(train_values)
#
#         test_matrix  <- temp_mat[,j]
#         test_family  <- temp_cluster[j]
#         test_values  <- temp_values[j]
#
#         # ========= Feature Selection ============ #
#         selected_vars <- MMPC.glmm(dataset = as.data.frame(train_matrix),
#                                    target = train_values,
#                                    group = as.factor(train_family),
#                                    max_k = 3,threshold = 0.05,ncores = 1)
#         m1 = SES.temporal(target=train_values, reps = NULL, group=as.numeric(train_family),
#                           dataset=as.data.frame(train_matrix),
#                           max_k = 3, threshold = 0.05,
#                           test = "testIndLMM",ncores = 1)
#
#         library(glmmLasso)
#         formula = paste0(paste("train_values",paste(colnames(train_matrix),collapse = "'+'"),sep="~'"),"'")
#         train_df <- as.data.frame(train_matrix)
#         train_df$Cluster <- as.factor(train_family)
#         train_df$train_values <- train_values
#         'train_values~PRSS40+RINL+SLC17A7+SLC19A3'
#
#         lm2 <- glmmLasso(train_values~PRSS40+RINL+SLC17A7+SLC19A3,
#                          rnd = list(Cluster=~1 ),lambda = 10,
#                          data = train_df)
#
#         mmpc_sel_vars <- unique(c(selected_vars@selectedVars))
#         # ---------------------------------------- #
#
#         # ============= Prediction =============== #
#         formula = paste("train_values~",paste(Signature,sep = "+"),"+ (1|train_family)")
#         model = glmer.nb(as.formula(form),nAGQ=0,control=glmerControl(optimizer = "nloptwrap"))
#         predicted_vals <- model.predict(test_matrix)
#
#
#         # ---------------------------------------- #
#
#     # }
# # }
#
#
