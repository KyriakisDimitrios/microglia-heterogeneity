# === General Libs
# library(useful)
# library(crayon)
# library(parallel)
# library(tictoc)
# library(stringr)

# library(monocle)
# library(Seurat)
# library(dplyr)
# library(cowplot)
# library(NMF)
# library(RColorBrewer) # for color definition
# library(jcolors)
# library(ggplot2)
# library(crayon)
# library(Routliers)
# library(slingshot)
# library(Matrix)
# library(ecp)
# library(ggplot2)
# library(ggpubr)

# # == Network
# require(MXM)
# require(visNetwork)

#' data_selection
#' @author Dimitrios Kyriakis
#' @export
data_selection <- function(project){
	if(get_os()=="windows"){
	    WORKDIR=paste0("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/",project,"/")
	}else{
    	WORKDIR=paste0("/home/users/dkyriakis/PhD/Projects/",project,"/")
  	}
  	if(project=="MBSYN"){
    	cond="WT"
        if(cond=="WT"){
          	list_of_files   <- c(paste(WORKDIR,"DATA/MBSYN3_S1_DGE.txt",sep=""),
                               paste(WORKDIR,"DATA/MBSYN4_S2_DGE.txt",sep=""))
          	condition_names <- c("WT mice (Midbrain)",
                               "WT mice (Striatum)")

        }else if (cond=="TG"){
          	list_of_files   <- c(paste(WORKDIR,"DATA/MBSYN1_S1_DGE.txt",sep=""),
                               paste(WORKDIR,"DATA/MBSYN2_S2_DGE.txt",sep=""))
          	condition_names <- c("TG a-syn (Midbrain)",
                               "TG a-syn (Striatum)")
        }else{
          	list_of_files   <- c(paste(WORKDIR,"DATA/MBSYN3_S1_DGE.txt",sep=""),
                               paste(WORKDIR,"DATA/MBSYN4_S2_DGE.txt",sep=""),
                               paste(WORKDIR,"DATA/MBSYN1_S1_DGE.txt",sep=""),
                               paste(WORKDIR,"DATA/MBSYN2_S2_DGE.txt",sep=""))

          	condition_names <- c("WT mice (Midbrain)",
                               "WT mice (Striatum)",
                               "TG a-syn (Midbrain)",
                               "TG a-syn (Striatum)")

        }
        file <- paste0(WORKDIR,"/Gene_Lists/Cell_types2.txt")
        organism <- "mouse"
        data_10x=FALSE
    }

    if(project=="RAT_Data"){
        list_of_files   <- c(paste0(WORKDIR,'DATA/RATB1_S1_DGE.txt'),
                            paste0(WORKDIR,'DATA/RATB2_S2_DGE.txt'),
                            paste0(WORKDIR,'DATA/RATB3_S1_DGE.txt'),
                            paste0(WORKDIR,'DATA/RATB4_S2_DGE.txt'))

        condition_names <- c("RATB1", "RATB2", "RATB3", "RATB4")
        condition_names <- c("Day09", "Day14", "Day17", "Day21")
        organism <- "rat"
        file <- paste0(WORKDIR,"Gene_Lists/Paper_Gene_List.txt")#"Cell_types.txt"
        data_10x=FALSE
    }

    if(project=="Christophe_Data"){
        list_of_files   <- c(paste0(WORKDIR,'CTISO1_S1_DGE.txt'),
                              paste0(WORKDIR,'CTISO2_S2_DGE.txt'),
                              paste0(WORKDIR,'CTISO3_S3_DGE.txt'),
                              paste0(WORKDIR,'CTISO4_S1_DGE.txt'),
                              paste0(WORKDIR,'CTISO5_S2_DGE.txt'),
                              paste0(WORKDIR,'CTISO6_S3_DGE.txt'))

        condition_names <- c("1hUS_PBS",
                             "1hS_isoproterenol",
                             "4hUS_PBS",
                             "4hS_isoproterenol",
                             "24hUS_PBS",
                             "24hS_isoproterenol" )
        organism <- "human"
        file <- "C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Christophe_Data/Gene_Lists/Th1Th2Th17_genes.txt"#"Cell_types.txt"
        data_10x=FALSE

    }

    if(project=="Michi_Data"){
        list_of_files   <- c(paste0(WORKDIR,'DATA/DADA1_S1_DGE.txt'),
                             paste0(WORKDIR,'DATA/DADA2_S2_DGE.txt'),
                             paste0(WORKDIR,'DATA/DADA3_S3_DGE.txt'),
                             paste0(WORKDIR,'DATA/DADA4_S4_DGE.txt'))#,
                             # 'C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Michi_Data/DATA/DADA5_S1_DGE.txt',
                             # 'C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Michi_Data/DATA/DADA6_S2_DGE.txt',
                             # 'C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Michi_Data/DATA/DADA7_S3_DGE.txt',
                             # 'C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Michi_Data/DATA/DADA8_S4_DGE.txt',
                             # 'C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Michi_Data/DATA/DADB1_S1_DGE.txt',
                             # 'C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Michi_Data/DATA/DADB4_S4_DGE.txt')

        condition_names <- c("Control_D21",
                             "Control_D15",
                             "Control_D10",
                             "Control_D06")#,
                             # "PINK1_21",
                             # "PINK1_15",
                             # "HSD_D21",
                             # "PINK1_D06",
                             # "Control_D22",
                             # "PARK1_D22")

        list_of_files   <- c((paste0(WORKDIR,'DATA/DADA1_S1_DGE.txt')),
                                     (paste0(WORKDIR,'DATA/DADA2_S2_DGE.txt')),
                                     (paste0(WORKDIR,'DATA/DADA3_S3_DGE.txt')),
                                     (paste0(WORKDIR,'DATA/DADA4_S4_DGE.txt')),
                                     (paste0(WORKDIR,'DATA/DADA5_S1_DGE.txt')),
                                     (paste0(WORKDIR,'DATA/DADA6_S2_DGE.txt')),
                                     (paste0(WORKDIR,'DATA/DADA7_S3_DGE.txt')),
                                     (paste0(WORKDIR,'DATA/DADA8_S4_DGE.txt')),
                                     (paste0(WORKDIR,'DATA/DADB1_S1_DGE.txt')),
                                     (paste0(WORKDIR,'DATA/DADB4_S4_DGE.txt')))

        condition_names <- c("Control_D21",
                             "Control_D15",
                             "Control_D10",
                             "Control_D06",
                             "PINK1_D21",
                             "PINK1_D15",
                             "HSD_D21",
                             "PINK1_D06",
                             "Control_D22",
                             "PARK1_D22")
        organism <- "human"
        file <- "C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Michi_Data/Gene_Lists/IPCS_genes.txt"#"Cell_types.txt"
        data_10x=FALSE

    }
    if(project=="10x_Kamil"){
        list_of_files   <- c(paste0(WORKDIR,"ATP_0uM/"),
                             paste0(WORKDIR,"ATP_20uM/"),
                             paste0(WORKDIR,"ATP_50uM/"),
                             paste0(WORKDIR,"ATP_100uM/"))

        condition_names <- c("ATP_000uM", "ATP_020uM", "ATP_050uM", "ATP_100uM")
        organism <- "human"
        file <- paste0(WORKDIR,"Gene_Lists/HMLER_genes.txt")
        data_10x=TRUE

    }

    return(list("WORKDIR"=WORKDIR,"list_of_files"=list_of_files,"condition_names"=condition_names,"organism"=organism,"file"=file,"data_10x"=data_10x))
}
