#' Erncigment Analysis GO analysis
#' @author Dimitrios Kyriakis
#' @export
#' @param gene_symbols : Vector of gene symbols
#' @param organism : String with the organism to search.
#' @param ontology : Vector with the GOterms to check (Default = c("BP")).
#' @param qval_thres : qvalue threshold for the significance of the pathway (Default = 0.05).
#' @param save : Save plots (Default = TRUE).
#' @param title : Title to the saved table and plots.
#'
#' @return Returns the enrichment analysis table and plots
#' @examples
#' gene_set_enrich(gene_symbols,organism,ontology=c("BP"),qval_thres=0.05,save=TRUE,title="")
gene_set_enrich <- function(gene_symbols,universe,organism,ontology=c("BP"),qval_thres=0.05,save=TRUE,title=""){
    # returns the enrichment analysis table and plots
    #
    # Args:
    #   gene_symbols : Vector of gene symbols
    #   organism : String with the organism to search
    #   ontology: Vector with the GOterms to check (Default = c("BP"))
    #   qval_thres : qvalue threshold for the significance of the pathway (Default = 0.05)
    #   save : Save plots (Default = TRUE)
    #   title: Title to the saved table and plots
    library(biomaRt)
    library(clusterProfiler)
    library(topGO)
    if (tolower(organism) == "human"){
        OrgDb = "org.Hs.eg.db"
        symbols <- gene_symbols
    } else{
        symbols = unlist(lapply(tolower(as.vector(gene_symbols)),simpleCap))
        if(tolower(organism) == "rat"){
          OrgDb = "org.Rn.eg.db"
        } else{
          OrgDb = "org.Mm.eg.db"
        }
    }

    # library(org.Mm.eg.db)
    library(OrgDb,character.only=TRUE)

    # symbols = as.vector(data$gene)


    # mapIds(org.Mm.eg.db, keys=symbols,"ENTREZID","SYMBOL")
    # eg=bitr(symbols,fromType = "SYMBOL",toType=c("SYMBOL","ENTREZID"),OrgDb=OrgDb)
    # head(eg$ENTREZID)

    for (ont in ontology){
        ego <- enrichGO(gene          = symbols,
                        OrgDb         = OrgDb,
                        ont           = ont,
                        pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,
                        qvalueCutoff  = qval_thres,
                        keyType="SYMBOL")
        df = summary(ego)

        term=df$ID[order(df$p.adjust, decreasing=T)]

        if(save){
          pdf(paste(Sys.Date(),"GSEA_Dotplot",organism,ont,qval_thres,title,".pdf",sep="_"),height=14,width=18)
          # print(barplot(ego, showCategory=term[1:30], order=T))#barplot(ego, showCategory=30))
          print(barplot(ego, showCategory=30))
          dev.off()
          pdf(paste(Sys.Date(),"GSEA_GOgraph",organism,ont,qval_thres,title,".pdf",sep="_"),height=14,width=18)
          plotGOgraph(ego)
          dev.off()
          write.table(ego,file=paste(Sys.Date(),organism,"GSEA",ont,qval_thres,title,".tsv",sep="_"),row.names=FALSE,na="",sep="/t")
        }
    }

    # pdf(paste(Sys.Date(),"EnrichMap_Microglia_DF_Clusters.pdf",sep="_"),height=14,width=18)
    # enrichMap(ego, vertex.label.cex=1.2, layout=igraph::layout.kamada.kawai)
    # dev.off()

    return(ego)
}




# =============================== David Encrichment Analysis ==========================================
#' Returns the enrichment analysis table and plots.
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param gene_symbols : Vector of gene symbols
#' @param organism : String with the organism to search.
#' @param qval_thres : qvalue threshold for the significance of the pathway (Default = 0.05).
#' @param save : Save plots (Default = TRUE).
#' @param title : Title to the saved table and plots.
#'
#' @return A matrix with the top expressed genes
#' @examples
#' david_enrich(gene_symbols,idents=NULL,universe=NULL,organism,qval_thres=0.05,save=TRUE,title="",david.user)
david_enrich <- function(gene_symbols,idents=NULL,universe=NULL,organism,qval_thres=0.05,save=TRUE,title=""){
    require(DOSE)
    require(clusterProfiler)
    library(biomaRt)
    library(topGO)
    if (tolower(organism) == "human"){
        OrgDb = "org.Hs.eg.db"
        symbols <- gene_symbols
    } else{
        symbols = unlist(lapply(tolower(as.vector(gene_symbols)),simpleCap))
        if(!is.null(universe)){
            universe <- unlist(lapply(tolower(as.vector(universe)),simpleCap))
        }
        if(tolower(organism) == "rat"){
            OrgDb = "org.Rn.eg.db"
        } else{
            OrgDb = "org.Mm.eg.db"
        }
    }

    library(OrgDb,character.only=TRUE)
    eg=bitr(symbols,fromType = "SYMBOL",toType=c("SYMBOL","ENTREZID"),OrgDb=OrgDb)
    gene = eg$ENTREZID
    idents <- idents[toupper(gene_symbols)%in%toupper(eg$SYMBOL)]
    # if(!is.null(universe)){
    #     universe <- bitr(universe,fromType = "SYMBOL",toType=c("SYMBOL","ENTREZID"),OrgDb=OrgDb)$ENTREZID
    # }

    # if(is.null(universe)){
    david = enrichDAVID(gene = gene, idType="ENTREZ_GENE_ID" ,annotation="KEGG_PATHWAY",david.user="dimitrios.kyriakis@uni.lu")
    # }else{
    #     david = enrichDAVID(gene = gene, idType="ENTREZ_GENE_ID" ,universe=universe,annotation="KEGG_PATHWAY",david.user="dimitrios.kyriakis@uni.lu")
    # }

    if(!is.null(david)){
        p1<-barplot(david)
        # p2 <- cnetplot(david, foldChange=gene_symbols)

        if(save){
            pdf(paste(Sys.Date(),title,"David_Bar_enrich.pdf",sep="_"))
            print(p1)
            dev.off()
            # pdf(paste(Sys.Date(),title,"David_cnetplot.pdf",sep="_"))
            # plot(p2)
            # dev.off()
        }

        plotlist<- list(david=david)

        if(!is.null(idents)){
            eg2 <- cbind(eg,idents)
            # gcSample_dim <- list(Day9=as.vector(eg2$ENTREZID[eg2$idents=="Day9"]),Day17=as.vector(eg2$ENTREZID[eg2$idents=="Day17"]))
            mydf <- data.frame(Entrez=eg2$ENTREZID,FCgroup=as.vector(eg2$idents))
            x=compareCluster(Entrez ~ FCgroup, data = mydf, fun="enrichDAVID", annotation="KEGG_PATHWAY",david.user="dimitrios.kyriakis@uni.lu")

            p3 <- dotplot(x, showCategory=TRUE)
            if(save){
                pdf(paste(Sys.Date(),title,"David_Dot_enrich.pdf",sep="_"))
                print(p3)
                dev.off()
            }
            plotlist["Dot"]<-x
        }

        # x <- enrichDO(gene          = eg2$ENTREZID,
        #               ont           = "DO",
        #               pvalueCutoff  = 0.05,
        #               pAdjustMethod = "BH",
        #               minGSSize     = 5,
        #               maxGSSize     = 500,
        #               qvalueCutoff  = 0.05,
        #               readable      = FALSE)
        # pdf("disease_dot.pdf")
        # print(dotplot(x, showCategory=TRUE))
        # dev.off()
        return(plotlist)
    }
    return("No Enrichment")
}

