#' Pseudotime Analysis
#' @author Dimitrios Kyriakis
#'
#' @export
#' @param object: object class from Monocle/Seurat.
#' @param reducedDim: call rate.
#' @param reverse: Remove mitochondrial genes (Default=TRUE).
#' @param method : slingshot/ddrtree.
#'
#' @return Pseudotime
#' @return Gene expression Matrix
df_pseudotime<-function(object,reducedDim="DiffMap",reverse=FALSE,method="slingshot"){
    if(tolower(method)=="slingshot"){
        # debugonce(slingshot_DiffMap)
        pseudo_output <- slingshot_DiffMap(object,reverse=reverse)

    }else{
        # debugonce(monocle_DDRTree)
        pseudo_output <- monocle_DDRTree(object,reverse=reverse)

    }
    return(pseudo_output)
}

#' monocle_DDRTree
#' @author Dimitrios Kyriakis
#' @export
monocle_DDRTree <-function(object,reverse=FALSE, batch_formula="~num_genes_expressed",Title=Sys.Date(),n_cores=4){
    tool <- object_identifier(object)
    orig_object <- object
    if(tool=="seurat"){
        object <- seurat_to_monocle(object)
    }

    tic()
    cat(cyan("Branched expression analysis modeling (BEAM) : ") %+% "Started at " %+% as.character(Sys.time()))

    library(dplyr)
    colormap_d<- c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928',"black","gray")
    color_cond  <- brewer.pal(8,"Dark2")
    color_clust <- c(brewer.pal(12,"Paired")[-11],"black","gray","magenta4","seagreen4")
    color_cells <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")

    color_list <- list(condition=color_cond,Cluster=color_clust,Cell_Type=color_cells,State=color_clust)

    disp_table_all <- dispersionTable(object)
    ordering_genes_all <- subset(disp_table_all, mean_expression >= 0.5 & dispersion_empirical >= 1 * dispersion_fit)$gene_id

    # Once we have a list of gene ids to be used for ordering, we need to set them in the HSMM object,
    # because the next several functions will depend on them.
    object<- setOrderingFilter(object, ordering_genes_all) #makes a new monocle cell object based on ctHSMM
    pdf('dispersion_ALL_PT_new.pdf')
    print(plot_ordering_genes(object))
    dev.off()

    # ===================== Trajectory step 2: reduce data dimensionality =================
    cat(paste0("\nResidual Model : ",batch_formula,"\n"))
    object <- reduceDimension(object, max_components=2, reduction_method = 'DDRTree', residualModelFormulaStr=batch_formula) #

    # ===================== Trajectory step 3: order cells along the trajectory
    object <- orderCells(object,reverse=reverse)

    # Calculate the differential expressed genes in pseudotime
    my_pseudotime_de <- differentialGeneTest(object,
                                             fullModelFormulaStr = "~sm.ns(Pseudotime)",
                                             cores = n_cores)

    head(my_pseudotime_de)
    my_pseudotime_de %>% dplyr::arrange(qval) %>% head()
    # save the top 6 genes
    my_pseudotime_de %>% dplyr::arrange(qval) %>% head() %>% dplyr::select(gene_short_name) -> my_pseudotime_gene
    my_pseudotime_gene <- my_pseudotime_gene$gene_short_name
    pdf(paste(Title,"Pseudotime.pdf",sep="_"))
    print(plot_genes_in_pseudotime(object[fData(object)$gene_short_name %in%my_pseudotime_gene,]))
    dev.off()

    # pdf(paste(Title,"Branched+Pseudotime.pdf",sep="_"))
    # print(plot_genes_branched_pseudotime(object[fData(object)$gene_short_name %in%my_pseudotime_gene,],branch_point=0))
    # dev.off()

    # cluster the top 50 genes that vary as a function of pseudotime
    my_pseudotime_de %>% dplyr::arrange(qval) %>% head(100) %>% dplyr::select(gene_short_name) -> gene_to_cluster
    gene_to_cluster <- gene_to_cluster$gene_short_name

    # Plot the 50 top differential expressed genes in pseudotime
    my_pseudotime_cluster <- plot_pseudotime_heatmap(object[fData(object)$gene_short_name %in%gene_to_cluster,],
                                                     cores = 2,
                                                     show_rownames = TRUE,
                                                     return_heatmap = TRUE)
    pdf(paste(Title,"Pseudo_Heatmap.pdf",sep="_"))
    print(my_pseudotime_cluster)
    dev.off()



    pdf(paste(Title,'cell_trajectory_col_condition.pdf',sep="_"))
    print(plot_cell_trajectory(object, color_by="condition"))
    dev.off()

    pdf(paste(Title,'cell_trajectory_col_Cluster.pdf',sep="_"))
    print(plot_cell_trajectory(object, color_by="Cluster")+
            scale_color_manual(values = color_list[["Cluster"]]))
    dev.off()

    pdf(paste(Title,'cell_trajectory_col_State.pdf',sep="_"))
    print(plot_cell_trajectory(object, color_by="State")+
            scale_color_manual(values = color_list[["State"]]))
    dev.off()

    pdf(paste(Title,'cell_trajectory_col_Pseudotimes.pdf',sep="_"))
    print(plot_cell_trajectory(object, color_by="Pseudotime"))
    dev.off()

    pdf(paste(Title,'cell_trajectory_col_State_wrap.pdf',sep="_"))
    print(plot_cell_trajectory(object, color_by="State")+ facet_wrap(~condition, nrow=1)+
            scale_color_manual(values = color_list[["State"]]))
    dev.off()


    pdf(paste(Title,'cell_trajectory_col_separated_condition.pdf',sep="_"))
    print(plot_cell_trajectory(object, color_by="condition") + facet_wrap(~condition, nrow=1))
    dev.off()

    pdf(paste(Title,"of_pseudotimes.pdf",sep="_"))
    print(qplot(Pseudotime, data=pData(object), color=condition,geom="density"))
    dev.off()

    # pdf(paste0(Sys.Date(),"_",dataset,"_Scat_BEAM.pdf"))
    # print(plot_cell_clusters(object,1,2,color_by ="Pseudotime"))
    # dev.off()
    orig_object$Pseudotime<-object$Pseudotime
    orig_object$State<-object$State



    # ======================= ANNIMATED PLOT ===================================
    aa <- hist(object$Pseudotime, 10, plot=F)
    max(object$Pseudotime)
    break_pseudo<- object$Pseudotime
    for (br in rev(aa$breaks)){
      break_pseudo[object$Pseudotime<=br] <- br
    }

    p1<- plot_cell_trajectory(object, color_by="Pseudotime")+
      geom_point(alpha = 0.7) + labs(title = "Pseudotime: {frame_time}") +
      theme(legend.position = "right",text = element_text(size=20))+
      transition_time(break_pseudo)+shadow_mark(alpha = 0.3, size = 0.5)
    print(p1)
    anim_save("Animated_Pseudotime.gif", animation = last_animation())
    # -------------------------------------------------------------------------


    cat(cyan("Finished : ") %+% as.character(Sys.time()))
    return(list("object"=orig_object,"df_genes"=gene_to_cluster,"all_df"=my_pseudotime_de%>% dplyr::arrange(qval)))
}

#' slingshot_DiffMap
#' @author Dimitrios Kyriakis
#' @export
slingshot_DiffMap <- function(object,reducedDim="DiffMap",reverse=FALSE){
    tool <- object_identifier(object)
    require(SingleCellExperiment)
    require(slingshot)
    require(destiny, quietly = TRUE)
    library(gganimate)
    reducedDim_u <- toupper(reducedDim)
    reducedDim_l <- tolower(reducedDim)
    if(tolower(tool)=="monocle"){
        deng_SCE <- SingleCellExperiment(object)
    }else{
        deng_SCE <- as.SingleCellExperiment(object)
    }

    if(tolower(tool)=="monocle"){
        GE_matrix<- data.matrix(object, rownames.force = NA)
        GE_matrix <- as.matrix(GE_matrix)
        rownames(GE_matrix) <- fData(object)$gene_short_name
        Normilize_Vector <- pData(object)[, 'Size_Factor']
        counts <- as.matrix(sweep(GE_matrix,2,Normilize_Vector,"/"))

        # counts <- GE_matrix
    }else{
        # counts <- as.matrix(object@assays$integrated@data)-min(as.matrix(object@assays$integrated@data))
      # counts <- GetAssayData(object,assay = "RNA")
      counts <- as.matrix(object@assays$RNA@counts)
    }

    pca <- prcomp(t(log1p(counts)), scale. = FALSE)
    rd1 <- pca$x[,1:2]


    dm <- DiffusionMap(t(log1p(as.matrix(counts))))
    rd2 <- cbind(DC1 = dm$DC1, DC2 = dm$DC2)

    #plot(rd2, col = rgb(0,0,0,.5), pch=16, asp = 1)
    reducedDims(deng_SCE) <- SimpleList(PCA = rd1, DIFFMAP = rd2)

    if(tolower(tool)=="monocle"){
        object@reducedDimS <- t(rd2)
    }else{
        object@reductions$diffmap <- rd2
    }



    # Read the Slingshot documentation (?slingshot) and then run Slingshot below.
    # Given your understanding of the algorithm and the documentation, what is one
    # major set of parameters we omitted here when running Slingshot?
    sce <- slingshot(deng_SCE,  reducedDim = reducedDim_u)  # no clusters

    # Plot PC1 vs PC2 colored by Slingshot pseudotime.
    colors <- rainbow(50, alpha = 1)
    a <-slingCurves(sce)$curve1$s[,1:2]
    dm <- reducedDims(sce)[[reducedDim_u]][,1:2]
    colnames(dm) <- paste0("DM_", 1:2)

    if(tolower(tool)=="monocle"){
        object@reducedDimS <- t(dm)
    }else{
        object[["dm"]] <- CreateDimReducObject(embeddings = dm, key = "DM_", assay = DefaultAssay(object))
    }

    if(reverse==TRUE){
      pst <- sce$slingPseudotime_1
      order_labels <- order(pst)
      pst_r <- sort(pst,decreasing = T)
      pst[order_labels] <- pst_r
      sce$slingPseudotime_1 <- pst
    }


    df_ps<-as.data.frame(cbind(reducedDims(sce)[[reducedDim_u]][,1:2],(sce$slingPseudotime_1),as.factor(object$condition),as.factor(object$Cluster)))
    colnames(df_ps) <- c("Component_1","Component_2","Pseudotime","Condition","Cluster")
    p1<-ggplot(df_ps) + geom_point(aes(x=Component_1,y=Component_2,color=Pseudotime)) +
      geom_point(x=a[,1],y=a[,2],col="black",pch=19, size=1)+
      theme(legend.position = "right",text = element_text(size=20))

    p2 <- plot_cells(object,target="condition",leg_pos="right",save=FALSE,ncol=1,reduction="dm")+theme(legend.position = "right",text = element_text(size=20))
    p3 <- plot_cells(object,target="Cluster",leg_pos="right",save=FALSE,ncol=1,reduction="dm")+theme(legend.position = "right",text = element_text(size=20))

    # p2<-DimPlot(object = object, reduction = "dm", group.by = "condition",cols =color_cond )
    # p3<-DimPlot(object = object, reduction = "dm", group.by = "cluster",cols =color_clust )

    pdf("Pseudotime_Analysis_Time.pdf")
    plot(p1)
    dev.off()


    pdf("Pseudotime_Analysis_Conds.pdf")
    plot(p2)
    dev.off()


    pdf("Pseudotime_Analysis_Clust.pdf")
    plot(p3)
    dev.off()

    pdf("Pseudotime_Analysis.pdf",width=16,height=8)
    print(plot_grid( p2,p3,p1,ncol = 3))
    dev.off()


    # ======================= ANNIMATED PLOT ===================================
    object$Pseudotime <- df_ps$Pseudotime
    aa <- hist(object$Pseudotime, 10, plot=F)
    max(object$Pseudotime)
    break_pseudo<- object$Pseudotime
    for (br in rev(aa$breaks)){
      break_pseudo[object$Pseudotime<=br] <- br
    }
    df <- as.data.frame(cbind(dm,object$condition,break_pseudo))
    colnames(df) <- c("DM_1","DM_2","Condition","Pseudotime")

    p1<- ggplot(df,aes(x=DM_1,y=DM_2,colour=break_pseudo))+
      geom_point(alpha = 0.7) + labs(title = "Pseudotime: {frame_time}") +
      transition_time(break_pseudo)+shadow_mark(alpha = 0.3, size = 0.5) +
      theme(legend.position = "right",text = element_text(size=20))
    print(p1)
    anim_save("Animated_Pseudotime.gif", animation = last_animation())
    # -------------------------------------------------------------------------


    # ============================ Differential Expression Analysis in pseudotime =============================
    library(gam)

    # Only look at the 1,000 most variable genes when identifying temporally expressesd genes.
    # Identify the variable genes by ranking all genes by their variance.

    Y <- log2(counts + 1)
    var1K <- names(sort(apply(Y, 1, var),decreasing = TRUE))[1:1000]
    Y <- Y[var1K, ]  # only counts for variable genes

    # Fit GAM for each gene using pseudotime as independent variable.
    t <- sce$slingPseudotime_1
    gam.pval <- apply(Y, 1, function(z){
        d <- data.frame(z=z, t=t)
        tmp <- gam(z ~ lo(t), data=d)
        p <- summary(tmp)[4][[1]][1,5]
        p
    })

    # Identify genes with the most significant time-dependent model fit.
    topgenes <- names(sort(gam.pval, decreasing = FALSE))[1:100]

    # Prepare and plot a heatmap of the top genes that vary their expression over pseudotime.
    require(clusterExperiment)
    heatdata <- as.matrix(Y[rownames(Y) %in% topgenes, order(t, na.last = NA)])
    heatclus <- object$condition[order(t, na.last = NA)]

    png(paste0("heatmap_time_genes.png"), width=10, height=10, units = "in", res=200)
    ce <- ClusterExperiment(heatdata, heatclus, transformation = log1p)
    clusterExperiment::plotHeatmap(ce, clusterSamplesData = "orderSamplesValue", visualizeData = 'transformed', cexRow = 1.5, fontsize = 15)
    dev.off()

    pdf(paste0("heatmap_time_genes.pdf"), width=10, height=10)
    ce <- ClusterExperiment(heatdata, heatclus, transformation = log1p)
    clusterExperiment::plotHeatmap(ce, clusterSamplesData = "orderSamplesValue", visualizeData = 'transformed', cexRow = 1.5, fontsize = 15)
    dev.off()



    write.table(cbind(topgenes,gam.pval), file = paste0(Sys.Date(),"_DF_Pseudotime.tsv"),row.names=FALSE, na="", sep="\t")
    return(list("object"=object,"DEGs"=topgenes,"Pseudotime"=df_ps$Pseudotime))
}

