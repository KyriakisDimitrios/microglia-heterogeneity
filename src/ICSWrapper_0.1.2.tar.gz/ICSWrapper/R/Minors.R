#' Load Files and Create Matrix.
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param list_of_files: a list of files to be load.
#' @param iter_qc: Iteration.
#' @param data_10x: Type of data (Default 10x=FALSE).
#'
#' @return Gene expression Matrix
#' @examples load_files(list_of_files,iter_qc,data_10x=FALSE)
load_files <- function(file,data_10x){
    if(data_10x){
        print(file)
        barcode.path <- paste0(file, "barcodes.tsv")
        features.path <- paste0(file, "features.tsv")
        matrix.path <- paste0(file, "matrix.mtx")
        mat <- as.matrix(readMM(file = matrix.path))
        feature.names = read.delim(features.path, header = FALSE, stringsAsFactors = FALSE)
        barcode.names = read.delim(barcode.path, header = FALSE, stringsAsFactors = FALSE)
        colnames(mat) = barcode.names$V1
        rownames(mat) = feature.names$V2
        object <- mat[,order(colSums(as.matrix(mat)),decreasing=T)]
    }else{
        object <- read.csv(file,header=T,row.names=1, sep='\t')
        object <- object[,order(colSums(object),decreasing=T)]
    }
    # = Change the cases to UPPER and - to dots
    rows_nms <- str_replace_all( toupper(rownames(object)),"-",".")
    rownames(object) <- rows_nms
    return(object)
}


#' remove_genes
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param object: Gene expression matrix.
#'
#' @return Gene expression Matrix
#' @examples remove_genes(object)
remove_genes <- function(object,remove_mt=TRUE,remove_rb=TRUE){
  # ========= Mitochondria Percentage ==========
  Mit.index <- grep(pattern = "^MT-|^MT\\.", x = rownames(object), value = FALSE)
  percent.Mit <- Matrix::colSums(object[Mit.index, ])/Matrix::colSums(object)
  # --------------------------------------------

  # ========= Ribosomal Percentage ==========
  RIB.index <- grep(pattern = "^RPL|^RPS", x = rownames(object), value = FALSE)
  percent.RIB <- Matrix::colSums(object[RIB.index, ])/Matrix::colSums(object)
  # -----------------------------------------

  if(remove_mt){
    object <- object[-Mit.index, ]
  }

  if(remove_rb){
    object <- object[-RIB.index, ]
  }

  return(object)
}


#' Metrics Calculation Mit,RB,ERCC
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param object: Gene expression matrix.
#'
#' @return Gene expression Matrix
#' @examples metrics_calc(object)
metrics_calc <- function(object,remove_mt=TRUE,remove_rb=TRUE){
    # ============= ERCC Percentage ==============
    ERCC.index <- grep(pattern = "^ERCC", x = rownames(object), value = FALSE)
    percent.ERCC <- Matrix::colSums(object[ERCC.index, ])
    object <- object[-ERCC.index, ]
    # --------------------------------------------

    # ========= Mitochondria Percentage ==========
    Mit.index <- grep(pattern = "^MT-|^MT\\.", x = rownames(object), value = FALSE)
    percent.Mit <- Matrix::colSums(object[Mit.index, ])/Matrix::colSums(object)
    # --------------------------------------------

    # ========= Ribosomal Percentage ==========
    RIB.index <- grep(pattern = "^RPL|^RPS", x = rownames(object), value = FALSE)
    percent.RIB <- Matrix::colSums(object[RIB.index, ])/Matrix::colSums(object)
    # -----------------------------------------

    if(remove_mt){
        object <- object[-Mit.index, ]
    }

    if(remove_rb){
        object <- object[-RIB.index, ]
    }

    return(list("object"=object,"percent.ERCC"=percent.ERCC,"percent.mito"=percent.Mit,"percent.rb"=percent.RIB))
}


#' Identify Operation System.
#' @author Dimitrios Kyriakis
#' @export
#' @return Returns the Operation System
#' @examples
#' get_os()
get_os <- function(){
  sysinf <- Sys.info()
  if (!is.null(sysinf)){
    os <- sysinf['sysname']
    if (os == 'Darwin')
      os <- "osx"
  } else { ## mystery machine
    os <- .Platform$OS.type
    if (grepl("^darwin", R.version$os))
      os <- "osx"
    if (grepl("linux-gnu", R.version$os))
      os <- "linux"
  }
  tolower(os)
}



#' Convert Gene list to Mouse gene list
#' @author Dimitrios Kyriakis
#' @export
#' @return Gene list as Mouse gene list
#' @examples
#' simpleCap(x)
simpleCap <- function(x) {
  s <- strsplit(x, " ")[[1]]
  s<-paste(toupper(substring(s, 1,1)), substring(s, 2),
           sep="", collapse=" ")

  if(length(grep("Loc",s) ==0)){
    s<- toupper(s)
  }
  if(length(grep("^Ay",s) ==0)){
    s<- toupper(s)
  }
  return(s)
}







#' Calculates how many Principal Components contain N\% of the variation of the data.
#'
#' @author Dimitrios Kyriakis
#' @export
#' @param CDSC: CellDataSet class from Monocle.
#' @param threshold: Expain variance.
#' @return The number of PCs expaining the N\% of the variation of the data.
#' @examples calc_num_pc <- function(CDSC,0.95).
calc_num_pc <- function(object,threshold){
  tool <- object_identifier(object)
  if(tolower(tool)=="monocle"){
    pc<-plot_pc_variance_explained(object, return_all = F)
    listaa <-pc$plot_env$irlba_res$sdev/100
  }else{
    x = Stdev(object = object, reduction = "pca")
    listaa<-x/100
  }
  z<-0
  for (i  in 1:length(listaa)) {
    z<- z +listaa[i]
    if (z>threshold){
      break}
  }
  cat(cyan("Explained Variance : ")  %+% paste(threshold, "% of the variance is explained by ", i ," Principal Components\n",sep=""))
  return(i)
}



#' seurat_to_monocle
#'
#' @author Dimitrios Kyriakis
#' @export
seurat_to_monocle<- function(object){
    mat <- as.matrix(object@assays$RNA@counts)
    data <- as(mat,"sparseMatrix")
    pd<-new("AnnotatedDataFrame",data=object@meta.data)
    pd[["num_genes_expressed"]]<-as.vector(object$nFeature_RNA)
    fData <- data.frame(gene_short_name=row.names(data),row.names=row.names(data))
    fd <- new("AnnotatedDataFrame",data=fData)
    # Construct Monocle Object
    object <- newCellDataSet(data,phenoData=pd,featureData=fd,lowerDetectionLimit=0.5,
            expressionFamily=negbinomial.size())
    object <- estimateSizeFactors(object)
    #this then for dipersion!
    object <- estimateDispersions(object)
    return(object)
}


#' object_identifier
#'
#' @author Dimitrios Kyriakis
#' @export
object_identifier<- function(object){
    if(class(object)=="Seurat"){
        tool="seurat"
    }else{
        tool="monocle"
    }
    return(tool)
}



#' Binomial overlap
#'
#' @author Dimitrios Kyriakis
#' @export
distribution_solve <- function(d1,d2){
  require(polynom)
  d2 <- -d2
  w1 = 1.0
  w2 = 1.0

  m1 <- mean(d1)
  m2 <- mean(d2)
  std1 <- sd(d1)
  std2 <- sd(d2)

  a = (std1**2 - std2**2)
  b = (-2*m2*std1**2) + 2*m1*std2**2
  c = std1**2*m2**2 - std2**2*m1**2 -2*std1**2*std2**2*log((w2*std1)/(w1*std2))
  p <- polynomial(c(c,b,a))
  print(solve(p))
  return( solve(p)[1])
}

