# Author Dimitrios Kyriakis
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'




#' Read Files
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param list_of_files: elist of files to be load.
#' @param condition_names: call rate.
#' @param remove_mt: Remove mitochondrial genes (Default=TRUE).
#' @param gene_list_remove : Remove list of genes.
#' @param imputation: Impute missing gene expressions with SAVER (Default=FALSE).
#' @param na_threshold: Genes with number of missing values more than threshold deleted.
#' @param n_cores: number of cores to use for Parallel Quality Control.
#' @param elbow: Filtering based on the PCA variance explain elbow.
#' @param data_10x: Type of data (Default 10x=FALSE).
#' @param outlier_detector: Method to detect the outliers "MAD"/"MEAN" (Default="MAD").
#'
#' @return Monocle Cell Data Set
#' @return Gene expression Matrix
#' @examples create_cds(list_of_files,condition_names,data_10x=FALSE,outlier_detector="MAD")
read_file <- function(iter_qc,list_of_files,condition_names,min.features=200,min.cells=5,remove_mt=TRUE,remove_rb=TRUE,outlier_detector="MAD",data_10x=FALSE,elbow=FALSE,imputation=FALSE,tool="Seurat"){
    init_num <- iter_qc
    file <- list_of_files[iter_qc]
    # ============== Load File ===============
    object <- load_files(file = file,data_10x=data_10x)
    # ----------------------------------------

    #============== ELBOW ====================
    if(elbow==TRUE){
        object <- elbow_calc(object,condition_names,iter_qc)
    }
    # ----------------------------------------



    # ================================= Outlier Detection ===================================
    # debugonce(Advanced_Outlier_detection)
    Outlier_object <- Advanced_Outlier_detection(object,condition= condition_names[init_num])
    object <- Outlier_object$object_filtered
    oultliers_index <- Outlier_object$oultliers_index
    # ---------------------------------------------------------------------------------------

    # #============== Metrics Calculation  ====================
    metrics_output <- metrics_calc(object=object,remove_mt=remove_mt,remove_rb=remove_rb)
    object <- metrics_output$object
    percent.mito <- metrics_output$percent.mito
    percent.rb <-  metrics_output$percent.rb
    # -------------------------------------------------------

    #object<- remove_genes(object)

    Seurat <- CreateSeuratObject(counts = object, project = condition_names[init_num],
                                 min.cells = min.cells,
                                 min.features = min.features,
                                 meta.data = data.frame(percent.mito = percent.mito,percent.rb=percent.rb))
    Seurat$stim <- condition_names[init_num]




    # ================= Standard pre-processing workflow (https://satijalab.org/seurat/v3.0/pbmc3k_tutorial.html)
    # QC and selecting cells for further analysis
    # Seurat[["percent.mt"]] <- PercentageFeatureSet(object = Seurat, pattern = "^MT-")
    # pdf(paste(Sys.Date(),"_QC_",Seurat$stim,"before.pdf",sep=""))
    # print(VlnPlot(object = Seurat, features = c("nFeature_RNA", "nCount_RNA", "percent.mito","percent.rb"), ncol = 4))
    # dev.off()
    #
    #
    # # # ================================= Outlier Detection ===================================
    # # # debugonce(Outlier_detection)
    # Outlier_object <- Outlier_detection(Seurat,outlier_detector=outlier_detector)
    # Seurat <- Outlier_object$object_filtered
    # oultliers_index <- Outlier_object$oultliers_index
    # # # ---------------------------------------------------------------------------------------

    # =================. Impute missing gene expressions with SAVER =========================
    if (imputation ==TRUE) {
        cat(green("\nImputation with SAVER\n"))
        allcells <- as.matrix(Seurat@assays$RNA@counts)
        library(SAVER)
        allcells[is.na(allcells)] <- 0
        cortex.saver <- saver(allcells, ncores = n_cores)
        allcells<-as.matrix(cortex.saver$estimate)
        allcells[is.na(allcells)] <- 0

        Seurat_imputed <- CreateSeuratObject(counts = allcells, project = condition_names[init_num],
                                     min.cells = min.cells,
                                     min.features = min.features,
                                     meta.data = data.frame(percent.mito = Seurat$percent.mito,percent.rb=Seurat$percent.rb))
        Seurat_imputed$stim <- condition_names[init_num]
        Seurat <- Seurat_imputed

    }
    # --------------------------------------------------------------------------------------

#
#     pdf(paste(Sys.Date(),"_QC_",Seurat$stim,"after.pdf",sep=""))
#     print(VlnPlot(object = Seurat, features = c("nFeature_RNA", "nCount_RNA", "percent.mito","percent.rb"), ncol = 4))
#     dev.off()
    # ----------------------------------------------

    # Seurat <- SCTransform(object = Seurat)
    # ====================== Normalization ====================
    Seurat <- NormalizeData(object = Seurat, normalization.method = "LogNormalize", scale.factor = 10000)
    # ----------------------------------------------


    # ====== Identification of highly variable features (feature selection)
    Seurat <- FindVariableFeatures(object = Seurat, selection.method = "vst", nfeatures = 5000)

    #Seurat <- ScaleData(object = Seurat, vars.to.regress = c("nUMI", "percent.mito"), display.progress = FALSE)

    # Identify the 10 most highly variable genes
    top10 <- head(x = VariableFeatures(object = Seurat), 10)

    # plot variable features with and without labels
    plot1 <- VariableFeaturePlot(object = Seurat)
    plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
    # CombinePlots(plots = list(plot1, plot2))
    pdf(paste(Sys.Date(),"_top10_var_feat_",Seurat$stim,".pdf"))
    print(plot2)
    dev.off()
    # ----------------------------------------------


    # Seurat[["percent.OPC"]]     <- PercentageFeatureSet(Seurat, features = c("OLIG1","OLIG2","PDGFRA"))
    # Seurat[["percent.Oligo"]]   <- PercentageFeatureSet(Seurat, features = c("MAG","MOG","PLP1","ERMN","ENPP6"))
    # Seurat[["percent.Astro"]]   <- PercentageFeatureSet(Seurat, features = c("AQP4","ALDOC","MLC1","SLC1A3","GJA1","NDRG2"))
    # Seurat[["percent.Micro"]]   <- PercentageFeatureSet(Seurat, features = c("TMEM119","TREM2","CCR5","LAPTM5","CTSS","AIF1","C1QA"))
    # Seurat[["percent.Neurons"]] <- PercentageFeatureSet(Seurat, features = c("GAD1","GAD2"))
    # Seurat[["percent.NSC"]]     <- PercentageFeatureSet(Seurat, features = c("TOP2A","BIRC5","CDK1"))


    # to merge sets to get all the relevant genes (to be filtered out later again!)
    # BUT HERE ONLY FOR THE 800 MOST EXPRESSING BARCODES!!! TOO EMPTY BEADS CONFUSES MONOCLE!!!
    # tm1 <- Org1[,c(1:number_of_cells)]
    tm1 <- Seurat
    print(dim(tm1))
    # tm_list[[init_num]]  <- tm1
    # init_num <- init_num + 1
    return(tm1)
}



#' Create a newCellDataSet  Monocle object.
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param list_of_files: elist of files to be load.
#' @param condition_names: call rate.
#' @param remove_mt: Remove mitochondrial genes (Default=TRUE).
#' @param gene_list_remove : Remove list of genes.
#' @param imputation: Impute missing gene expressions with SAVER (Default=FALSE).
#' @param na_threshold: Genes with number of missing values more than threshold deleted.
#' @param n_cores: number of cores to use for Parallel Quality Control.
#' @param elbow: Filtering based on the PCA variance explain elbow.
#' @param data_10x: Type of data (Default 10x=FALSE).
#' @param outlier_detector: Method to detect the outliers "MAD"/"MEAN" (Default="MAD").
#'
#' @return Monocle Cell Data Set
#' @return Gene expression Matrix
#' @examples create_cds(list_of_files,condition_names,data_10x=FALSE,outlier_detector="MAD")
create_cds <- function(list_of_files,condition_names,
    min.features=200,min.cells=5,
    remove_mt=TRUE,remove_rb=TRUE,
    outlier_detector="MAD",data_10x=FALSE,elbow=FALSE,imputation=FALSE,
    tool="Seurat",
    n_cores=2){

    # ============================== Checking the Parameters ====================================
    tic()
    cat(cyan("Selected Parameteres :\n")%+% paste("\tRemove Mitochondrial Genes : ",remove_mt,
                                                  "\n\tRemove Ribosomal genes : ",remove_rb,
                                                  "\n\tImputation : ",imputation,
                                                  "\n\t10xData : ",data_10x,
                                                  "\n\tElbow : ",elbow,
                                                  "\n\tOutlier Detector : ",outlier_detector) )
    cat(cyan("\n\nLoading Data : ")  %+% as.character(Sys.time()) %+% "\n" )
    tm_list <- list()
    init_num <- 1

    print("QC for every file")

    if (get_os()=="windows"){
        cat(yellow("Warning :")  %+% "Your os is Windows. The Parallel file reading is implemented only for UNIX/MAC\n")
        n_cores=1
    }
    # debugonce(read_file)
    tm_list <- mclapply(FUN=read_file,c(1:length(list_of_files)),
                                     list_of_files=list_of_files,
                                     condition_names=condition_names,
                                     data_10x=data_10x,
                                     elbow=elbow,
                                    imputation=imputation,
                                     outlier_detector=outlier_detector,
                                      min.features=min.features,
                                      min.cells=min.cells,
                                      mc.cores=n_cores)

    # =========================== Perform integration ==============================
    Seurat.anchors <- FindIntegrationAnchors(object.list = tm_list, dims = 1:20)
    Seurat.combined <- IntegrateData(anchorset = Seurat.anchors, dims = 1:20)
    # doi: https://doi.org/10.1101/576827
    # int.features <- SelectIntegrationFeatures(object.list = tm_list, nfeatures = 3000)
    # tm_list <- PrepSCTIntegration(object.list = tm_list, anchor.features = int.features,
    #                                     verbose = FALSE)
    # int.anchors <- FindIntegrationAnchors(object.list = tm_list, normalization.method = "SCT",
    #                                            anchor.features = int.features, verbose = FALSE)
    # Seurat.combined <- IntegrateData(anchorset = int.anchors, normalization.method = "SCT",
    #                                      verbose = FALSE)


    # =========================== Perform an integrated analysis ==========================
    DefaultAssay(object = Seurat.combined) <- "integrated"
    Seurat.combined$condition <- Idents(object = Seurat.combined)
    # -------------------------------------------------------------------------------------

    # ======================================== CELL Cycle ==========================================
    s.genes <- cc.genes$s.genes
    g2m.genes <- cc.genes$g2m.genes
    if(!g2m.genes%in%rownames(Seurat.combined@assays$integrated@data)){
        if(!s.genes%in%rownames(Seurat.combined@assays$integrated@data)){
        }
    }
    Seurat.combined <- CellCycleScoring(Seurat.combined, s.features = s.genes, g2m.features = g2m.genes)
    # -----------------------------------------------------------------------------------------------------


    object <- Seurat.combined
    if(tolower(tool)=="monocle"){
       object <- seurat_to_monocle(object)
    }
    return(list("Combined"=object,"Data_List"=tm_list))
}
# ----------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------










# =============================================================================================
# =============================================================================================
# =============================================================================================
# =============================================================================================
# =============================================================================================







#' Read Files
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param list_of_files: elist of files to be load.
#' @param condition_names: call rate.
#' @param remove_mt: Remove mitochondrial genes (Default=TRUE).
#' @param gene_list_remove : Remove list of genes.
#' @param imputation: Impute missing gene expressions with SAVER (Default=FALSE).
#' @param na_threshold: Genes with number of missing values more than threshold deleted.
#' @param n_cores: number of cores to use for Parallel Quality Control.
#' @param elbow: Filtering based on the PCA variance explain elbow.
#' @param data_10x: Type of data (Default 10x=FALSE).
#' @param outlier_detector: Method to detect the outliers "MAD"/"MEAN" (Default="MAD").
#'
#' @return Monocle Cell Data Set
#' @return Gene expression Matrix
#' @examples create_cds(list_of_files,condition_names,data_10x=FALSE,outlier_detector="MAD")
read_file2 <- function(iter_qc,list_of_files,condition_names,min.features=200,min.cells=5,remove_mt=TRUE,remove_rb=TRUE,outlier_detector="MAD",data_10x=FALSE,elbow=FALSE,imputation=FALSE,tool="Seurat"){
    init_num <- iter_qc
    file <- list_of_files[iter_qc]
    # ============== Load File ===============
    object <- load_files(file = file,data_10x=data_10x)
    # ----------------------------------------

    #============== ELBOW ====================
    if(elbow==TRUE){
        object <- elbow_calc(object,condition_names,iter_qc)
    }
    # ----------------------------------------



    # ================================= Outlier Detection ===================================
    # debugonce(Advanced_Outlier_detection)
    Outlier_object <- Advanced_Outlier_detection(object,condition= condition_names[init_num])
    object <- Outlier_object$object_filtered
    oultliers_index <- Outlier_object$oultliers_index
    # ---------------------------------------------------------------------------------------

    # #============== Metrics Calculation  ====================
    metrics_output <- metrics_calc(object=object,remove_mt=remove_mt,remove_rb=remove_rb)
    object <- metrics_output$object
    percent.mito <- metrics_output$percent.mito
    percent.rb <-  metrics_output$percent.rb
    # -------------------------------------------------------

    #object<- remove_genes(object)

    Seurat <- CreateSeuratObject(counts = object, project = condition_names[init_num],
                                 min.cells = min.cells,
                                 min.features = min.features,
                                 meta.data = data.frame(percent.mito = percent.mito,percent.rb=percent.rb))
    Seurat$stim <- condition_names[init_num]



    # =================. Impute missing gene expressions with SAVER =========================
    if (imputation ==TRUE) {
        cat(green("\nImputation with SAVER\n"))
        allcells <- as.matrix(Seurat@assays$RNA@counts)
        library(SAVER)
        allcells[is.na(allcells)] <- 0
        cortex.saver <- saver(allcells, ncores = n_cores)
        allcells<-as.matrix(cortex.saver$estimate)
        allcells[is.na(allcells)] <- 0

        Seurat_imputed <- CreateSeuratObject(counts = allcells, project = condition_names[init_num],
                                             min.cells = min.cells,
                                             min.features = min.features,
                                             meta.data = data.frame(percent.mito = Seurat$percent.mito,percent.rb=Seurat$percent.rb))
        Seurat_imputed$stim <- condition_names[init_num]
        Seurat <- Seurat_imputed

    }
    # --------------------------------------------------------------------------------------

    # ============== Normalization =========================== #
    # https://doi.org/10.1101/576827
    # Seurat <- SCTransform(object = Seurat)
    # ====================== Normalization ====================
    Seurat <- NormalizeData(object = Seurat, normalization.method = "LogNormalize", scale.factor = 10000)
    # ----------------------------------------------


    # ====== Identification of highly variable features (feature selection)
    Seurat <- FindVariableFeatures(object = Seurat, selection.method = "vst", nfeatures = 5000)

    # Identify the 10 most highly variable genes
    top10 <- head(x = VariableFeatures(object = Seurat), 10)

    # plot variable features with and without labels
    plot1 <- VariableFeaturePlot(object = Seurat)
    plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
    # CombinePlots(plots = list(plot1, plot2))
    pdf(paste(Sys.Date(),"_top10_var_feat_",Seurat$stim,".pdf"))
    print(plot2)
    dev.off()
    # ----------------------------------------------


    tm1 <- Seurat
    print(dim(tm1))
    return(tm1)
}





#' Create a newCellDataSet  Monocle object.
#' @author Dimitrios Kyriakis
#' @export
#'
#' @param list_of_files: elist of files to be load.
#' @param condition_names: call rate.
#' @param remove_mt: Remove mitochondrial genes (Default=TRUE).
#' @param gene_list_remove : Remove list of genes.
#' @param imputation: Impute missing gene expressions with SAVER (Default=FALSE).
#' @param na_threshold: Genes with number of missing values more than threshold deleted.
#' @param n_cores: number of cores to use for Parallel Quality Control.
#' @param elbow: Filtering based on the PCA variance explain elbow.
#' @param data_10x: Type of data (Default 10x=FALSE).
#' @param outlier_detector: Method to detect the outliers "MAD"/"MEAN" (Default="MAD").
#'
#' @return Monocle Cell Data Set
#' @return Gene expression Matrix
#' @examples create_cds(list_of_files,condition_names,data_10x=FALSE,outlier_detector="MAD")
create_cds2 <- function(list_of_files,condition_names,
                       min.features=200,min.cells=5,
                       remove_mt=TRUE,remove_rb=TRUE,
                       outlier_detector="MAD",data_10x=FALSE,elbow=FALSE,imputation=FALSE,
                       tool="Seurat",
                       n_cores=2){

    # ============================== Checking the Parameters ====================================
    tic()
    cat(cyan("Selected Parameteres :\n")%+% paste("\tRemove Mitochondrial Genes : ",remove_mt,
                                                  "\n\tRemove Ribosomal genes : ",remove_rb,
                                                  "\n\tImputation : ",imputation,
                                                  "\n\t10xData : ",data_10x,
                                                  "\n\tElbow : ",elbow,
                                                  "\n\tOutlier Detector : ",outlier_detector) )
    cat(cyan("\n\nLoading Data : ")  %+% as.character(Sys.time()) %+% "\n" )
    tm_list <- list()
    init_num <- 1

    print("QC for every file")

    if (get_os()=="windows"){
        cat(yellow("Warning :")  %+% "Your os is Windows. The Parallel file reading is implemented only for UNIX/MAC\n")
        n_cores=1
    }


    tm_list <- mclapply(FUN=read_file2,c(1:length(list_of_files)),
                        list_of_files=list_of_files,
                        condition_names=condition_names,
                        data_10x=data_10x,
                        elbow=elbow,
                        imputation=imputation,
                        outlier_detector=outlier_detector,
                        min.features=min.features,
                        min.cells=min.cells,
                        mc.cores=n_cores)

    # =========================== Perform integration ==============================

    #========================== ADDED REMOVE UNIQUE GENES =========================
    if(length(list_of_files)>1){

        Seurat.anchors <- FindIntegrationAnchors(object.list = tm_list, dims = 1:20)
        Seurat.combined <- IntegrateData(anchorset = Seurat.anchors, dims = 1:20)
        # doi: https://doi.org/10.1101/576827
        # int.features <- SelectIntegrationFeatures(object.list = tm_list, nfeatures = 3000)
        # tm_list <- PrepSCTIntegration(object.list = tm_list, anchor.features = int.features,
        #                                     verbose = FALSE)
        # int.anchors <- FindIntegrationAnchors(object.list = tm_list, normalization.method = "SCT",
        #                                            anchor.features = int.features, verbose = FALSE)
        # Seurat.combined <- IntegrateData(anchorset = int.anchors, normalization.method = "SCT",
        #                                      verbose = FALSE)


        # =========================== Perform an integrated analysis ==========================
        DefaultAssay(object = Seurat.combined) <- "integrated"
        Seurat.combined$condition <- Idents(object = Seurat.combined)
        # -------------------------------------------------------------------------------------
    }else{
        Seurat.combined <- tm_list[[1]]
        Seurat.combined$condition <- Idents(object = Seurat.combined)
    }
    # -----------------------------------------------------------------------------



    # ======================================== CELL Cycle ==========================================
    s.genes <- cc.genes$s.genes
    g2m.genes <- cc.genes$g2m.genes
    if(!g2m.genes%in%rownames(Seurat.combined@assays$integrated@data)){
        if(!s.genes%in%rownames(Seurat.combined@assays$integrated@data)){
        }
    }
    Seurat.combined <- CellCycleScoring(Seurat.combined, s.features = s.genes, g2m.features = g2m.genes)
    # -----------------------------------------------------------------------------------------------------


    object <- Seurat.combined
    if(tolower(tool)=="monocle"){
        object <- seurat_to_monocle(object)
    }
    return(list("Combined"=object,"Data_List"=tm_list))
}
# ----------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------





# ======================= NOT READY

#' Keep the genes that are exist in all dataset
#' @author Dimitrios Kyriakis
# #' @export
#'
#' @param list_of_files: elist of files to be load.
#' @param condition_names: call rate.
#' @param remove_mt: Remove mitochondrial genes (Default=TRUE).
#' @param gene_list_remove : Remove list of genes.
#' @param imputation: Impute missing gene expressions with SAVER (Default=FALSE).
#' @param na_threshold: Genes with number of missing values more than threshold deleted.
#' @param n_cores: number of cores to use for Parallel Quality Control.
#' @param elbow: Filtering based on the PCA variance explain elbow.
#' @param data_10x: Type of data (Default 10x=FALSE).
#' @param outlier_detector: Method to detect the outliers "MAD"/"MEAN" (Default="MAD").
#'
#' @return Monocle Cell Data Set
#' @return Gene expression Matrix
#' @examples create_cds(list_of_files,condition_names,data_10x=FALSE,outlier_detector="MAD")
keep_universe <- function(file,condition_names,
                        min.features=200,min.cells=5,
                        remove_mt=TRUE,remove_rb=TRUE,
                        outlier_detector="MAD",data_10x=FALSE,elbow=FALSE,imputation=FALSE,
                        tool="Seurat",
                        n_cores=2){
    if(data_10x){
        print(file)
        barcode.path <- paste0(file, "barcodes.tsv")
        features.path <- paste0(file, "features.tsv")
        matrix.path <- paste0(file, "matrix.mtx")
        mat <- as.matrix(readMM(file = matrix.path))
        feature.names = read.delim(features.path, header = FALSE, stringsAsFactors = FALSE)
        barcode.names = read.delim(barcode.path, header = FALSE, stringsAsFactors = FALSE)
        colnames(mat) = barcode.names$V1
        rownames(mat) = feature.names$V2
        object <- mat[,order(colSums(as.matrix(mat)),decreasing=T)]
    }else{
        print(file)
        object <- read.csv(file,header=T,row.names=1, sep='\t')
        object <- object[,order(colSums(object),decreasing=T)]
    }
    # = Change the cases to UPPER and - to dots
    rows_nms <- str_replace_all( toupper(rownames(object)),"-",".")
    rownames(object) <- rows_nms
    return(list("object"=object,"rownames"=rownames(object)))
}




#' Read Files
#' @author Dimitrios Kyriakis
# #' @export
#'
#' @param list_of_files: elist of files to be load.
#' @param condition_names: call rate.
#' @param remove_mt: Remove mitochondrial genes (Default=TRUE).
#' @param gene_list_remove : Remove list of genes.
#' @param imputation: Impute missing gene expressions with SAVER (Default=FALSE).
#' @param na_threshold: Genes with number of missing values more than threshold deleted.
#' @param n_cores: number of cores to use for Parallel Quality Control.
#' @param elbow: Filtering based on the PCA variance explain elbow.
#' @param data_10x: Type of data (Default 10x=FALSE).
#' @param outlier_detector: Method to detect the outliers "MAD"/"MEAN" (Default="MAD").
#'
#' @return Monocle Cell Data Set
#' @return Gene expression Matrix
#' @examples create_cds(list_of_files,condition_names,data_10x=FALSE,outlier_detector="MAD")
read_file3 <- function(object,iter_qc,condition_names,min.features=200,min.cells=5,remove_mt=TRUE,remove_rb=TRUE,outlier_detector="MAD",data_10x=FALSE,elbow=FALSE,imputation=FALSE,tool="Seurat"){
    object <- object[[iter_qc]]$object
    init_num <- iter_qc
    # ----------------------------------------

    # ============ Keep Universe =============
    object <- object[rownames(object)%in%universe,]
    # ----------------------------------------


    #============== ELBOW ====================
    if(elbow==TRUE){
        object <- elbow_calc(object,condition_names,iter_qc)
    }
    # ----------------------------------------



    # ================================= Outlier Detection ===================================
    # debugonce(Advanced_Outlier_detection)
    Outlier_object <- Advanced_Outlier_detection(object,condition= condition_names[init_num])
    object <- Outlier_object$object_filtered
    oultliers_index <- Outlier_object$oultliers_index
    # ---------------------------------------------------------------------------------------

    # #============== Metrics Calculation  ====================
    metrics_output <- metrics_calc(object=object,remove_mt=remove_mt,remove_rb=remove_rb)
    object <- metrics_output$object
    percent.mito <- metrics_output$percent.mito
    percent.rb <-  metrics_output$percent.rb
    # -------------------------------------------------------

    #object<- remove_genes(object)

    Seurat <- CreateSeuratObject(counts = object, project = condition_names[init_num],
                                 min.cells = min.cells,
                                 min.features = min.features,
                                 meta.data = data.frame(percent.mito = percent.mito,percent.rb=percent.rb))
    Seurat$stim <- condition_names[init_num]



    # =================. Impute missing gene expressions with SAVER =========================
    if (imputation ==TRUE) {
        cat(green("\nImputation with SAVER\n"))
        allcells <- as.matrix(Seurat@assays$RNA@counts)
        library(SAVER)
        allcells[is.na(allcells)] <- 0
        cortex.saver <- saver(allcells, ncores = n_cores)
        allcells<-as.matrix(cortex.saver$estimate)
        allcells[is.na(allcells)] <- 0

        Seurat_imputed <- CreateSeuratObject(counts = allcells, project = condition_names[init_num],
                                             min.cells = min.cells,
                                             min.features = min.features,
                                             meta.data = data.frame(percent.mito = Seurat$percent.mito,percent.rb=Seurat$percent.rb))
        Seurat_imputed$stim <- condition_names[init_num]
        Seurat <- Seurat_imputed

    }
    # --------------------------------------------------------------------------------------

    # ============== Normalization =========================== #
    # https://doi.org/10.1101/576827
    # Seurat <- SCTransform(object = Seurat)
    # ====================== Normalization ====================
    Seurat <- NormalizeData(object = Seurat, normalization.method = "LogNormalize", scale.factor = 10000)
    # ----------------------------------------------


    # ====== Identification of highly variable features (feature selection)
    Seurat <- FindVariableFeatures(object = Seurat, selection.method = "vst", nfeatures = 5000)

    # Identify the 10 most highly variable genes
    top10 <- head(x = VariableFeatures(object = Seurat), 10)

    # plot variable features with and without labels
    plot1 <- VariableFeaturePlot(object = Seurat)
    plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
    # CombinePlots(plots = list(plot1, plot2))
    pdf(paste(Sys.Date(),"_top10_var_feat_",Seurat$stim,".pdf"))
    print(plot2)
    dev.off()
    # ----------------------------------------------


    tm1 <- Seurat
    print(dim(tm1))
    return(tm1)
}




#' Create a newCellDataSet  Monocle object.
#' @author Dimitrios Kyriakis
# #' @export
#'
#' @param list_of_files: elist of files to be load.
#' @param condition_names: call rate.
#' @param remove_mt: Remove mitochondrial genes (Default=TRUE).
#' @param gene_list_remove : Remove list of genes.
#' @param imputation: Impute missing gene expressions with SAVER (Default=FALSE).
#' @param na_threshold: Genes with number of missing values more than threshold deleted.
#' @param n_cores: number of cores to use for Parallel Quality Control.
#' @param elbow: Filtering based on the PCA variance explain elbow.
#' @param data_10x: Type of data (Default 10x=FALSE).
#' @param outlier_detector: Method to detect the outliers "MAD"/"MEAN" (Default="MAD").
#'
#' @return Monocle Cell Data Set
#' @return Gene expression Matrix
#' @examples create_cds(list_of_files,condition_names,data_10x=FALSE,outlier_detector="MAD")
create_cds3 <- function(list_of_files,condition_names,
                        min.features=200,min.cells=5,
                        remove_mt=TRUE,remove_rb=TRUE,
                        outlier_detector="MAD",data_10x=FALSE,elbow=FALSE,imputation=FALSE,
                        tool="Seurat",
                        n_cores=2){

    # ============================== Checking the Parameters ====================================
    tic()
    cat(cyan("Selected Parameteres :\n")%+% paste("\tRemove Mitochondrial Genes : ",remove_mt,
                                                  "\n\tRemove Ribosomal genes : ",remove_rb,
                                                  "\n\tImputation : ",imputation,
                                                  "\n\t10xData : ",data_10x,
                                                  "\n\tElbow : ",elbow,
                                                  "\n\tOutlier Detector : ",outlier_detector) )
    cat(cyan("\n\nLoading Data : ")  %+% as.character(Sys.time()) %+% "\n" )
    tm_list <- list()
    init_num <- 1

    print("QC for every file")

    if (get_os()=="windows"){
        cat(yellow("Warning :")  %+% "Your os is Windows. The Parallel file reading is implemented only for UNIX/MAC\n")
        n_cores=1
    }

    #================ Read  Files ==============
    read_files <- mclapply(list_of_files,FUN=keep_universe,mc.cores=n_cores)
    # ------------------------------------------

    # ============== Extract Universe ==========
    universe <-c(read_files[[1]]$rownames)
    for(i in 2:length(read_files)){
        universe<-intersect.Vector(universe,read_files[[i]]$rownames)
        print(length(read_files[[i]]$rownames))
    }
    for(i in read_files){
        read_files$object <- read_files$object[rownames(read_files$object) %in% universe,]
    }
    # ------------------------------------------


    tm_list <- mclapply(FUN=read_file3,iter_qc=c(1:length(list_of_files)),
                        read_files,
                        condition_names=condition_names,
                        data_10x=data_10x,
                        elbow=elbow,
                        imputation=imputation,
                        outlier_detector=outlier_detector,
                        min.features=min.features,
                        min.cells=min.cells,
                        mc.cores=n_cores)

    # =========================== Perform integration ==============================

    #========================== ADDED REMOVE UNIQUE GENES =========================
    if(length(list_of_files)>1){

        Seurat.anchors <- FindIntegrationAnchors(object.list = tm_list, dims = 1:20)
        Seurat.combined <- IntegrateData(anchorset = Seurat.anchors, dims = 1:20)
        # doi: https://doi.org/10.1101/576827
        # int.features <- SelectIntegrationFeatures(object.list = tm_list, nfeatures = 3000)
        # tm_list <- PrepSCTIntegration(object.list = tm_list, anchor.features = int.features,
        #                                     verbose = FALSE)
        # int.anchors <- FindIntegrationAnchors(object.list = tm_list, normalization.method = "SCT",
        #                                            anchor.features = int.features, verbose = FALSE)
        # Seurat.combined <- IntegrateData(anchorset = int.anchors, normalization.method = "SCT",
        #                                      verbose = FALSE)


        # =========================== Perform an integrated analysis ==========================
        DefaultAssay(object = Seurat.combined) <- "integrated"
        Seurat.combined$condition <- Idents(object = Seurat.combined)
        # -------------------------------------------------------------------------------------
    }else{
        Seurat.combined <- tm_list[[1]]
        Seurat.combined$condition <- Idents(object = Seurat.combined)
    }
    # -----------------------------------------------------------------------------



    # ======================================== CELL Cycle ==========================================
    s.genes <- cc.genes$s.genes
    g2m.genes <- cc.genes$g2m.genes
    if(!g2m.genes%in%rownames(Seurat.combined@assays$integrated@data)){
        if(!s.genes%in%rownames(Seurat.combined@assays$integrated@data)){
        }
    }
    Seurat.combined <- CellCycleScoring(Seurat.combined, s.features = s.genes, g2m.features = g2m.genes)
    # -----------------------------------------------------------------------------------------------------


    object <- Seurat.combined
    if(tolower(tool)=="monocle"){
        object <- seurat_to_monocle(object)
    }
    return(list("Combined"=object,"Data_List"=tm_list))
}
# ----------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------


