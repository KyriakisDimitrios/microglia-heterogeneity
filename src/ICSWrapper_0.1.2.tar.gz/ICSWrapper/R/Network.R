#' Build Networks PC, MMHC, Partial Correlation based on FS Network
#'
#' @author Dimitrios Kyriakis
#' @export
#' @param dataset : A Matrix with columns the nodes
#' @param node : Optional a list of gene to plot the local network
#'
#' @return Three different networks
#' @examples network_MXM(heat_matrix)
#'
network_MXM <- function(dataset,node=c()){
    require(MXM)
    require(visNetwork)
    # require(visSave)
    dir.create("Network")
    setwd("Network")
    if (length(node)==0){
        ### ~ ~ ~ Running MMHC skeleton with MMPC ~ ~ ~ ###
        MmhcSkeleton <- MXM::mmhc.skel(dataset    = dataset, max_k      = 3,
                                       threshold  = 0.05, test       = "testIndFisher",
                                       type       = "MMPC",  backward   = TRUE,
                                       symmetry   = TRUE, nc=6,
                                       ini.pvalue = NULL, hash       = TRUE)

        ### ~ ~ ~ Running PC skeleton  ~ ~ ~ ###
        PcSkeleton <- MXM::pc.skel(dataset= as.matrix(dataset), method= "pearson" ,alpha       = 0.01,
                                   rob       = FALSE)

        ### ~ ~ ~  Running FS skeleton  ~ ~ ~ ###
        # FSSkeleton <- MXM::corfs.network(x = as.matrix(dataset), threshold  = 0.05,
        #                                  symmetry = TRUE,  tolb       = 2,
        #                                  tolr = 0.02, stopping   = "BICR2", nc = 1)
        #
        # ============ PLOTTING ================
        plotnetwork_dim(MmhcSkeleton$G[colSums(MmhcSkeleton$G)!=0,rowSums(MmhcSkeleton$G)!=0], "MMHC with MMPC Network") %>% visSave(file="MMHC_Network.html", selfcontained = TRUE, background = "white")
        plotnetwork_dim(PcSkeleton$G[colSums(PcSkeleton$G)!=0,rowSums(PcSkeleton$G)!=0], "PC Network") %>% visSave(file="PC_Network2.html", selfcontained = TRUE, background = "white")
        plotnetwork_dim(PcSkeleton$G, "PC Network") %>% visSave(file="PC_Network.html", selfcontained = TRUE, background = "white")


        # plotnetwork_dim(FSSkeleton$G, "Partial Correlation based on FS Network")%>% visSave(file="PCFS_Network.html", selfcontained = TRUE, background = "white")

    }else{
        temp_fun <-function(x){
          node_n <- match(x,colnames(dataset))
          MmhcSkeleton <- local.mmhc.skel(dataset, node=node_n, max_k = 3, threshold = 0.05, test = "testIndFisher")
          plotnetwork_dim(MmhcSkeleton$G, paste0(x," Local Network"))%>% visSave(file=paste0(x,"_MMHC_Network.html"), selfcontained = TRUE, background = "white")
          return(MmhcSkeleton)
        }
        MmhcSkeleton <-lapply(node,temp_fun)
    }

    setwd("../")
    return(list("MmhcSkeleton"=MmhcSkeleton,"PcSkeleton"=PcSkeleton))
}




#' plotnetwork_dim
#'
#' @author Dimitrios Kyriakis
#' @export
plotnetwork_dim <- function(G, titlos = NULL) {
    # Some changes of the MXM plotnetwork
    if ( sum(G) > 0 ) {

        if ( is.null( colnames(G) ) ) {
          nam <- colnames(G) <- rownames(G) <- paste("X", 1:dim(G)[2])
        }  else  nam <- colnames(G)

        nodes <- data.frame(id = nam)

        if ( sum( abs( G - t(G) ) ) == 0 ) { ## no orientations
          ed <- which(G > 0, arr.ind = TRUE)
          ed <- unique( t( Rfast::sort_mat( t(ed) ) ) )
          edges <- data.frame( from = nam[ed[, 1]], to = nam[ed[, 2]], type = numeric( dim(ed)[1] ) )

        } else {
          ed1 <- which(G == 2, arr.ind = TRUE)
          ed0 <- which(G == 1, arr.ind = TRUE)
          ed0 <- unique( t( Rfast::sort_mat( t(ed0) ) ) )
          ed <- rbind(ed1, ed0)
          edges <- data.frame( from = nam[ed[, 1]], to = nam[ed[, 2]], type = c(numeric( dim(ed1)[1] ) + 1, numeric( dim(ed0)[1] )) )
        }

        id = paste(nodes[1:dim(nodes)[1], 1])

        nodesprint <- data.frame( id = id,
                                  title = id, #on hover
                                  label = id, #current label
                                  shape = c("dot"),
                                  mass = 1,
                                  size = 40,
                                  shadow = TRUE,
                                  #color = c("#1abc9c"),
                                  physics = TRUE, font = "50px" )

        from <- edges$from
        to <- edges$to
        type <- edges$type
        a <- type
        a[type == 1] = "to"
        a[type == 0] = ""

        edgesprint <- data.frame(from = from,
                                 to = to,
                                 #title = weight, #on hover
                                 smooth = FALSE,
                                 width = 3,
                                 shadow = TRUE,
                                 arrows = a, #determine the type of the edges here with a vector of length as the number of edges
                                 color = list(highlight = "red", hover = "green"),
                                 physics = FALSE
        )

    } else  edges <- NULL

    if(is.null(edges)){
        return();
    }else{
        if ( is.null(titlos) )   titlos <- "Network"
        visNetwork::visNetwork(nodesprint, edgesprint, width = "100%", height = "1200px", main = titlos) %>%
        visNetwork::visPhysics(minVelocity = 1, maxVelocity = 50,repulsion = list(nodeDistance = 200, centralGravity = 10000), barnesHut = list(gravitationalConstant = -16000)) %>%
        visNetwork::visInteraction(navigationButtons = TRUE,hover = TRUE, hoverConnectedEdges = TRUE) %>%
        visNetwork::visOptions(nodesIdSelection = list(enabled = TRUE))
    }
}
