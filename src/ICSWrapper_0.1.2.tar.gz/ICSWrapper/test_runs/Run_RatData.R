library(ICSWrapper)
# === General Libs
# library(useful)
# library(crayon)
# library(parallel)
# library(tictoc)
# library(stringr)

# library(monocle)
# library(Seurat)
# library(garnett)

# library(dplyr)
# library(cowplot)
# library(NMF)
# library(RColorBrewer) # for color definition
# library(jcolors)
# library(ggplot2)
# library(crayon)
# library(Routliers)
# library(slingshot)
# library(Matrix)
# library(ecp)
# library(ggplot2)
# library(ggpubr)

# # == Network
# require(MXM)
# require(visNetwork)



set.seed(123)
tool="seurat"
# tool="monocle"
# args = commandArgs(trailingOnly=TRUE)
# project<-args[1]
project ="RAT_Data"
# project ="MBSYN"
# project ="Michi_Data"
dataset <- project
Data_select <- data_selection(project)

WORKDIR <- Data_select$WORKDIR
list_of_files <- Data_select$list_of_files
condition_names <- Data_select$condition_names
organism<- Data_select$organism
file<- Data_select$file
data_10x<- Data_select$data_10x

setwd(Data_select$WORKDIR)



colormap_d<- c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928',"black","gray")
color_cond  <- c(brewer.pal(8,"Dark2"),"black","gray","magenta4","seagreen4")
color_clust <- c(brewer.pal(12,"Paired")[-11],"black","gray","magenta4","seagreen4",brewer.pal(9,"Set1"))
color_cells <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")
color_list <- list(condition=color_cond,Cluster=color_clust,Cell_Type=color_cells,State=color_clust)
# color_cells <-primary.colors(15, steps = 3, no.white = TRUE)



# ================================ SETTING UP ======================================== #
# Number of cells to use
imputation = FALSE
remove_mt=TRUE
remove_ribsomal=TRUE
n_cores=4
elbow = TRUE


NewDir <- paste0(Sys.Date(),"_",tool,"_elbow_",elbow)

dir.create(NewDir)
setwd(NewDir)



# ==============================================================================================
# ================================ Setup the Seurat objects ====================================
# ==============================================================================================
# ======== Perform an integrated analysis ====
dir.create("QC")
setwd("QC")
# debugonce(create_cds)
Return_fun <- create_cds3(list_of_files=list_of_files,
                         condition_names=condition_names,
                         min.features =200,min.cells=5,remove_mt=TRUE,data_10x=data_10x, elbow = elbow,tool=tool,n_cores=1)

Combined  <- Return_fun$Combined
Data_List <- Return_fun$Data_List
setwd("../")
# ----------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------

saveRDS(Combined,paste0("Merged_",NewDir,".rds"))

# ==============================================================================================
# ======================================= Clustering  ==========================================
# ==============================================================================================
dir.create("Clustering")
setwd("Clustering")
# Combined <- ReduceDim(Combined,method="umap",project=project)$Combined
# debugonce(reduce_dim)
Combined <- reduce_dim(Combined,project=project)$Combined#,resolution=c(0.1))$Combined

pdf(paste(Sys.Date(),project,"tsne","Conditions.pdf",sep="_"))
plot_cells(Combined,target="condition",leg_pos="right",save=TRUE,ncol=1)
dev.off()
pdf(paste(Sys.Date(),project,"tsne","Cluster.pdf",sep="_"))
# debugonce(plot_cells)
plot_cells(Combined,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
dev.off()


plot_nFeatures(Combined,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)
plot_tot_mRNA(Combined,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)


if(tolower(tool)=="seurat" & elbow){
    p3 <- DimPlot(object = Combined, reduction = "umap", group.by = "condition",cols = color_cond)
    p4 <- DimPlot(object = Combined, reduction = "umap", label = TRUE,cols = color_clust)
    pdf(paste(Sys.Date(),project,"umap","Seurat_Conditions.pdf",sep="_"))
    print(p3)
    dev.off()
    pdf(paste(Sys.Date(),project,"umap","Seurat_Clusters.pdf",sep="_"))
    print(p4)
    dev.off()
}

# ------------------------------------------------------------------------------------------------

setwd("../")
saveRDS(Combined,paste0("Clustered_",NewDir,".rds"))

# Combined <- readRDS(paste0("Clustered_",NewDir,".rds"))

# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
# debugonce(df_genes)
return_fun <- df_genes(Combined,"condition",top_n=15,logfc.threshold=0.25, n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------

# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
return_fun <- df_genes(Combined,"Cluster",top_n=15,logfc.threshold=0.25, n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------



#
# dir.create("Cell_Types_Garnett")
# setwd("Cell_Types_Garnett")
# Combined <- garnett_assignment(Combined ,organism="rat",check_markers=FALSE)
# Combined <- garnett_assignment(Combined ,organism="skata",check_markers=FALSE)
# pdf("Garnett_Cell_type.pdf")
# plot_cells(Combined,target="cell_type")
# plot_cells(Combined,target="cluster_ext_type")
# plot_cells(Combined,target="garnett_cluster")
# dev.off()
# setwd("../")





# =================================== CELL TYPES =================================================
dir.create("Cell_Types_Gab")
setwd("Cell_Types_Gab")
gene_list_name <- "Cell_Type"
file="C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Rat_DATA/Gene_lists/Cell_Types.txt"
# debugonce(cell_type_assignment)
res_cell_type_assignment <- cell_type_assignment(object=Combined,tab_name="Cell_Type",file=file)

Combined = res_cell_type_assignment$object
r_annot = res_cell_type_assignment$r_annot
gene_list <- c("P2RY12","GJA1","OLIG1","GAD2","IGF2","CCDC153")
plot_bar_cells(gene_list,object=Combined,save=TRUE)
pie_per_CellType(Combined,target="Cell_Type")
setwd("../")
# ------------------------------------------------------------------------------------------------


# =================================== CELL TYPES =================================================
dir.create("Cell_Types")
setwd("Cell_Types")
gene_list_name <- "Cell_Type"
file="C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Rat_DATA/Gene_lists/Paper_Gene_List.txt"
# debugonce(cell_type_assignment)
res_cell_type_assignment <- cell_type_assignment(object=Combined,tab_name="Cell_Type",file=file)

Combined = res_cell_type_assignment$object
r_annot = res_cell_type_assignment$r_annot
gene_list <- c("P2RY12","GJA1","OLIG1","GAD2","IGF2","CCDC153")
plot_bar_cells(gene_list,object=Combined,save=TRUE)
pie_per_CellType(Combined,target="Cell_Type")
setwd("../")
# ------------------------------------------------------------------------------------------------

saveRDS(Combined,paste0("Cell_Types_",NewDir,".rds"))


if(tolower(tool)=="seurat"&!elbow){
    cell_types <- Combined$Cell_Type
    save_cell_types<-Combined$Cell_Type
    cell_types[ which(Combined$Cluster %in% c(4,11))] <- "Microglia"
    cell_types[ which(Combined$Cluster %in% c(0,5,7,10))] <- "Oligodendrocytes"
    cell_types[ which(Combined$Cluster %in% c(3,8))] <- "Astrocytes"
    cell_types[ which(Combined$Cluster %in% c(2,6))] <- "NSC"
    cell_types[ which(Combined$Cluster %in% c(1,13))] <- "Neurons"
    cell_types[ which(Combined$Cluster %in% c(9))] <- "Vascular"
    # cell_types[ which(Combined$Cluster %in% c(13))] <- "Unknown"
    cell_types[ which(Combined$Cluster %in% c(12))] <- "Endothelial"
    cell_types[ which(Combined$Cluster %in% c(14))] <- "Ependymal"
    # cell_types[ which(Combined$Cluster %in% c(2))] <- "Hybrid"
    Combined$Cell_Type <-cell_types
}
if(tolower(tool)=="seurat"&elbow){
    cell_types <- Combined$Cell_Type
    save_cell_types<-Combined$Cell_Type
    cell_types[ which(Combined$Cluster %in% c(0))] <- "Microglia"
    cell_types[ which(Combined$Cluster %in% c(1,4,8,9,10,13))] <- "Oligodendrocytes"
    cell_types[ which(Combined$Cluster %in% c(2,5))] <- "Astrocytes"
    cell_types[ which(Combined$Cluster %in% c(3,7))] <- "NSC"
    cell_types[ which(Combined$Cluster %in% c(6,11))] <- "Neurons"
    cell_types[ which(Combined$Cluster %in% c(12))] <- "Vascular"
    # cell_types[ which(Combined$Cluster %in% c(13))] <- "Unknown"
    cell_types[ which(Combined$Cluster %in% c(14))] <- "Endothelial"
    cell_types[ which(Combined$Cluster %in% c(15))] <- "Ependymal"
    cell_types[ which(Combined$Cluster %in% c(16))] <- "Hybrid"
    Combined$Cell_Type <-cell_types
}
if(tool=="monocle"&elbow){
    cell_types <- Combined$Cell_Type
    save_cell_types<-Combined$Cell_Type
    cell_types[ which(Combined$Cluster %in% c(5))] <- "Microglia"
    cell_types[ which(Combined$Cluster %in% c(1,3,6))] <- "Oligodendrocytes"
    cell_types[ which(Combined$Cluster %in% c(2))] <- "Astrocytes"
    cell_types[ which(Combined$Cluster %in% c(4))] <- "Neurons"
    Combined$Cell_Type <-cell_types
}


p1 <- plot_cells(Combined,target="condition",leg_pos="right",save=TRUE,ncol=1)
p2 <-plot_cells(Combined,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
p3 <-plot_cells(Combined,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1)

pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

pdf(paste(Sys.Date(),project,"Cell_Type_tsne.pdf",sep="_"))
print(p3)
dev.off()
pdf(paste(Sys.Date(),project,"Condition_tsne.pdf",sep="_"))
print(p1)
dev.off()
pdf(paste(Sys.Date(),project,"Cluster_tsne.pdf",sep="_"))
print(p2)
dev.off()


gene_list <- c("P2RY12","GJA1","OLIG1","GAD2","STMN3","NSG2","DLX1","CCDC153")
plot_bar_cells(gene_list,object=Combined,save=TRUE)
pie_per_CellType(Combined,target="Cell_Type")

# ======================================== Oligodendrocytes Analysis  =================================
dir.create("Oligodendrocytes_Analysis")
setwd("Oligodendrocytes_Analysis")
#debugonce(object_subset)
Oligo_Sub <- object_subset(object=Combined,Conditions=NULL,Clusters=NULL,Cell_Types=c("Oligodendrocytes"))
# Olig_sub <-sub_pop_analysis(Combined, "Oligodendrocytes", target="Cell_Type",top_n=30 ,logfc.threshold=0.25,organism=organism)


p1 <- plot_cells(Oligo_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1)
p2 <-plot_cells(Oligo_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
p3 <-plot_cells(Oligo_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1 )
pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

pdf(paste(Sys.Date(),project,"Cell_Type_tsne.pdf",sep="_"))
print(p3)
dev.off()
pdf(paste(Sys.Date(),project,"Condition_tsne.pdf",sep="_"))
print(p1)
dev.off()
pdf(paste(Sys.Date(),project,"Cluster_tsne.pdf",sep="_"))
print(p2)
dev.off()


pdf("Oligo_markers.pdf",height = 4,width = 8)
FeaturePlot(Oligo_Sub, features = c("PDGFRA","C1QL1"),
            reduction = "tsne",min.cutoff = "q9",cols=brewer.pal(100, "OrRd"))
FeaturePlot(Oligo_Sub, features = c("ENPP6","ERMN"),
            reduction = "tsne",min.cutoff = "q9",cols=brewer.pal(100, "OrRd"))
FeaturePlot(Oligo_Sub, features = c("MAG","PLP1"),
            reduction = "tsne",min.cutoff = "q9",max.cutoff = "q80",cols=brewer.pal(100, "OrRd"))

dev.off()



# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
Oligo_df_cond <- df_genes(Oligo_Sub,"condition",top_n=15,logfc.threshold=0.25, n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------
# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
Oligo_df_cl <- df_genes(Oligo_Sub,"Cluster",top_n=15,logfc.threshold=0.25, n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------

# =================================== Pseudotime =================================================
dir.create("Pseudotime_DiffMap2")
setwd("Pseudotime_DiffMap2")
debugonce(df_pseudotime)
Oligo_pseudo <-df_pseudotime(Oligo_Sub,reducedDim="DiffMap",reverse=FALSE,method="slingshot" )



dir.create("Network")
setwd("Network")
if(tool=="monocle"){
    GE_matrix<- data.matrix(Oligo_Sub, rownames.force = NA)
    GE_matrix <- as.matrix(GE_matrix)
    rownames(GE_matrix) <- fData(Oligo_Sub)$gene_short_name
    Normilize_Vector <- pData(Oligo_Sub)[, 'Size_Factor']
    mat <- as.matrix(sweep(GE_matrix,2,Normilize_Vector,"/"))
}else{
    mat <- as.data.frame(Oligo_Sub@assays$RNA@data)
    mat <- as.data.frame(Oligo_Sub@assays$integrated@data)
}
net_mat <- t(mat[Oligo_pseudo$DEGs,])
write.table(cbind(Oligo_pseudo$DEGs,Oligo_pseudo$DEGs),file = "df_pseudo.tsv",row.names=FALSE, na="", sep="\t")
network_MXM(net_mat)
network_MXM(net_mat,node= c("MAG","MOG","PLP1","MBP"))
network_MXM(net_mat,node= c("PDGFRA"))

setwd("../")

object <- Oligo_Sub

setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/Rat_DATA/2019-10-21_seurat_elbow_FALSE/Oligodendrocytes_Analysis/Pseudotime_DiffMap/Network")


dir.create("DAY9")
setwd("DAY9")
mat <- as.data.frame(object@assays$integrated@data[,object$condition=="Day9"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
write.table(cbind(Oligo_pseudo$DEGs,Oligo_pseudo$DEGs),file = "df_pseudo.tsv",row.names=FALSE, na="", sep="\t")
day_9_all <- network_MXM(net_mat)
setwd("../")

dir.create("DAY14")
setwd("DAY14")
mat <- as.data.frame(object@assays$integrated@data[,object$condition=="Day14"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
write.table(cbind(Oligo_pseudo$DEGs,Oligo_pseudo$DEGs),file = "df_pseudo.tsv",row.names=FALSE, na="", sep="\t")
day_14_all <- network_MXM(net_mat)
setwd("../")

dir.create("DAY17")
setwd("DAY17")
mat <- as.data.frame(object@assays$integrated@data[,object$condition=="Day17"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
write.table(cbind(Oligo_pseudo$DEGs,Oligo_pseudo$DEGs),file = "df_pseudo.tsv",row.names=FALSE, na="", sep="\t")
day_17_all <- network_MXM(net_mat)
setwd("../")

dir.create("DAY21")
setwd("DAY21")
mat <- as.data.frame(object@assays$integrated@data[,object$condition=="Day21"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
write.table(cbind(Oligo_pseudo$DEGs,Oligo_pseudo$DEGs),file = "df_pseudo.tsv",row.names=FALSE, na="", sep="\t")
day_21_all <- network_MXM(net_mat)
setwd("../")



tail(sort(rowSums(day_9_all$MmhcSkeleton$G)))
tail(sort(rowSums(day_14_all$MmhcSkeleton$G)))
tail(sort(rowSums(day_17_all$MmhcSkeleton$G)))
tail(sort(rowSums(day_21_all$MmhcSkeleton$G)))

tail(sort(rowSums(day_9_all$PcSkeleton$G)))
tail(sort(rowSums(day_14_all$PcSkeleton$G)))
tail(sort(rowSums(day_17_all$PcSkeleton$G)))
tail(sort(rowSums(day_21_all$PcSkeleton$G)))

library(igraph)

DM1 <- day_9_all$MmhcSkeleton$G
G1 <- graph.adjacency(DM1, mode = "undirected", weighted = NULL, diag = FALSE)
clusterlouvain <- cluster_louvain(G1)
V(G1)$label.cex <-0.5
pdf("MMHC_Graph_Day9.pdf")
# plot(G1, vertex.color=rainbow(50, alpha=0.6)[clusterlouvain$membership])
n <- length(unique(clusterlouvain$membership))
plot(G1, vertex.color=rainbow(n, alpha=0.6)[clusterlouvain$membership])
dev.off()




DM1 <- day_14_all$MmhcSkeleton$G
G1 <- graph.adjacency(DM1, mode = "undirected", weighted = NULL, diag = FALSE)
clusterlouvain <- cluster_louvain(G1)
V(G1)$label.cex <-0.5
pdf("MMHC_Graph_Day14.pdf")
n <- length(unique(clusterlouvain$membership))
plot(G1, vertex.color=rainbow(n, alpha=0.6)[clusterlouvain$membership])
dev.off()




DM1 <- day_17_all$MmhcSkeleton$G
G1 <- graph.adjacency(DM1, mode = "undirected", weighted = NULL, diag = FALSE)
clusterlouvain <- cluster_louvain(G1)
V(G1)$label.cex <-0.5
pdf("MMHC_Graph_Day17.pdf")
n <- length(unique(clusterlouvain$membership))
plot(G1, vertex.color=rainbow(n, alpha=0.6)[clusterlouvain$membership])
dev.off()


DM1 <- day_21_all$MmhcSkeleton$G
G1 <- graph.adjacency(DM1, mode = "undirected", weighted = NULL, diag = FALSE)
clusterlouvain <- cluster_louvain(G1)
V(G1)$label.cex <-0.5
pdf("MMHC_Graph_Day21.pdf")
n <- length(unique(clusterlouvain$membership))
plot(G1, vertex.color=rainbow(n, alpha=0.6)[clusterlouvain$membership])
dev.off()





DM1 <- day_9_all$PcSkeleton$G
G1 <- graph.adjacency(DM1, mode = "undirected", weighted = NULL, diag = FALSE)
clusterlouvain <- cluster_louvain(G1)
V(G1)$label.cex <-0.5
pdf("PC_Graph_Day9.pdf")
plot(G1, vertex.color=rainbow(50, alpha=0.6)[clusterlouvain$membership])
n <- length(unique(clusterlouvain$membership))
plot(G1, vertex.color=rainbow(n, alpha=0.6)[clusterlouvain$membership])
dev.off()




DM1 <- day_14_all$PcSkeleton$G
G1 <- graph.adjacency(DM1, mode = "undirected", weighted = NULL, diag = FALSE)
clusterlouvain <- cluster_louvain(G1)
V(G1)$label.cex <-0.5
pdf("PC_Graph_Day14.pdf")
n <- length(unique(clusterlouvain$membership))
plot(G1, vertex.color=rainbow(n, alpha=0.6)[clusterlouvain$membership])
dev.off()




DM1 <- day_17_all$PcSkeleton$G
G1 <- graph.adjacency(DM1, mode = "undirected", weighted = NULL, diag = FALSE)
clusterlouvain <- cluster_louvain(G1)
V(G1)$label.cex <-0.5
pdf("PC_Graph_Day17.pdf")
n <- length(unique(clusterlouvain$membership))
plot(G1, vertex.color=rainbow(n, alpha=0.6)[clusterlouvain$membership])
dev.off()


DM1 <- day_21_all$PcSkeleton$G
G1 <- graph.adjacency(DM1, mode = "undirected", weighted = NULL, diag = FALSE)
clusterlouvain <- cluster_louvain(G1)
V(G1)$label.cex <-0.5
pdf("PC_Graph_Day21.pdf")
n <- length(unique(clusterlouvain$membership))
plot(G1, vertex.color=rainbow(n, alpha=0.6)[clusterlouvain$membership])
dev.off()




library(ggnet)
library(network)
ggnet2(G1, size = 6, color = "black", edge.size = 1, edge.color = "grey")
network(G1, directed = FALSE)


df <- as.data.frame(cbind(Oligo_pseudo$object$Pseudotime,Oligo_pseudo$object@assays$integrated@data["PLP1",]))
colnames(df) <- c("Pseudotime","Counts")

df2 <- as.data.frame(cbind(Oligo_pseudo$object$Pseudotime,Oligo_pseudo$object@assays$integrated@data["PDGFRA",]))
colnames(df2) <- c("Pseudotime","Counts")

df3 <- as.data.frame(cbind(Oligo_pseudo$object$Pseudotime,Oligo_pseudo$object@assays$integrated@data["C1QL1",]))
colnames(df3) <- c("Pseudotime","Counts")

df4 <- as.data.frame(cbind(Oligo_pseudo$object$Pseudotime,Oligo_pseudo$object@assays$integrated@data["SERINC3",]))
colnames(df4) <- c("Pseudotime","Counts")

p1<-ggplot(df, aes(x=Pseudotime, y=Counts)) +
    geom_smooth(data = df, method="loess", fullrange=FALSE,se=TRUE, na.rm=TRUE)+
    geom_smooth(data = df2, method="loess", fullrange=FALSE,se=TRUE, na.rm=TRUE,color="red")+
    geom_smooth(data = df3, method="loess", fullrange=FALSE,se=TRUE, na.rm=TRUE,color="green")+
    geom_smooth(data = df4, method="loess", fullrange=FALSE,se=TRUE, na.rm=TRUE,color="black")


plp1_c <-as.vector(Oligo_pseudo$object@assays$integrated@data["PLP1",])
pdgfra_c <- as.vector(Oligo_pseudo$object@assays$integrated@data["PDGFRA",])
c1ql1_c <- as.vector(Oligo_pseudo$object@assays$integrated@data["C1QL1",])
mog_c <- as.vector(Oligo_pseudo$object@assays$integrated@data["MOG",])

df_all <- data.frame("Pseudotime"=rep(Oligo_pseudo$object$Pseudotime,4),
                     "Counts"=c(plp1_c,pdgfra_c,c1ql1_c,mog_c),
                     "Gene" = rep(c("Plp1","Pdgfra","C1ql1","Mog"),each=length(plp1_c)))

p <- ggplot(df_all,aes(Pseudotime,Counts,group=Gene,color=Gene))+
    # geom_point() +
    geom_smooth(method="loess", fullrange=FALSE,se=TRUE, na.rm=TRUE) +
    scale_color_viridis_d() +
    labs(x = "Pseudotime", y = "Counts") +
    theme(legend.position = "top",text = element_text(size=20))
p

pdf("Genes_Trend.pdf")
p
dev.off()




n_mark = match("PLP1",colnames(day_9_all$MmhcSkeleton$G))
day_9_all$MmhcSkeleton$G[day_9_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]
day_14_all$MmhcSkeleton$G[day_14_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]
day_17_all$MmhcSkeleton$G[day_17_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]
day_21_all$MmhcSkeleton$G[day_21_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]

n_mark = match("PDGFRA",colnames(day_9_all$MmhcSkeleton$G))
day_9_all$MmhcSkeleton$G[day_9_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]
day_14_all$MmhcSkeleton$G[day_14_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]
day_17_all$MmhcSkeleton$G[day_17_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]
day_21_all$MmhcSkeleton$G[day_21_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]


n_mark = match("MAG",colnames(day_9_all$MmhcSkeleton$G))
day_9_all$MmhcSkeleton$G[day_9_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]
day_14_all$MmhcSkeleton$G[day_14_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]
day_17_all$MmhcSkeleton$G[day_17_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]
day_21_all$MmhcSkeleton$G[day_21_all$MmhcSkeleton$G[,n_mark]!=0,n_mark]


# day_9_spef <-network_MXM(net_mat,node= c("MAG","MOG","PLP1","MBP"))
setwd("../")

dir.create("DAY14")
setwd("DAY14")
mat <- as.data.frame(object@assays$RNA@data[,object$condition=="Day14"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
write.table(cbind(Oligo_pseudo$DEGs,Oligo_pseudo$DEGs),file = "df_pseudo.tsv",row.names=FALSE, na="", sep="\t")
day_14_all <- network_MXM(net_mat)
sort(rowSums(day_14_all$PcSkeleton$G))
# day_17_spef <-network_MXM(net_mat,node= c("MAG","MOG","PLP1","MBP"))
setwd("../")


dir.create("DAY17")
setwd("DAY17")
mat <- as.data.frame(object@assays$RNA@data[,object$condition=="Day17"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
write.table(cbind(Oligo_pseudo$DEGs,Oligo_pseudo$DEGs),file = "df_pseudo.tsv",row.names=FALSE, na="", sep="\t")
day_17_all <- network_MXM(net_mat)
sort(rowSums(day_17_all$PcSkeleton$G))

# day_17_spef <-network_MXM(net_mat,node= c("MAG","MOG","PLP1","MBP"))
setwd("../")


dir.create("DAY21")
setwd("DAY21")
mat <- as.data.frame(object@assays$RNA@data[,object$condition=="Day21"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
write.table(cbind(Oligo_pseudo$DEGs,Oligo_pseudo$DEGs),file = "df_pseudo.tsv",row.names=FALSE, na="", sep="\t")
day_21_all <- network_MXM(net_mat)
sort(rowSums(day_21_all$PcSkeleton$G))

# day_21_spef <-network_MXM(net_mat,node= c("MAG","MOG","PLP1","MBP"))
setwd("../")

setwd("../")


save.image(file = "my_work_space.RData")


dir.create("Pseudotime_ddrtree")
setwd("Pseudotime_ddrtree")

length(colnames(Combined)[Combined$Cell_Type=="Oligodendrocytes"])
length(colnames(Oligo_Sub))


Oligo_pseudo <-df_pseudotime(Oligo_Sub,reducedDim="DiffMap",reverse=FALSE,method="monocle" )

dir.create("Network")
setwd("Network")
mat <- as.data.frame(object@assays$RNA@data)
net_mat <- t(mat[df_pseudotime_umap$DEGs,])
write.table(cbind(df_pseudotime_umap$DEGs,df_pseudotime_umap$DEGs),file = "df_pseudo.tsv",row.names=FALSE, na="", sep="\t")
network_MXM(net_mat)
network_MXM(net_mat,node= c("MAG","MOG","PLP1","MBP"))
setwd("../")

setwd("../")
# ------------------------------------------------------------------------------------------------


setwd("../")
# -----------------------------------------------------------------------------------------------



# ======================================== Astrocytes Analysis  =================================
dir.create("Astrocytes_Analysis")
setwd("Astrocytes_Analysis")
Astro_Sub <- object_subset(object=Combined,Conditions=NULL,Clusters=NULL,Cell_Types=c("Astrocytes") )


p1 <- plot_cells(Astro_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1)
p2 <-plot_cells(Astro_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
p3 <-plot_cells(Astro_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1 )
pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

pdf(paste(Sys.Date(),project,"Cell_Type_tsne.pdf",sep="_"))
print(p3)
dev.off()
pdf(paste(Sys.Date(),project,"Condition_tsne.pdf",sep="_"))
print(p1)
dev.off()
pdf(paste(Sys.Date(),project,"Cluster_tsne.pdf",sep="_"))
print(p2)
dev.off()



# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
return_fun <- df_genes(Astro_Sub,"condition",top_n=15,logfc.threshold=0.25 ,n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------
# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
return_fun <- df_genes(Astro_Sub,"Cluster",top_n=15,logfc.threshold=0.25 ,n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------

# =================================== Pseudotime =================================================
dir.create("Pseudotime")
setwd("Pseudotime")
# debugonce(df_pseudotime)
astro_pseudo <-df_pseudotime(Astro_Sub,reducedDim="DiffMap",reverse=FALSE,method="slingshot")
setwd("../")
# ------------------------------------------------------------------------------------------------
setwd("../")
# -----------------------------------------------------------------------------------------------



# ======================================== Microglia Analysis  =================================
dir.create("Microglia_Analysis")
setwd("Microglia_Analysis")
Micro_Sub <- object_subset(object=Combined,Conditions=NULL,Clusters=NULL,Cell_Types=c("Microglia") )


p1 <- plot_cells(Micro_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1)
p2 <-plot_cells(Micro_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
p3 <-plot_cells(Micro_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1 )
pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

pdf(paste(Sys.Date(),project,"Cell_Type_tsne.pdf",sep="_"))
print(p3)
dev.off()
pdf(paste(Sys.Date(),project,"Condition_tsne.pdf",sep="_"))
print(p1)
dev.off()
pdf(paste(Sys.Date(),project,"Cluster_tsne.pdf",sep="_"))
print(p2)
dev.off()



# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
return_fun <- df_genes(Micro_Sub,"condition",top_n=15,logfc.threshold=0.25 ,n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------
# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
return_fun <- df_genes(Micro_Sub,"Cluster",top_n=15,logfc.threshold=0.25 ,n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------

# =================================== Pseudotime =================================================
dir.create("Pseudotime")
setwd("Pseudotime")
# debugonce(df_pseudotime)
astro_pseudo <-df_pseudotime(Micro_Sub,reducedDim="DiffMap",reverse=FALSE,method="slingshot")
setwd("../")
# ------------------------------------------------------------------------------------------------
setwd("../")
# -----------------------------------------------------------------------------------------------






# ======================================== NEurons Analysis  =================================
dir.create("Neurons_Analysis")
setwd("Neurons_Analysis")
Combined$Cell_Type[Combined$Cluster==2] <-"Hybrid"
Neuron_Sub <- object_subset(object=Combined,Conditions=NULL,Clusters=NULL,Cell_Types=c("Neurons","NSC") )


p1 <- plot_cells(Neuron_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1)
p2 <-plot_cells(Neuron_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
p3 <-plot_cells(Neuron_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1 )
pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

pdf(paste(Sys.Date(),project,"Cell_Type_tsne.pdf",sep="_"))
print(p3)
dev.off()
pdf(paste(Sys.Date(),project,"Condition_tsne.pdf",sep="_"))
print(p1)
dev.off()
pdf(paste(Sys.Date(),project,"Cluster_tsne.pdf",sep="_"))
print(p2)
dev.off()



# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
return_fun <- df_genes(Neuron_Sub,"condition",top_n=15,logfc.threshold=0.25 ,n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------
# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
return_fun <- df_genes(Neuron_Sub,"Cluster",top_n=15,logfc.threshold=0.25 ,n_cores=4)
setwd("../")
# ------------------------------------------------------------------------------------------------

# =================================== Pseudotime =================================================
dir.create("Pseudotime")
setwd("Pseudotime")
# debugonce(df_pseudotime)
neuro_pseudo <-df_pseudotime(Neuron_Sub,reducedDim="DiffMap",reverse=FALSE,method="slingshot")
setwd("../")
# ------------------------------------------------------------------------------------------------
setwd("../")
# -----------------------------------------------------------------------------------------------








#  ================================ BETWEENNESS CENTRALITY =============================

library(igraph)
DM1 <- day_9_all$PcSkeleton$G
G1 <- graph.adjacency(DM1, mode = "undirected", weighted = NULL, diag = FALSE)
clusterlouvain <- cluster_louvain(G1)

G1 <-  graph.adjacency(day_9_all$PcSkeleton$G, mode = "undirected", weighted = NULL, diag = FALSE)
G2 <-  graph.adjacency(day_14_all$PcSkeleton$G, mode = "undirected", weighted = NULL, diag = FALSE)
G3 <-  graph.adjacency(day_17_all$PcSkeleton$G, mode = "undirected", weighted = NULL, diag = FALSE)
G4 <-  graph.adjacency(day_21_all$PcSkeleton$G, mode = "undirected", weighted = NULL, diag = FALSE)

day9_betweeness <- as.data.frame(betweenness(G1))

set.seed(1234)  # set seed to make the layout reproducible
pdf("Graphs.pdf")
for (i in list(G1,G2,G3,G4)){
  V(i)$label.cex <-0.5
  clusterlouvain <- cluster_louvain(i)
  set.seed(1234)  # set seed to make the layout reproducible
  plot(i,edge.arrow.size=0.25,edge.arrow.mode="-",vertex.color=rainbow(length(unique(clusterlouvain$membership)), alpha=0.6)[clusterlouvain$membership])

  # ==================== Betweeness ======================
  #Node or Vetex Options: Size and Color
  V(i)$size=betweenness(i)/200 #because we have wide range, I am dividing by 5 to keep the high in-degree nodes from overshadowing everything else.
  V(i)$color <- rainbow(length(unique(clusterlouvain$membership)), alpha=0.6)[clusterlouvain$membership]
  #Edge Options: Color
  E(i)$color <- "grey"
  #Plotting, Now Specifying an arrow size and getting rid of arrow heads
  #We are letting the color and the size of the node indicate the directed nature of the graph
  set.seed(1234)  # set seed to make the layout reproducible
  plot(i, edge.arrow.size=0.25,edge.arrow.mode = "-", vertex.label = NA)

  # ==================== Closeness ======================
  #Node or Vetex Options: Size and Color
  V(i)$size=degree(i, mode = "in") #because we have wide range, I am dividing by 5 to keep the high in-degree nodes from overshadowing everything else.
  V(i)$color <- rainbow(length(unique(clusterlouvain$membership)), alpha=0.6)[clusterlouvain$membership]
  #Edge Options: Color
  E(i)$color <- "grey"
  #Plotting, Now Specifying an arrow size and getting rid of arrow heads
  #We are letting the color and the size of the node indicate the directed nature of the graph
  set.seed(1234)  # set seed to make the layout reproducible
  plot(i, edge.arrow.size=0.25,edge.arrow.mode = "-", vertex.label = NA)


}
dev.off()


day14_betweeness <- as.data.frame(betweenness(G2))
day17_betweeness <- as.data.frame(betweenness(G3))
day21_betweeness <- as.data.frame(betweenness(G4))

day9_genes <- colnames(day_9_all$PcSkeleton$G)
day9_genes[order(day9_betweeness[,1],decreasing = T)][1:5]
day9_genes[order(day14_betweeness[,1],decreasing = T)][1:5]
day9_genes[order(day17_betweeness[,1],decreasing = T)][1:5]
day9_genes[order(day21_betweeness[,1],decreasing = T)][1:5]


object <- Oligo_Sub

dir.create("Cluster1")
setwd("Cluster1")
mat <- as.data.frame(object@assays$integrated@data[,object$Cluster=="1"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
cl1_all <- network_MXM(net_mat)
setwd("../")


dir.create("Cluster0")
setwd("Cluster0")
mat <- as.data.frame(object@assays$integrated@data[,object$Cluster=="0"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
cl0_all <- network_MXM(net_mat)
setwd("../")



dir.create("Cluster4")
setwd("Cluster4")
mat <- as.data.frame(object@assays$integrated@data[,object$Cluster=="4"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
cl4_all <- network_MXM(net_mat)
setwd("../")


library(igraph)
G11 <-  graph.adjacency(cl1_all$PcSkeleton$G, mode = "undirected", weighted = NULL, diag = FALSE)
G21 <-  graph.adjacency(cl0_all$PcSkeleton$G, mode = "undirected", weighted = NULL, diag = FALSE)
G31 <-  graph.adjacency(cl4_all$PcSkeleton$G, mode = "undirected", weighted = NULL, diag = FALSE)


set.seed(1234)  # set seed to make the layout reproducible
pdf("Graphs_Clusters.pdf")
for (i in list(G11,G21,G31)){
  V(i)$label.cex <-0.5
  clusterlouvain <- cluster_louvain(i)
  set.seed(1234)  # set seed to make the layout reproducible
  plot(i,edge.arrow.size=0.25,edge.arrow.mode="-",vertex.color=rainbow(length(unique(clusterlouvain$membership)), alpha=0.6)[clusterlouvain$membership])

  # ==================== Betweeness ======================
  #Node or Vetex Options: Size and Color
  V(i)$size=betweenness(i)/200 #because we have wide range, I am dividing by 5 to keep the high in-degree nodes from overshadowing everything else.
  V(i)$color <- rainbow(length(unique(clusterlouvain$membership)), alpha=0.6)[clusterlouvain$membership]
  #Edge Options: Color
  E(i)$color <- "grey"
  #Plotting, Now Specifying an arrow size and getting rid of arrow heads
  #We are letting the color and the size of the node indicate the directed nature of the graph
  set.seed(1234)  # set seed to make the layout reproducible
  plot(i, edge.arrow.size=0.25,edge.arrow.mode = "-", vertex.label = NA)

  # ==================== Closeness ======================
  #Node or Vetex Options: Size and Color
  V(i)$size=degree(i, mode = "in") #because we have wide range, I am dividing by 5 to keep the high in-degree nodes from overshadowing everything else.
  V(i)$color <- rainbow(length(unique(clusterlouvain$membership)), alpha=0.6)[clusterlouvain$membership]
  #Edge Options: Color
  E(i)$color <- "grey"
  #Plotting, Now Specifying an arrow size and getting rid of arrow heads
  #We are letting the color and the size of the node indicate the directed nature of the graph
  set.seed(1234)  # set seed to make the layout reproducible
  plot(i, edge.arrow.size=0.25,edge.arrow.mode = "-", vertex.label = NA)


}
dev.off()


pdf("Cormap_Clusters.pdf")
for (i in c("1","0","4")){
  mat <- as.data.frame(object@assays$RNA@data[,object$Cluster==i])
  net_mat <- t(mat[Oligo_pseudo$DEGs,])

  cor_map<-cor(net_mat)
  cor_map[is.na(cor_map)]<- 0
  corrplot(cor_map, order = "AOE",
           type="lower",
           number.font=0.5,tl.cex=0.4,
           addCoefasPercent = TRUE)
}
dev.off()









G1
# ============================== GENE CORRELATION ===================================
library(corrplot)
for (i in c("Day9","Day14","Day17","Day21")){
    mat <- as.data.frame(object@assays$RNA@data[,object$condition==i])
    net_mat <- t(mat[Oligo_pseudo$DEGs,])
    pdf(paste0(i,"_Cormap.pdf"))
    cor_map<-cor(net_mat)
    cor_map[is.na(cor_map)]<- 0
    corrplot(cor_map, order = "AOE",
             type="lower",
             number.font=0.5,tl.cex=0.4,
             addCoefasPercent = TRUE)
    dev.off()
}

mat <- as.data.frame(object@assays$RNA@data[,object$condition=="Day14"])
net_mat <- t(mat[Oligo_pseudo$DEGs,])
df <- as.data.frame(net_mat)

cor(plp1_c,pdgfra_c )
plp1_c <- df$PLP1
pdgfra_c <- df$PDGFRA
c1ql1_c <- df$C1QL1
mog_c <- df$MOG
df_all <- data.frame("Pseudotime"=rep(Oligo_pseudo$object$Pseudotime[object$condition=="Day14"],4),
                     "Counts"=c(plp1_c,pdgfra_c,c1ql1_c,mog_c),
                     "Gene" = rep(c("Plp1","Pdgfra","C1ql1","Mog"),each=length(plp1_c)))

p <- ggplot(df_all,aes(Pseudotime,Counts,group=Gene,color=Gene))+
    # geom_point() +
    geom_smooth(method="loess", fullrange=FALSE,se=TRUE, na.rm=TRUE) +
    scale_color_viridis_d() +
    labs(x = "Pseudotime", y = "Counts") +
    theme(legend.position = "top",text = element_text(size=20))
p


Combined2 <- Combined
Combined2
Combined4 <- RunTSNE(Combined2,
                            reduction.use = "pca",
                            dims.use = 1:27,
                            dim.embed = 3)
tsne_1 <- Combined4[["tsne"]]@cell.embeddings[,1]

tsne_2 <- Combined4[["tsne"]]@cell.embeddings[,2]

tsne_3 <- Combined4[["tsne"]]@cell.embeddings[,3]


library(rgl) #interactive 3d plotting
plot3d(x = tsne_1, y = tsne_2, z = tsne_3,col = color_list$condition[Combined4$condition])

plot3d(x = tsne_1, y = tsne_2, z = tsne_3,col = color_list$Cluster[Combined4$Cluster])

plot3d(x = tsne_1, y = tsne_2, z = tsne_3,col =color_list$Cell_Type[as.factor(Combined4$Cell_Type)])


row_sums <- rowSums(Combined@assays$RNA@counts)
col_sums <- colSums(Combined@assays$RNA@counts)
Combined2 <- Combined[,col_sums>=200]


plot_cells(Combined2,target="Cell_Type",leg_pos="right",save=FALSE,ncol=1 )
plot_cells(Combined,target="Cell_Type",leg_pos="right",save=FALSE,ncol=1 )

length(col_sums)
dim(Combined)
dim(Combined2)


library(MASS)
den3d <- kde2d(tsne_1,tsne_2)
persp(den3d, box=FALSE)

library(plotly)
plot_ly(x=-den3d$x, y=-den3d$y, z=-den3d$z, type = "surface")%>%
    add_trace(data = den3d, x = tsne_1, y = tsne_2,z=rep(0,length(tsne_2)),mode = "markers", type = "scatter3d",
              marker = list(size = 5, color = color_list$condition[Combined4$condition], symbol = 104))
plot_cells(Combined2,target="Cluster",leg_pos="right",save=FALSE,ncol=1 )
plot_cells(Combined2,target="condition",leg_pos="right",save=FALSE,ncol=1 )
FeaturePlot(Combined2, features = c("nFeature_RNA"),
            reduction = "pca",
            pt.size=1.2,
            cols=jcolors(palette = "pal12"))


library(plotly)
plotting.data <- FetchData(object = Combined2, vars = c("PC_1", "PC_2", "PC_3", "MOG"))
plotting.data$MOG <- MinMax(data = plotting.data$MOG, min = 0, max = 5)

plot_ly(data = plotting.data, x = ~PC_1, y = ~PC_2, z = ~PC_3,
      marker= list(color = ~MOG,colorscale=jcolors("pal12"),showscale=TRUE))

