library(ICSWrapper)

set.seed(123)
tool="seurat"

project ="10x_Kamil"
dataset <- project
Data_select <- data_selection(project)

WORKDIR <- Data_select$WORKDIR
list_of_files <- Data_select$list_of_files
condition_names <- Data_select$condition_names
organism<- Data_select$organism
file<- Data_select$file
data_10x<- Data_select$data_10x

setwd(Data_select$WORKDIR)



colormap_d<- c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928',"black","gray")
color_cond  <- c(brewer.pal(8,"Dark2"),"black","gray","magenta4","seagreen4")

color_cond  <- c(brewer.pal(5,"Set1"),"black","gray","magenta4","seagreen4")


color_clust <- c(brewer.pal(12,"Paired")[-11],"black","gray","magenta4","seagreen4",brewer.pal(9,"Set1"))

color_clust <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")
color_cells <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")
color_list <- list(condition=color_cond,Cluster=color_clust,Cell_Type=color_cells,State=color_clust)
# color_cells <-primary.colors(15, steps = 3, no.white = TRUE)



# ================================ SETTING UP ======================================== #
# Number of cells to use
imputation = FALSE
remove_mt=TRUE
remove_ribsomal=TRUE
n_cores=5
elbow = FALSE


# setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-20_seurat_elbow_FALSE")
# Combined <- readRDS("Cell_Types_2019-11-20_seurat_elbow_FALSE.rds")

NewDir <- paste0(Sys.Date(),"_",tool,"_elbow_",elbow,"_remove_ribsomal_",remove_ribsomal)

dir.create(NewDir)
setwd(NewDir)

# setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-13_seurat_elbow_FALSE_SAVER")

# ==============================================================================================
# ================================ Setup the Seurat objects ====================================
# ==============================================================================================
# ======== Perform an integrated analysis ====
dir.create("QC")
setwd("QC")
# debugonce(load_files)
Return_fun <- create_cds(list_of_files=list_of_files,
                         condition_names=condition_names,
                         min.features =200,min.cells=10,remove_mt=TRUE,data_10x=data_10x, elbow = elbow,tool=tool,imputation=imputation)

Combined  <- Return_fun$Combined
Data_List <- Return_fun$Data_List
setwd("../")

# ----------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------

saveRDS(Combined,paste0("Merged_",NewDir,".rds"))
# setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-13_seurat_elbow_FALSE_SAVER")
# Combined <- readRDS("Merged_2019-11-13_seurat_elbow_FALSE.rds")

# ==============================================================================================
# ======================================= Clustering  ==========================================
# ==============================================================================================
dir.create("Clustering")
setwd("Clustering")
# Combined <- ReduceDim(Combined,method="umap",project=project)$Combined
# debugonce(reduce_dim)
Combined <- reduce_dim(Combined,project=project)$Combined

pdf(paste(Sys.Date(),project,"tsne","Conditions.pdf",sep="_"))
plot_cells(Combined,target="condition",leg_pos="right",save=TRUE,ncol=1)
dev.off()
pdf(paste(Sys.Date(),project,"tsne","Cluster.pdf",sep="_"))
# debugonce(plot_cells)
plot_cells(Combined,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
dev.off()


plot_nFeatures(Combined,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)
plot_tot_mRNA(Combined,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)


if(tolower(tool)=="seurat" & elbow){
    p3 <- DimPlot(object = Combined, reduction = "umap", group.by = "condition",cols = color_cond)
    p4 <- DimPlot(object = Combined, reduction = "umap", group.by = "Cluster", label = TRUE,cols = color_clust)
    pdf(paste(Sys.Date(),project,"umap","Seurat_Conditions.pdf",sep="_"))
    print(p3)
    dev.off()
    pdf(paste(Sys.Date(),project,"umap","Seurat_Clusters.pdf",sep="_"))
    print(p4)
    dev.off()
}

# ------------------------------------------------------------------------------------------------

setwd("../")

saveRDS(Combined,paste0("Clustered_",NewDir,".rds"))
Combined <-readRDS(paste0("Clustered_",NewDir,".rds"))

Combined$Cluster <- as.factor(as.numeric(Combined$seurat_clusters))
Combined$Cell_Type <-as.vector(Combined$Cluster)  
cell_types <- Combined$Cell_Type
cell_types[ which(Combined$Cluster %in% c(1,2,5,4,7,13,12,14,15))] <- "Mesenchymal"
cell_types[ which(Combined$Cluster %in% c(9,3,11,10,6,8))] <- "Epithelial"
Combined$Cell_Type <-cell_types
Combined$Cluster <- as.factor(as.vector(Combined$Cell_Type))
Combined$ATP <- Combined$condition




p1 <- plot_cells(Combined,target="condition",leg_pos="right",save=TRUE,ncol=1)
p2 <-plot_cells(Combined,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
p3 <-plot_cells(Combined,target="seurat_clusters",leg_pos="right",save=TRUE,ncol=1)

pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

pdf(paste(Sys.Date(),project,"Cell_Type_tsne.pdf",sep="_"))
print(p3)
dev.off()
pdf(paste(Sys.Date(),project,"Condition_tsne.pdf",sep="_"))
print(p1)
dev.off()
pdf(paste(Sys.Date(),project,"Cluster_tsne.pdf",sep="_"))
print(p2)
dev.off()



# --------------------------------------------------------------------------------------------

# =================================== DF ATP =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
em_return_fun <- df_genes(Combined,"Cluster",top_n=50,
	logfc.threshold=0.5,
	n_cores=4,
	latent.vars=c("nCount_RNA"),
	only.pos=TRUE)
setwd("../")

length(em_return_fun$top_markers)
count_mat <-  as.matrix(Combined@assays$RNA@counts)
e_score <-colSums(count_mat[rownames(count_mat) %in% em_return_fun$top_markers[1:50],])
m_score <-colSums(count_mat[rownames(count_mat) %in% em_return_fun$top_markers[51:100],])
em_score <- e_score - m_score 

Combined$em_score <- MinMax(em_score,2.5,-2.5)
Combined$em_score <- em_score

hist(em_score)
d <- density(em_score[Combined$Cluster=="Epithelial"]) # returns the density data
plot(d) # plots the results
d <- density(em_score[Combined$Cluster=="Mesenchymal"]) # returns the density data
plot(d) # plots the results

d <- density(em_score) # returns the density data
plot(d) # plots the results


e_em_score <- em_score[Combined$Cluster=="Epithelial"]
m_em_score <- em_score[Combined$Cluster=="Mesenchymal"]

# ================= Find the overlap of the Distributions ===========================
Center_Threshold <- distribution_solve(e_em_score,m_em_score)
hist(em_score,breaks=100);abline(v=Center_Threshold,col="red", lwd=3, lty=2)
# -----------------------------------------------------------------------------------

tr_m <- m_em_score[m_em_score<Center_Threshold]
m_n_out <- round(length(tr_m)*5/100)
sr_tr_m <- sort(tr_m,decreasing =F)
fl_tr_m <- sr_tr_m[1:(length(sr_tr_m)-m_n_out)]


tr_e <- e_em_score[e_em_score>Center_Threshold]
e_n_out <- round(length(tr_e)*5/100)
fl_tr_e <- sort(tr_e,decreasing =T)[1:(length(tr_e)-e_n_out)]
fl_tr_e[length(fl_tr_e)]
fl_tr_m[length(fl_tr_m)]

d <- density(fl_tr_m) # returns the density data
plot(d) # plots the results

d <- density(fl_tr_e) # returns the density data
plot(d) # plots the results

hist(em_score)

hist(em_score, col="lightblue",main="Histogram for em_score")

hl1 <- fl_tr_e[length(fl_tr_e)]
hl2 <- fl_tr_m[length(fl_tr_m)]
pdf("EM_density_Cut.pdf")
hist(em_score, col="lightblue",main="Histogram for em_score",breaks=100)
abline(v=c(hl1,Center_Threshold,hl2),col=c("blue","red","blue"), lwd=3, lty=2)

plot(density(em_score), col="black",main="Density for em_score")
abline(v=c(hl1,Center_Threshold,hl2),col=c("blue","red","blue"), lwd=3, lty=2)
dev.off()
# --------------------------------------------------------------------------------------------



dir.create("Files")
setwd("Files")
# =================================== DF M/E =================================================
for (atp in levels(Combined$condition)){
	temp <- Combined[,as.vector(Combined$condition)==atp]
	temp_count_mat <- as.matrix(temp@assays$RNA@counts)
	temp_m <- temp_count_mat[,colnames(temp_count_mat)%in%names(fl_tr_m)]
	temp_e <- temp_count_mat[,colnames(temp_count_mat)%in%names(fl_tr_e)]
	
	# write(temp_m, file = paste0(atp,"_Mesenchymal.txt"), sep = "\t")
	# write(temp_e, file = paste0(atp,"_Epithelial.txt"), sep = "\t")

	write.csv(temp_m, file = paste0(atp,"_Mesenchymal.csv"))
	write.csv(temp_e, file = paste0(atp,"_Epithelial.csv"))
	
	temp_em_score <- data.frame("EM_Score"=em_score[names(em_score)%in% colnames(temp_count_mat)])
	#write(temp_em_score, file = paste0(atp,"_EM_Score.csv"), sep = "\t")
	write.csv(temp_em_score, file = paste0(atp,"_EM_Score.csv"))

}
setwd("../")






Combined2 <- Combined
temp_cl <- as.vector(Combined2$Cluster)
temp_cl[!colnames(Combined2)%in% c(names(fl_tr_e),names(fl_tr_m))] <- "Intermidiate"
Combined2$Cluster <- as.factor(temp_cl)



Combined2$em_score <- em_score

p1 <- plot_cells(Combined2,target="condition",leg_pos="right",save=TRUE,ncol=1)
p2 <-plot_cells(Combined2,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
p3 <-plot_cells(Combined2,target="seurat_clusters",leg_pos="right",save=TRUE,ncol=1)

pdf(paste(Sys.Date(),project,"tsne2.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

pdf(paste(Sys.Date(),project,"Cell_Type_tsne2.pdf",sep="_"))
print(p3)
dev.off()
pdf(paste(Sys.Date(),project,"Condition_tsne2.pdf",sep="_"))
print(p1)
dev.off()
pdf(paste(Sys.Date(),project,"Cluster_tsne2.pdf",sep="_"))
print(p2)
dev.off()


saveRDS(Combined2,"Re_named.rds")
DimPlot(Combined2,reduction="pca",group.by="Cluster")
DimPlot(Combined2,reduction="tsne",group.by="Cluster")
DimPlot(Combined2,reduction="umap",group.by="Cluster")

pdf("Violin_EMscore.pdf")
VlnPlot(Combined2,features="em_score",group.by="Cluster")
dev.off()




# =================================== DF ATP =================================================
dir.create("DF_Clusters_EIM")
setwd("DF_Clusters_EIM")
eim_return_fun <- df_genes(Combined,"Cluster",top_n=50,
	logfc.threshold=0.5,
	n_cores=4,
	latent.vars=c("nCount_RNA"),
	only.pos=TRUE)

library(clusterProfiler)
dir.create("GSEA")
setwd("GSEA")
# debugonce(gene_set_enrich)
sub_degs <- eim_return_fun$degs[eim_return_fun$degs$p_val_adj<0.05,]
universe <- rownames(Combined@assays$RNA@counts)
symbols = as.vector(sub_degs[order(abs(sub_degs$avg_logFC)),]$gene)
test <- split(symbols,sub_degs$cluster)

x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="BP")
pdf("enrichGO_BP.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()

x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="MF")
pdf("enrichGO_MF.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()

x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="CC")
pdf("enrichGO_CC.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()

setwd("../")
setwd("../")


save.image(file = "EM_work_space.RData")



# !!!!!!!!!!!!!!!!///////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
# !!!!!!!!!!!!!!!!///////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
# !!!!!!!!!!!!!!!!///////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/10x_Kamil/2019-12-03_seurat_elbow_FALSE_remove_ribsomal_TRUE")
# Combined2 <- readRDS("Re_named.rds")
load("EM_work_space.RData")
# !!!!!!!!!!!!!!!!///////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
# !!!!!!!!!!!!!!!!///////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
# !!!!!!!!!!!!!!!!///////////////////////////////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\







# ========= ATP_0uM ===================


# =================================== DF M/E =================================================
for (atp in levels(Combined$condition)){
	temp <- Combined[,as.vector(Combined$condition)==atp]
	temp[,as.vector(temp$Cluster)=="Mesenchymal"]
	temp[,as.vector(temp$Cluster)=="Mesenchymal"]
}

Mesenchymal <- Combined2[,as.vector(Combined2$Cluster)=="Mesenchymal"]
Epithelial <- Combined2[,as.vector(Combined2$Cluster)=="Epithelial"]

dir.create("DF_condition_Mesenchymal")
setwd("DF_condition_Mesenchymal")
return_fun <- df_genes(Mesenchymal,"condition",top_n=50,
	logfc.threshold=0.2,
	n_cores=4,
	latent.vars=c("nCount_RNA"),
	only.pos=TRUE)

library(clusterProfiler)
dir.create("GSEA")
setwd("GSEA")
# debugonce(gene_set_enrich)
sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05,]
universe <- rownames(Mesenchymal@assays$RNA@counts)
symbols = as.vector(sub_degs[order(abs(sub_degs$avg_logFC)),]$gene)
test <- split(symbols,sub_degs$cluster)

x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="BP")
pdf("enrichGO.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()

x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="MF")
pdf("enrichGO_MF.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()
setwd("../")




dir.create("DF_Pairwise")
setwd("DF_Pairwise")
Idents(Mesenchymal) <- Mesenchymal$condition
cl_combinations <- combn(levels(Mesenchymal$condition),2)

pairwise_df <- function (comb,cl_combinations,object){
#for(comb in 1:dim(cl_combinations)[2]){
	target <- "condition"
    idents <- as.vector(cl_combinations[,comb])
    ident.1 <- idents[1]
    print(ident.1)
    
    ident.2 <- idents[2]
    DefaultAssay(object) <- "RNA"
    
    cells_index <- object$condition%in%c(ident.1,ident.2)
    temp_object <- subset(x=object,cells=colnames(object)[cells_index])

    
    temp_object <- ScaleData(temp_object)

    pbmc.markers <- FindAllMarkers(object = temp_object,
                                           assay ="RNA",
                                           logfc.threshold=0,
                                           only.pos = TRUE,
                                           test.use = "MAST",latent.vars = c("nCount_RNA"))
    pbmc.markers$gene <- rownames(pbmc.markers)
    qvalue <- p.adjust(pbmc.markers$p_val, method = "BH",n=dim(temp_object@assays$RNA@counts)[1])
    pbmc.markers$qvalue <- qvalue
    top <- pbmc.markers[pbmc.markers$qvalue<0.05,]
    top10 <- top %>% top_n(n = 50, wt = abs(avg_logFC))
    top10_genes<- top10$gene
    temp <- temp_object[,temp_object$condition%in%c(ident.1,ident.2)]
    temp$condition <- as.factor(as.vector(temp$condition))

    # debugonce(annotated_heat)
    title <- paste(cl_combinations[,comb],collapse = "_")
    annotated_heat(object=temp,
                      row_annotation=c(1),
                      gene_list=top10_genes,
                      Rowv=TRUE,
                      gene_list_name="DF_genes",
                      title=title,
                      ordering="condition")

    DefaultAssay(temp_object) <- "integrated"
    write.table(pbmc.markers, file = paste0(Sys.Date(),"_TO_EXP_each_",target,"_",title,".tsv"),row.names=FALSE, na="", sep="\t")

    test <- split(top$gene,top$cluster)

	x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
	                        pvalueCutoff  = 0.05,ont="BP")
	pdf(paste0(Sys.Date(),"_enrichGO_BP_",target,"_",title,".pdf"),width=12,height=10)
	dotplot(x, showCategory=5, includeAll=FALSE)
	dev.off()

	x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
	                        pvalueCutoff  = 0.05,ont="MF")
	pdf(paste0(Sys.Date(),"_enrichGO_MF_",target,"_",title,".pdf"),width=12,height=10)
	dotplot(x, showCategory=5, includeAll=FALSE)
	dev.off()
}

mclapply(c(1:dim(cl_combinations)[2]),FUN=pairwise_df,
	cl_combinations=cl_combinations,
	object=Mesenchymal,
	mc.cores=1)


setwd("../")
setwd("../")



dir.create("DF_condition_Epithelial")
setwd("DF_condition_Epithelial")
return_fun <- df_genes(Epithelial,"condition",top_n=50,
	logfc.threshold=0.2,
	n_cores=4,
	latent.vars=c("nCount_RNA"),
	only.pos=TRUE)


library(clusterProfiler)
dir.create("GSEA")
setwd("GSEA")
# debugonce(gene_set_enrich)
sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05,]
universe <- rownames(Mesenchymal@assays$RNA@counts)
symbols = as.vector(sub_degs[order(abs(sub_degs$avg_logFC)),]$gene)
test <- split(symbols,sub_degs$cluster)


x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="BP")
pdf("enrichGO_BP.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()

x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="MF")
pdf("enrichGO_MF.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()

setwd("../")




dir.create("DF_Pairwise")
setwd("DF_Pairwise")
Idents(Epithelial) <- Epithelial$condition
cl_combinations <- combn(levels(Epithelial$condition),2)

mclapply(c(1:dim(cl_combinations)[2]),FUN=pairwise_df,
	cl_combinations=cl_combinations,
	object=Epithelial,
	mc.cores=1)



setwd("../")
setwd("../")












# ============================== oscillation ======================================
# ============================== oscillation ======================================
# ============================== oscillation ======================================

imputation = FALSE
remove_mt=TRUE
remove_ribsomal=TRUE
n_cores=5
elbow = TRUE
data_10x=FALSE
project <- "oscillation"
dir.create("Oscillation")
setwd("Oscillation")

work2  <- "C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/10x_Kamil/Oscillation/"

list_of_files <- c(
	paste0(work2,"HmlerCTR_S1_DGE.txt"),
	paste0(work2,"Hmler2oscil_S2_DGE.txt"),
	paste0(work2,"hmler6ms_S2_DGE.txt"),
	paste0(work2,"hmler6mo_S1_DGE.txt"),
		paste0(work2,"hmlerConst_S2_DGE.txt")
)

condition_names <- c("CTR_S1","2oscil","6ms","6mo","Const")

dir.create("QC")
setwd("QC")
Return_fun <- create_cds(list_of_files=list_of_files,
                         condition_names=condition_names,
                         min.features =200,min.cells=10,remove_mt=TRUE,remove_ribsomal=TRUE,data_10x=FALSE, elbow = elbow,tool="seurat",imputation=FALSE)

Osci  <- Return_fun$Combined
Data_List <- Return_fun$Data_List
setwd("../")


dir.create("Clustering")
setwd("Clustering")

Osci <- reduce_dim(Osci,project=project)$Combined

pdf(paste(Sys.Date(),project,"tsne","Conditions.pdf",sep="_"))
plot_cells(Osci,target="condition",leg_pos="right",save=TRUE,ncol=1)
dev.off()
pdf(paste(Sys.Date(),project,"tsne","Cluster.pdf",sep="_"))
plot_cells(Osci,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
dev.off()


plot_nFeatures(Osci,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)
plot_tot_mRNA(Osci,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)


if(tolower(tool)=="seurat" & elbow){
    p3 <- DimPlot(object = Osci, reduction = "umap", group.by = "condition",cols = color_cond)
    p4 <- DimPlot(object = Osci, reduction = "umap", group.by = "Cluster", label = TRUE,cols = color_clust)
    pdf(paste(Sys.Date(),project,"umap","Seurat_Conditions.pdf",sep="_"))
    print(p3)
    dev.off()
    pdf(paste(Sys.Date(),project,"umap","Seurat_Clusters.pdf",sep="_"))
    print(p4)
    dev.off()
}

# ------------------------------------------------------------------------------------------------

setwd("../")

saveRDS(Osci,paste0("Osci_Clustered_",NewDir,".rds"))




count_mat_osci <-  as.matrix(Osci@assays$RNA@counts)
e_score_osci <-colSums(count_mat_osci[rownames(count_mat_osci) %in% em_return_fun$top_markers[1:50],])
m_score_osci <-colSums(count_mat_osci[rownames(count_mat_osci) %in% em_return_fun$top_markers[51:100],])
em_score_osci <- e_score_osci - m_score_osci 


Osci$VIM <- Osci@assays$RNA@counts["VIM",]



osci2 <- Osci[,Osci$condition=="CTR_S1"]
osci2 <- metrics_calc(osci2)$object
osci2 <- reduce_dim(osci2,project=project)$Combined


count_mat_osci2 <-  as.matrix(osci2@assays$RNA@counts)
e_score_osci2 <-colSums(count_mat_osci2[rownames(count_mat_osci2) %in% em_return_fun$top_markers[1:50],])
m_score_osci2 <-colSums(count_mat_osci2[rownames(count_mat_osci2) %in% em_return_fun$top_markers[51:100],])
em_score_osci2 <- e_score_osci2 - m_score_osci2

osci2$em_score <- em_score_osci2

temp_cl <- em_score_osci2
temp_cl[em_score_osci2<0] <- "Mesenchymal"
temp_cl[em_score_osci2>0] <- "Epithelial"
osci2$Cluster <- as.factor(temp_cl)

# =================================== DF ATP =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
em_return_fun <- df_genes(osci2,"Cluster",top_n=50,
	logfc.threshold=0.2,
	n_cores=4,
	latent.vars=c("nCount_RNA"),
	only.pos=TRUE)
setwd("../")






