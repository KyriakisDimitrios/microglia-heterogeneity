library(ICSWrapper)
library(scater)
library(sctransform)
library(Seurat)
library(scran)
set.seed(123)
tool="seurat"
project ="MBSYN"
dataset <- project
Data_select <- data_selection(project)

WORKDIR <- Data_select$WORKDIR
list_of_files <- Data_select$list_of_files
condition_names <- Data_select$condition_names
organism<- Data_select$organism
file<- Data_select$file
data_10x<- Data_select$data_10x

setwd(Data_select$WORKDIR)



colormap_d<- c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928',"black","gray")
color_cond  <- c(brewer.pal(8,"Dark2"),"black","gray","magenta4","seagreen4")
color_cond  <- c(brewer.pal(5,"Set1"),"black","gray","magenta4","seagreen4")
color_clust <- c(brewer.pal(12,"Paired")[-11],"black","gray","magenta4","seagreen4",brewer.pal(9,"Set1"))
color_clust <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")
color_cells <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")
color_list <- list(condition=color_cond,Cluster=color_clust,Cell_Type=color_cells,State=color_clust)
# color_cells <-primary.colors(15, steps = 3, no.white = TRUE)



# ================================ SETTING UP ======================================== #
# Number of cells to use
imputation = FALSE
remove_mt=TRUE
remove_ribsomal=TRUE
n_cores=5
elbow = FALSE


# setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-20_seurat_elbow_FALSE")
# Combined <- readRDS("Cell_Types_2019-11-20_seurat_elbow_FALSE.rds")

NewDir <- paste0(Sys.Date(),"_",tool,"_elbow_",elbow,"_remove_ribsomal_",remove_ribsomal)

dir.create(NewDir)
setwd(NewDir)


# setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-13_seurat_elbow_FALSE_SAVER")

# ==============================================================================================
# ================================ Setup the Seurat objects ====================================
# ==============================================================================================
# ======== Perform an integrated analysis ====
dir.create("QC")
setwd("QC")
# debugonce(load_files)
Return_fun <- create_cds(list_of_files=list_of_files,
                         condition_names=condition_names,
                         min.features =200,min.cells=5,
                         remove_mt=TRUE,
                         data_10x=data_10x,
                          elbow = elbow,
                         tool=tool,
                         imputation=imputation,
                        n_cores=2)

Combined  <- Return_fun$Combined
Data_List <- Return_fun$Data_List
setwd("../")

# ----------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------

saveRDS(Combined,paste0("Merged_",NewDir,".rds"))
# setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-13_seurat_elbow_FALSE_SAVER")
# Combined <- readRDS("Merged_2019-11-13_seurat_elbow_FALSE.rds")

# ==============================================================================================
# ======================================= Clustering  ==========================================
# ==============================================================================================
dir.create("Clustering")
setwd("Clustering")
# Combined <- ReduceDim(Combined,method="umap",project=project)$Combined
# debugonce(reduce_dim)
Combined <- reduce_dim(Combined,project=project)$Combined

pdf(paste(Sys.Date(),project,"tsne","Conditions.pdf",sep="_"))
plot_cells(Combined,target="condition",leg_pos="right",save=TRUE,ncol=1)
dev.off()
pdf(paste(Sys.Date(),project,"tsne","Cluster.pdf",sep="_"))
# debugonce(plot_cells)
plot_cells(Combined,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
dev.off()


plot_nFeatures(Combined,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)
plot_tot_mRNA(Combined,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)


if(tolower(tool)=="seurat" & elbow){
    p3 <- DimPlot(object = Combined, reduction = "umap", group.by = "condition",cols = color_cond)
    p4 <- DimPlot(object = Combined, reduction = "umap", group.by = "Cluster", label = TRUE,cols = color_clust)
    pdf(paste(Sys.Date(),project,"umap","Seurat_Conditions.pdf",sep="_"))
    print(p3)
    dev.off()
    pdf(paste(Sys.Date(),project,"umap","Seurat_Clusters.pdf",sep="_"))
    print(p4)
    dev.off()
}

# ------------------------------------------------------------------------------------------------

setwd("../")

saveRDS(Combined,paste0("Clustered_",NewDir,".rds"))

# Combined <- readRDS(paste0("Clustered_",NewDir,".rds"))

# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
return_fun <- df_genes(Combined,"condition",top_n=15,logfc.threshold=0, n_cores=4,
    latent.vars=c("nCount_RNA","Cluster"),
    only.pos=TRUE)
setwd("../")
# ------------------------------------------------------------------------------------------------




# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
return_fun <- df_genes(Combined,"Cluster",top_n=15,logfc.threshold=0.25, n_cores=4,latent.vars=c("nCount_RNA"),only.pos=TRUE)


library(stackoverflow)
cl_tops <- chunk2(return_fun$top_markers,length(unique(Combined$Cluster)))
list_bar_cl <- c()
for (i in cl_tops){
	list_bar_cl <- c(list_bar_cl,i[1:3])
}


library(clusterProfiler)
dir.create("GSEA")
setwd("GSEA")
# debugonce(gene_set_enrich)
sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05 & return_fun$degs$avg_logFC>1.5,]
universe <- rownames(Combined@assays$RNA@counts)

symbols = unlist(lapply(tolower(as.vector(sub_degs$gene)),simpleCap))
test <- split(symbols,sub_degs$cluster)

x=compareCluster(test, fun='enrichGO', OrgDb='org.Mm.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="BP")
pdf("enrichGO.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()

x2=compareCluster(test, fun='groupGO', OrgDb='org.Mm.eg.db',keyType="SYMBOL",ont="BP",level=2)

pdf("groupGO.pdf",width=12)
dotplot(x2, showCategory=10, includeAll=FALSE)
dev.off()

list_symbols <- list()
iter=0
for (i in names(test)){
	iter=iter+1
	eg=bitr(as.vector(test[[i]]),fromType = "SYMBOL",toType=c("SYMBOL","ENTREZID"),OrgDb='org.Mm.eg.db')$ENTREZID
	list_symbols[[i]] <-c(eg)
}

x3=compareCluster(list_symbols, fun='enrichKEGG', organism="mmu",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05)

pdf("enrichKEGG.pdf",width=12)
dotplot(x3, showCategory=10, includeAll=FALSE)
dev.off()




for (cl in unique(sub_degs$cluster)){
	dir.create(paste0("Cluster_",cl))
	setwd(paste0("Cluster_",cl))
	gene_symbols <- sub_degs[sub_degs$cluster==cl,]$gene
	ego <-gene_set_enrich(gene_symbols,organism=organism,ontology=c("BP","MF"),qval_thres=0.05,save=TRUE,title=cl)	
	# pdf(paste(Sys.Date(),"GSEA_Dotplot","Cluster",cl,".pdf",sep="_"),height=14,width=18)
	# print(barplot(ego, showCategory=30))
	# dev.off()
	# debugonce(david_enrich)
	das <- david_enrich(gene_symbols=gene_symbols,
		idents=NULL,organism=organism,
		qval_thres=0.05,save=TRUE,title=paste0("CL",cl))
	setwd("../")
}


setwd("../")
# ------------------------------------------------------------------------------------------------





dir.create("Cell_Types_Garnett")
setwd("Cell_Types_Garnett")
library(garnett)
Combined <- garnett_assignment(Combined ,organism="mouse",check_markers=FALSE)
# Combined <- garnett_assignment(Combined ,organism="skata",check_markers=FALSE)
pdf("Garnett_Cell_type.pdf")
plot_cells(Combined,target="cell_type")
plot_cells(Combined,target="cluster_ext_type")
plot_cells(Combined,target="garnett_cluster")
dev.off()
setwd("../")




# =================================== CELL TYPES =================================================
dir.create("Cell_Types")
setwd("Cell_Types")
gene_list_name <- "Cell_Type"
file <- paste0(WORKDIR,"/Gene_Lists/Paper_Cell_types.txt")
res_cell_type_assignment <- cell_type_assignment(object=Combined,tab_name="Cell_Type",file=file)
Combined = res_cell_type_assignment$object
r_annot = res_cell_type_assignment$r_annot

# if (elbow){
# 	cell_types <- Combined$Cell_Type
# 	save_cell_types<-Combined$Cell_Type
# 	cell_types[ which(Combined$Cluster %in% c(1))] <- "Microglia"
# 	cell_types[ which(Combined$Cluster %in% c(2))] <- "Oligodendrocytes"
# 	cell_types[ which(Combined$Cluster %in% c(3))] <- "Endothelial"
# 	cell_types[ which(Combined$Cluster %in% c(4))] <- "Astrocytes"
# 	cell_types[ which(Combined$Cluster %in% c(5))] <- "Neurons"
# 	cell_types[ which(Combined$Cluster %in% c(6,7))] <- "Ependymal"
# 	#cell_types[ which(Combined$Cluster %in% c(7))] <- "Unknown"
# 	Combined$Cell_Type <-cell_types
# }else{
# 	cell_types <- Combined$Cell_Type
# 	save_cell_types<-Combined$Cell_Type
# 	cell_types[ which(Combined$Cluster %in% c(1))] <- "Microglia"
# 	cell_types[ which(Combined$Cluster %in% c(2))] <- "Oligodendrocytes"
# 	cell_types[ which(Combined$Cluster %in% c(3))] <- "Endothelial"
# 	cell_types[ which(Combined$Cluster %in% c(4))] <- "Astrocytes"
# 	cell_types[ which(Combined$Cluster %in% c(5))] <- "Neurons"
# 	cell_types[ which(Combined$Cluster %in% c(6,7))] <- "Ependymal"
# 	#cell_types[ which(Combined$Cluster %in% c(7))] <- "Unknown"
# 	Combined$Cell_Type <-cell_types
# }
# cell_types <- Combined$Cell_Type
# save_cell_types<-Combined$Cell_Type
# cell_types[ which(Combined$Cluster %in% c(1))] <- "Oligodendrocytes"
# cell_types[ which(Combined$Cluster %in% c(2))] <- "Endothelial"
# cell_types[ which(Combined$Cluster %in% c(3))] <- "Astrocytes"
# cell_types[ which(Combined$Cluster %in% c(4,7))] <- "Microglia"
# cell_types[ which(Combined$Cluster %in% c(5))] <- "Neurons"
# cell_types[ which(Combined$Cluster %in% c(6))] <- "Ependymal"
# cell_types[ which(Combined$Cluster %in% c(9,8))] <- "Unknown"
# Combined$Cell_Type <-cell_types


# ============ ADVANCED QUALITY FILTERING =========================
cell_types <- Combined$Cell_Type
cell_types <- as.vector(Combined$Cluster)

save_cell_types<-Combined$Cell_Type
cell_types[ which(Combined$Cluster %in% c(1))] <- "Astrocytes"
cell_types[ which(Combined$Cluster %in% c(2))] <- "Microglia"
cell_types[ which(Combined$Cluster %in% c(3))] <- "Oligodendrocytes"
cell_types[ which(Combined$Cluster %in% c(4))] <- "Endothelial"
cell_types[ which(Combined$Cluster %in% c(6,7))] <- "Ependymal"
cell_types[ which(Combined$Cluster %in% c(5,8))] <- "Neurons"
cell_types[ which(Combined$Cluster %in% c(9))] <- "Hybrid"
Combined$Cell_Type <-cell_types

# ================================================================




# ======================================== DF CELL TYPES  =================================
dir.create("DF_Cell_Types")
setwd("DF_Cell_Types")
return_fun <- df_genes(Combined,"Cell_Type",top_n=50,logfc.threshold=1, n_cores=4,latent.vars=c("nCount_RNA"))
gene_list <- c("P2RY12","GJA1","MBP","LY6C2","TTR","ENPP2","PDGFRA","MEG3")
plot_bar_cells(gene_list,object=Combined,save=TRUE)
pie_per_CellType(Combined,target="Cell_Type")
plot_bar_cells(list_bar_cl[1:6],object=Combined,save=TRUE,title="1-6")
plot_bar_cells(list_bar_cl[7:12],object=Combined,save=TRUE,title="7-12")
plot_bar_cells(list_bar_cl[13:18],object=Combined,save=TRUE,title="13-18")
plot_bar_cells(list_bar_cl[19:24],object=Combined,save=TRUE,title="19-24")
plot_bar_cells(list_bar_cl[25:27],object=Combined,save=TRUE,title="25-27")
setwd("../")
# ------------------------------------------------------------------------------------------------

plot_bar_cells(list_bar_cl[1:6],object=Combined,save=TRUE,title="1-6",target="Cluster")
plot_bar_cells(list_bar_cl[7:12],object=Combined,save=TRUE,title="7-12",target="Cluster")
plot_bar_cells(list_bar_cl[13:18],object=Combined,save=TRUE,title="13-18",target="Cluster")
plot_bar_cells(list_bar_cl[19:24],object=Combined,save=TRUE,title="19-24",target="Cluster")
plot_bar_cells(list_bar_cl[25:27],object=Combined,save=TRUE,title="25-27",target="Cluster")

saveRDS(Combined,paste0("Cell_Types_",NewDir,".rds"))





p1 <- plot_cells(Combined,target="condition",leg_pos="right",save=TRUE,ncol=1)
p2 <-plot_cells(Combined,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
p3 <-plot_cells(Combined,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1)

pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

pdf(paste(Sys.Date(),project,"Cell_Type_tsne.pdf",sep="_"))
print(p3)
dev.off()
pdf(paste(Sys.Date(),project,"Condition_tsne.pdf",sep="_"))
print(p1)
dev.off()
pdf(paste(Sys.Date(),project,"Cluster_tsne.pdf",sep="_"))
print(p2)
dev.off()


p1 <- plot_cells(Combined,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p2 <-plot_cells(Combined,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p3 <-plot_cells(Combined,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="umap")

pdf(paste(Sys.Date(),project,"umap.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

pdf(paste(Sys.Date(),project,"Cell_Type_umap.pdf",sep="_"))
print(p3)
dev.off()
pdf(paste(Sys.Date(),project,"Condition_umap.pdf",sep="_"))
print(p1)
dev.off()
pdf(paste(Sys.Date(),project,"Cluster_umap.pdf",sep="_"))
print(p2)
dev.off()
# ------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------------------


# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ///////////////// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ///////////////// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ///////////////// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
library(ICSWrapper)
tool="seurat"
project ="MBSYN"
dataset <- project
Data_select <- data_selection(project)

WORKDIR <- Data_select$WORKDIR
list_of_files <- Data_select$list_of_files
condition_names <- Data_select$condition_names
organism<- Data_select$organism
file<- Data_select$file
data_10x<- Data_select$data_10x

setwd(Data_select$WORKDIR)



colormap_d<- c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928',"black","gray")
color_cond  <- c(brewer.pal(8,"Dark2"),"black","gray","magenta4","seagreen4")
color_cond  <- c(brewer.pal(5,"Set1"),"black","gray","magenta4","seagreen4")
color_clust <- c(brewer.pal(12,"Paired")[-11],"black","gray","magenta4","seagreen4",brewer.pal(9,"Set1"))
color_clust <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")
color_cells <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")
color_list <- list(condition=color_cond,Cluster=color_clust,Cell_Type=color_cells,State=color_clust)
# color_cells <-primary.colors(15, steps = 3, no.white = TRUE)



# ================================ SETTING UP ======================================== #
# Number of cells to use
imputation = FALSE
remove_mt=TRUE
remove_ribsomal=TRUE
n_cores=5
elbow = FALSE
setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-12-02_seurat_elbow_FALSE_remove_ribsomal_TRUE")
Combined <- readRDS("Cell_Types_2019-12-02_seurat_elbow_FALSE_remove_ribsomal_TRUE.rds")
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ///////////////// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ///////////////// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! ///////////////// <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

# Combined$Cell_Type <- Combined$cluster_ext_type






# ======================================== Microglia Analysis  =================================
dir.create("Microglia_Analysis_counts")
setwd("Microglia_Analysis_counts")
# debugonce(object_subset)
Micro_Sub <- object_subset(object=Combined,Conditions=NULL,Clusters=NULL,Cell_Types=c("Microglia") )
DefaultAssay(Micro_Sub) <- "RNA"
Micro_Sub <- reduce_dim(Micro_Sub,project=project,resolution=c(1.2))$Combined



gene_list <- c("P2RY12","GJA1","MBP","LY6C2","TTR","ENPP2","PDGFRA","MEG3")
plot_bar_cells(gene_list,object=Micro_Sub,save=TRUE,target="Cluster")


p1<-plot_cells(Micro_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p2<-plot_cells(Micro_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p3<-plot_cells(Micro_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="umap")

pdf(paste(Sys.Date(),project,"umap.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

p1<-plot_cells(Micro_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
p2<-plot_cells(Micro_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
p3<-plot_cells(Micro_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")

pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

# =================================== DF Conditions =================================================
# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
return_fun <- df_genes(Micro_Sub,"condition",top_n=15,logfc.threshold=0.15,n_cores=4,latent.vars=c("nCount_RNA"),only.pos=TRUE)
setwd("../")
# ---------------------------------------------------------------------------------------------




# =================================== DF Clusters =================================================
# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
return_fun <- df_genes(Micro_Sub,"Cluster",top_n=30,logfc.threshold=0 ,n_cores=4,latent.vars=c("nCount_RNA"),only.pos=TRUE)


gene_list <- c("LGMN","MARCKS","P2RY12","FCRLS","CSF1R","SERINC3")
plot_bar_cells(gene_list,object=Micro_Sub,save=TRUE,target="Cluster",title="Homeostatic")


library(clusterProfiler)
dir.create("GSEA")
setwd("GSEA")
# debugonce(gene_set_enrich)
sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05 & return_fun$degs$avg_logFC>1.5,]
universe <- rownames(Micro_Sub@assays$RNA@counts)

symbols = unlist(lapply(tolower(as.vector(sub_degs$gene)),simpleCap))
test <- split(symbols,sub_degs$cluster)

x=compareCluster(test, fun='enrichGO', OrgDb='org.Mm.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="BP")
pdf("enrichGO.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()
setwd("../")

# =============================== PAIRWISE DF ===============================================
# =============================== PAIRWISE DF ===============================================
# dir.create("DF_Pairwise")
# setwd("DF_Pairwise")
# Idents(Micro_Sub) <- Micro_Sub$Cluster
# cl_combinations <- combn(levels(Micro_Sub$Cluster),2)

pairwise_df <- function (comb,cl_combinations,object){
    title <- paste(cl_combinations[,comb],collapse = "_")
    dir.create(title)
    setwd(title)
    target <- "Cluster"
    idents <- as.vector(cl_combinations[,comb])
    ident.1 <- idents[1]    
    ident.2 <- idents[2]
    
    
    cells_index <- object$Cluster%in%c(ident.1,ident.2)
    temp_object <- subset(x=object,cells=colnames(object)[cells_index])

    
    temp_object <- ScaleData(temp_object)
    DefaultAssay(object) <- "RNA"
    pbmc.markers <- FindAllMarkers(object = temp_object,
                                           assay ="RNA",
                                           logfc.threshold=0,
                                           only.pos = TRUE,
                                           test.use = "MAST",latent.vars = c("nCount_RNA"))
    pbmc.markers$gene <- rownames(pbmc.markers)
    qvalue <- p.adjust(pbmc.markers$p_val, method = "BH",n=dim(temp_object@assays$RNA@counts)[1])
    pbmc.markers$qvalue <- qvalue
    top <- pbmc.markers[pbmc.markers$qvalue<0.05,]
    top10 <- top %>% top_n(n = 50, wt = abs(avg_logFC))
    top10_genes<- top10$gene
    temp <- temp_object[,temp_object$Cluster%in%c(ident.1,ident.2)]
    temp$Cluster <- as.factor(as.vector(temp$Cluster))

    # debugonce(annotated_heat)
    annotated_heat(object=temp,
                      row_annotation=c(1),
                      gene_list=top10_genes,
                      Rowv=TRUE,
                      gene_list_name="DF_genes",
                      title=title,
                      ordering="Cluster")

    DefaultAssay(temp_object) <- "integrated"
    write.table(pbmc.markers, file = paste0(Sys.Date(),"_TO_EXP_each_",target,"_",title,".tsv"),row.names=FALSE, na="", sep="\t")

    test <- split(top$gene,top$cluster)

    x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                            pvalueCutoff  = 0.05,ont="BP")
    pdf(paste0(Sys.Date(),"_enrichGO_BP_",target,"_",title,".pdf"),width=12,height=10)
    dotplot(x, showCategory=5, includeAll=FALSE)
    dev.off()

    x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                            pvalueCutoff  = 0.05,ont="MF")
    pdf(paste0(Sys.Date(),"_enrichGO_MF_",target,"_",title,".pdf"),width=12,height=10)
    dotplot(x, showCategory=5, includeAll=FALSE)
    dev.off()
    pbmc.markers[c("LGMN","MARCKS","P2RY12","FCRLS","CSF1R","SERINC3"),]
    setwd("../")
}


# lapply(c(1:dim(cl_combinations)[2]),FUN=pairwise_df,cl_combinations=cl_combinations,object=Micro_Sub)

# Homeostatic <- c(grep("FCRLS",return_fun$degs$gene),
# grep("LGMN",return_fun$degs$gene),
# grep("MARCKS",return_fun$degs$gene),
# grep("CSF1R",return_fun$degs$gene),
# grep("P2RY12",return_fun$degs$gene),
# grep("SERINC3",return_fun$degs$gene))

# return_fun$degs[Homeostatic,]
# setwd("../")


# ============================= REANALUSIS ===============================
# ============================= REANALUSIS ===============================
# ============================= REANALUSIS ===============================

dir.create("Reanalysis")
setwd("Reanalysis")
Micro_Sub2 <- object_subset(object=Micro_Sub,Conditions=NULL,Clusters=c(1,2,3,4,6),Cell_Types=NULL )
DefaultAssay(Micro_Sub2) <- "RNA"
Micro_Sub2 <- reduce_dim(Micro_Sub2,project=project,resolution=c(1.2))$Combined
gene_list <- c("P2RY12","GJA1","MBP","LY6C2","TTR","ENPP2","PDGFRA","MEG3")
plot_bar_cells(gene_list,object=Micro_Sub2,save=TRUE,target="Cluster")


p1<-plot_cells(Micro_Sub2,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p2<-plot_cells(Micro_Sub2,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p3<-plot_cells(Micro_Sub2,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="umap")

pdf(paste(Sys.Date(),project,"umap.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

p1<-plot_cells(Micro_Sub2,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
p2<-plot_cells(Micro_Sub2,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
p3<-plot_cells(Micro_Sub2,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")

pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

# =================================== DF Conditions =================================================
# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
return_fun <- df_genes(Micro_Sub2,"condition",top_n=15,logfc.threshold=0.15,n_cores=4,latent.vars=c("nCount_RNA"),only.pos=TRUE)
setwd("../")
# ---------------------------------------------------------------------------------------------

# =================================== DF Clusters =================================================
# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
return_fun <- df_genes(Micro_Sub2,"Cluster",top_n=30,logfc.threshold=0 ,n_cores=4,latent.vars=c("nCount_RNA"),only.pos=TRUE)


gene_list <- c("LGMN","MARCKS","P2RY12","FCRLS","CSF1R","SERINC3")
plot_bar_cells(gene_list,object=Micro_Sub2,save=TRUE,target="Cluster",title="Homeostatic")


library(clusterProfiler)
dir.create("GSEA")
setwd("GSEA")
# debugonce(gene_set_enrich)
sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05 & return_fun$degs$avg_logFC>1.5,]
universe <- rownames(Micro_Sub2@assays$RNA@counts)

symbols = unlist(lapply(tolower(as.vector(sub_degs$gene)),simpleCap))
test <- split(symbols,sub_degs$cluster)

x=compareCluster(test, fun='enrichGO', OrgDb='org.Mm.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="BP")
pdf("enrichGO.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()
setwd("../")
setwd("../")
setwd("../")

# =============================== PAIRWISE DF ===============================================
# =============================== PAIRWISE DF ===============================================
# dir.create("DF_Pairwise")
# setwd("DF_Pairwise")
# Idents(Micro_Sub2) <- Micro_Sub2$Cluster
# cl_combinations <- combn(levels(Micro_Sub2$Cluster),2)

# lapply(c(1:dim(cl_combinations)[2]),FUN=pairwise_df,cl_combinations=cl_combinations,object=Micro_Sub2)

# Homeostatic <- c(grep("FCRLS",return_fun$degs$gene),
# grep("LGMN",return_fun$degs$gene),
# grep("MARCKS",return_fun$degs$gene),
# grep("CSF1R",return_fun$degs$gene),
# grep("P2RY12",return_fun$degs$gene),
# grep("SERINC3",return_fun$degs$gene))

# return_fun$degs[Homeostatic,]
# setwd("../")

# setwd("../")
# ----------------------------------------------------------------------------------------------



# =============================== Microglia Analysis Integraded  ===============================
# =============================== Microglia Analysis Integraded  ===============================
# ======================================== Microglia Analysis  =================================
dir.create("Microglia_Analysis_integrated")
setwd("Microglia_Analysis_integrated")
# debugonce(object_subset)
Micro_Sub <- object_subset(object=Combined,Conditions=NULL,Clusters=NULL,Cell_Types=c("Microglia") )
DefaultAssay(Micro_Sub) <- "integrated"
Micro_Sub <- reduce_dim(Micro_Sub,project=project,resolution=c(1.2))$Combined



gene_list <- c("P2RY12","GJA1","MBP","LY6C2","TTR","ENPP2","PDGFRA","MEG3")
plot_bar_cells(gene_list,object=Micro_Sub,save=TRUE,target="Cluster")


p1<-plot_cells(Micro_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p2<-plot_cells(Micro_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p3<-plot_cells(Micro_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="umap")

pdf(paste(Sys.Date(),project,"umap.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

p1<-plot_cells(Micro_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
p2<-plot_cells(Micro_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
p3<-plot_cells(Micro_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")

pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

# =================================== DF Conditions =================================================
# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
return_fun <- df_genes(Micro_Sub,"condition",top_n=15,logfc.threshold=0.15,n_cores=4,latent.vars=c("nCount_RNA"),only.pos=TRUE)
setwd("../")
# ---------------------------------------------------------------------------------------------




# =================================== DF Clusters =================================================
# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
return_fun <- df_genes(Micro_Sub,"Cluster",top_n=30,logfc.threshold=0 ,n_cores=4,latent.vars=c("nCount_RNA"),only.pos=TRUE)


gene_list <- c("LGMN","MARCKS","P2RY12","FCRLS","CSF1R","SERINC3")
plot_bar_cells(gene_list,object=Micro_Sub,save=TRUE,target="Cluster",title="Homeostatic")


library(clusterProfiler)
dir.create("GSEA")
setwd("GSEA")
# debugonce(gene_set_enrich)
sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05 & return_fun$degs$avg_logFC>1.5,]
universe <- rownames(Micro_Sub@assays$RNA@counts)

symbols = unlist(lapply(tolower(as.vector(sub_degs$gene)),simpleCap))
test <- split(symbols,sub_degs$cluster)

x=compareCluster(test, fun='enrichGO', OrgDb='org.Mm.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="BP")
pdf("enrichGO.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()
setwd("../")

# =============================== PAIRWISE DF ===============================================
# =============================== PAIRWISE DF ===============================================
# dir.create("DF_Pairwise")
# setwd("DF_Pairwise")
# Idents(Micro_Sub) <- Micro_Sub$Cluster
# cl_combinations <- combn(levels(Micro_Sub$Cluster),2)


# lapply(c(1:dim(cl_combinations)[2]),FUN=pairwise_df,cl_combinations=cl_combinations,object=Micro_Sub)

# Homeostatic <- c(grep("FCRLS",return_fun$degs$gene),
# grep("LGMN",return_fun$degs$gene),
# grep("MARCKS",return_fun$degs$gene),
# grep("CSF1R",return_fun$degs$gene),
# grep("P2RY12",return_fun$degs$gene),
# grep("SERINC3",return_fun$degs$gene))

# return_fun$degs[Homeostatic,]
# setwd("../")


# ============================= REANALUSIS ===============================
# ============================= REANALUSIS ===============================
# ============================= REANALUSIS ===============================

dir.create("Reanalysis")
setwd("Reanalysis")
Micro_Sub2 <- object_subset(object=Micro_Sub,Conditions=NULL,Clusters=c(1,2,3),Cell_Types=NULL )
DefaultAssay(Micro_Sub2) <- "RNA"
Micro_Sub2 <- reduce_dim(Micro_Sub2,project=project,resolution=c(1.2))$Combined
gene_list <- c("P2RY12","GJA1","MBP","LY6C2","TTR","ENPP2","PDGFRA","MEG3")
plot_bar_cells(gene_list,object=Micro_Sub2,save=TRUE,target="Cluster")


p1<-plot_cells(Micro_Sub2,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p2<-plot_cells(Micro_Sub2,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
p3<-plot_cells(Micro_Sub2,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="umap")

pdf(paste(Sys.Date(),project,"umap.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

p1<-plot_cells(Micro_Sub2,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
p2<-plot_cells(Micro_Sub2,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
p3<-plot_cells(Micro_Sub2,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")

pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
print(plot_grid(p1, p2,p3,ncol = 3))
dev.off()

# =================================== DF Conditions =================================================
# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
return_fun <- df_genes(Micro_Sub2,"condition",top_n=15,logfc.threshold=0.15,n_cores=4,latent.vars=c("nCount_RNA"),only.pos=TRUE)
setwd("../")
# ---------------------------------------------------------------------------------------------

# =================================== DF Clusters =================================================
# =================================== DF Clusters =================================================
dir.create("DF_Clusters")
setwd("DF_Clusters")
return_fun <- df_genes(Micro_Sub2,"Cluster",top_n=30,logfc.threshold=0 ,n_cores=4,latent.vars=c("nCount_RNA"),only.pos=TRUE)


gene_list <- c("LGMN","MARCKS","P2RY12","FCRLS","CSF1R","SERINC3")
plot_bar_cells(gene_list,object=Micro_Sub2,save=TRUE,target="Cluster",title="Homeostatic")


library(clusterProfiler)
dir.create("GSEA")
setwd("GSEA")
# debugonce(gene_set_enrich)
sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05 & return_fun$degs$avg_logFC>1.5,]
universe <- rownames(Micro_Sub2@assays$RNA@counts)

symbols = unlist(lapply(tolower(as.vector(sub_degs$gene)),simpleCap))
test <- split(symbols,sub_degs$cluster)

x=compareCluster(test, fun='enrichGO', OrgDb='org.Mm.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
                        pvalueCutoff  = 0.05,ont="BP")
pdf("enrichGO.pdf",width=12,height=10)
dotplot(x, showCategory=5, includeAll=FALSE)
dev.off()
setwd("../")

# =============================== PAIRWISE DF ===============================================
# =============================== PAIRWISE DF ===============================================
# dir.create("DF_Pairwise")
# setwd("DF_Pairwise")
# Idents(Micro_Sub2) <- Micro_Sub2$Cluster
# cl_combinations <- combn(levels(Micro_Sub2$Cluster),2)

# lapply(c(1:dim(cl_combinations)[2]),FUN=pairwise_df,cl_combinations=cl_combinations,object=Micro_Sub2)

# Homeostatic <- c(grep("FCRLS",return_fun$degs$gene),
# grep("LGMN",return_fun$degs$gene),
# grep("MARCKS",return_fun$degs$gene),
# grep("CSF1R",return_fun$degs$gene),
# grep("P2RY12",return_fun$degs$gene),
# grep("SERINC3",return_fun$degs$gene))

# return_fun$degs[Homeostatic,]
# setwd("../")

# setwd("../")




# cl_combinations=cl_combinations,
# object=Micro_Sub2
# title <- paste(cl_combinations[,comb],collapse = "_")
# dir.create(title)
# setwd(title)
# target <- "Cluster"
# idents <- as.vector(cl_combinations[,comb])
# ident.1 <- idents[1]    
# ident.2 <- idents[2]


# cells_index <- object$Cluster%in%c(ident.1,ident.2)
# temp_object <- subset(x=object,cells=colnames(object)[cells_index])


# temp_object <- ScaleData(temp_object)
# DefaultAssay(object) <- "RNA"
# pbmc.markers <- FindAllMarkers(object = temp_object,
#                                        assay ="RNA",
#                                        logfc.threshold=0,min.pct = 0,
#                                        only.pos = TRUE,
#                                        test.use = "MAST",latent.vars = c("nCount_RNA"))
# pbmc.markers$gene <- rownames(pbmc.markers)
# qvalue <- p.adjust(pbmc.markers$p_val, method = "BH",n=dim(temp_object@assays$RNA@counts)[1])
# pbmc.markers$qvalue <- qvalue
# top <- pbmc.markers[pbmc.markers$qvalue<0.05,]
# top10 <- top %>% top_n(n = 50, wt = abs(avg_logFC))
# top10_genes<- top10$gene
# temp <- temp_object[,temp_object$Cluster%in%c(ident.1,ident.2)]
# temp$Cluster <- as.factor(as.vector(temp$Cluster))

# # debugonce(annotated_heat)
# annotated_heat(object=temp,
#                   row_annotation=c(1),
#                   gene_list=top10_genes,
#                   Rowv=TRUE,
#                   gene_list_name="DF_genes",
#                   title=title,
#                   ordering="Cluster")

# DefaultAssay(temp_object) <- "integrated"
# write.table(pbmc.markers, file = paste0(Sys.Date(),"_TO_EXP_each_",target,"_",title,".tsv"),row.names=FALSE, na="", sep="\t")

# test <- split(top$gene,top$cluster)

# x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
#                         pvalueCutoff  = 0.05,ont="BP")
# pdf(paste0(Sys.Date(),"_enrichGO_BP_",target,"_",title,".pdf"),width=12,height=10)
# dotplot(x, showCategory=5, includeAll=FALSE)
# dev.off()

# x=compareCluster(test, fun='enrichGO', OrgDb='org.Hs.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
#                         pvalueCutoff  = 0.05,ont="MF")
# pdf(paste0(Sys.Date(),"_enrichGO_MF_",target,"_",title,".pdf"),width=12,height=10)
# dotplot(x, showCategory=5, includeAll=FALSE)
# dev.off()
# pbmc.markers[c("LGMN","MARCKS","P2RY12","FCRLS","CSF1R","SERINC3"),]
# setwd("../")




































# dir.create("Reanalysis")
# setwd("Reanalysis")
# #Remove Oligos from Microglia
# Micro_Sub2 <- object_subset(object=Micro_Sub,Conditions=NULL,Clusters=c(1,2,3),Cell_Types=c("Microglia"),re_project=FALSE)
# Micro_Sub2$Cluster<-as.factor(as.vector(Micro_Sub2$Cluster))
# Micro_Sub2 <- reduce_dim(Micro_Sub2,project=project)$Combined

# p1 <- plot_cells(Micro_Sub2,target="condition",leg_pos="right",save=TRUE,ncol=1)
# p2 <-plot_cells(Micro_Sub2,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
# p3 <-plot_cells(Micro_Sub2,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1 )
# pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
# print(plot_grid(p1, p2,p3,ncol = 3))
# dev.off()

# pdf(paste(Sys.Date(),project,"Cell_Type_tsne.pdf",sep="_"))
# print(p3)
# dev.off()
# pdf(paste(Sys.Date(),project,"Condition_tsne.pdf",sep="_"))
# print(p1)
# dev.off()
# pdf(paste(Sys.Date(),project,"Cluster_tsne.pdf",sep="_"))
# print(p2)
# dev.off()

# dir.create("DF_Clusters")
# setwd("DF_Clusters")
# return_fun <- df_genes(Micro_Sub2,"Cluster",top_n=50,logfc.threshold=0.8 ,n_cores=4,latent.vars=c("nCount_RNA"))
# setwd("../")









# gene_list <- c("JUN","JUND","FOSB","PLP1")
# plot_bar_cells(gene_list,object=Micro_Sub,save=TRUE,target="Cluster")

# cells_list <- c("AAGAATAGGATC_1",
# "GCGCTTTGTGGA_1",
# "TAAATCCGAGTC_1",
# "CCACACTTTACG_1",
# "CAAGCGAAGTGA_1",
# "GTACTTAATTCC_1",
# "TAGCCCCAGAGT_1",
# "AGCGTGGGGTAT_1",
# "CCTCCGAACTGA_1",
# "TTTACACTTAGG_2",
# "TAAAGACTCGCG_2",
# "GCCATGCGAGGG_2",
# "GGTGTTTGAATC_2",
# "ACTCAGGCACTA_2",
# "GCCATGCGAGGA_2",
# "GCCATGCGAGGC_2",
# "GCCATGCGAGGT_2")

# gene_list <- c("LGMN","MARCKS","P2RY12","FCRLS","CSF1R","SERINC3")
# plot_bar_cells(gene_list,object=Micro_Sub,save=TRUE,target="Cluster",title="Homeostatic")

# counts_mat <- as.matrix(Micro_Sub@assays$RNA@counts)
# intergraded_mat <- as.matrix(Micro_Sub@assays$integrated@data)
# scaled_mat <- Micro_Sub@assays$integrated@scale.data
# clusters <- Micro_Sub$Cluster	
# mat <- counts_mat
# mat <- intergraded_mat

# mat2 <- as.data.frame(cbind(t(mat[rownames(mat)%in%gene_list,]),as.factor(clusters)))

# plot_list <- list()
# for (gene in gene_list){
# 	p <- ggplot(mat2, aes(x=clusters , y=gene )) + 
#   		geom_violin()
#   	plot_list[[gene]] <- p
# }
# grid.arrange(grobs =plot_list,nrow=6)

# p <- ggplot(mat2, aes(x=clusters , y=CSF1R )) + 
#   geom_violin()

# p <- ggplot(mat2, aes(x=clusters , y=CSF1R )) + 
#   geom_violin()

# p <- ggplot(mat2, aes(x=clusters , y=CSF1R )) + 
#   geom_violin()



# # =================================== DF Conditions =================================================
# dir.create("DF_Conditions2")
# setwd("DF_Conditions2")
# DefaultAssay(Combined) <- "RNA"
# return_fun <- df_genes(Micro_Sub,"condition",top_n=15,logfc.threshold=0.15 ,n_cores=4)
# DefaultAssay(Combined) <- "integrated"
# setwd("../")
# # ------------------------------------------------------------------------------------------------



# # =================================== DF Clusters =================================================
# dir.create("DF_Clusters")
# setwd("DF_Clusters")
# return_fun <- df_genes(Micro_Sub,"Cluster",top_n=15,logfc.threshold=0.15 ,n_cores=4)
# setwd("../")



# library(stackoverflow)
# cl_tops <- chunk2(return_fun$top_markers,length(unique(Micro_Sub$Cluster)))
# list_bar_cl <- c()
# for (i in cl_tops){
# 	list_bar_cl <- c(list_bar_cl,i[1:3])
# }
# plot_bar_cells(list_bar_cl[1:3],object=Micro_Sub,save=TRUE,title="CL1",target="Cluster")
# plot_bar_cells(list_bar_cl[4:6],object=Micro_Sub,save=TRUE,title="CL2",target="Cluster")
# plot_bar_cells(list_bar_cl[6:9],object=Micro_Sub,save=TRUE,title="CL3",target="Cluster")




# dir.create("GSEA")
# setwd("GSEA")

# sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05 & return_fun$degs$avg_logFC>1.5,]
# sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05,]
# universe <- rownames(Combined@assays$RNA@counts)

# symbols = unlist(lapply(tolower(as.vector(sub_degs$gene)),simpleCap))
# test <- split(symbols,sub_degs$cluster)

# x=compareCluster(test, fun='enrichGO', OrgDb='org.Mm.eg.db',keyType="SYMBOL",pAdjustMethod = "BH",
#                         pvalueCutoff  = 0.05,ont="BP")
# pdf("enrichGO.pdf",width=12,height=10)
# dotplot(x, showCategory=5, includeAll=FALSE)
# dev.off()

# x2=compareCluster(test, fun='groupGO', OrgDb='org.Mm.eg.db',keyType="SYMBOL",ont="BP",level=2)

# pdf("groupGO.pdf",width=12)
# dotplot(x2, showCategory=10, includeAll=FALSE)
# dev.off()

# list_symbols <- list()
# iter=0
# for (i in names(test)){
# 	iter=iter+1
# 	eg=bitr(as.vector(test[[i]]),fromType = "SYMBOL",toType=c("SYMBOL","ENTREZID"),OrgDb='org.Mm.eg.db')$ENTREZID
# 	list_symbols[[i]] <-c(eg)
# }

# x3=compareCluster(list_symbols, fun='enrichKEGG', organism="mmu",pAdjustMethod = "BH",
#                         pvalueCutoff  = 0.05)

# pdf("enrichKEGG.pdf",width=12)
# dotplot(x3, showCategory=10, includeAll=FALSE)
# dev.off()



# # debugonce(gene_set_enrich)
# sub_degs <- return_fun$degs[return_fun$degs$p_val_adj<0.05 & return_fun$degs$avg_logFC>1.5,]
# universe <- rownames(Combined@assays$RNA@counts)
# for (cl in unique(sub_degs$cluster)){
# 	dir.create(paste0("Cluster_",cl))
# 	setwd(paste0("Cluster_",cl))
# 	gene_symbols <- sub_degs[sub_degs$cluster==cl,]$gene
# 	ego <-gene_set_enrich(gene_symbols,universe=universe,organism,ontology=c("BP","MF"),qval_thres=0.05,save=TRUE,title=cl)	
# 	# pdf(paste(Sys.Date(),"GSEA_Dotplot","Cluster",cl,".pdf",sep="_"),height=14,width=18)
# 	# print(barplot(ego, showCategory=30))
# 	# dev.off()
# 	das <- david_enrich(gene_symbols=gene_symbols,
# 		idents=NULL,
# 		universe=universe,organism=organism,
# 		qval_thres=0.05,save=TRUE,title=paste0("CL",cl))
# 	setwd("../")
# }

# setwd("../")


# setwd("../")
# # ------------------------------------------------------------------------------------------------

# # =================================== Pseudotime =================================================
# dir.create("Pseudotime")
# setwd("Pseudotime")
# # debugonce(df_pseudotime)
# astro_pseudo <-df_pseudotime(Micro_Sub,reducedDim="DiffMap",reverse=FALSE,method="slingshot")
# setwd("../")
# # ------------------------------------------------------------------------------------------------
# setwd("../")
# # -----------------------------------------------------------------------------------------------


# find . -type f -name '*.pdf' -print0 |
#   while IFS= read -r -d '' file
#     do convert -verbose -density 300  "${file}" "TIFF/${file%.*}.tiff"
#   done

# convert ../*.pdf  -set filename:fname '%t_tn' +adjoin '%[filename:fname].tiff' -density=1200


# # ======================================== Hybrid Analysis  =================================
# dir.create("Hybrid_Analysis")
# setwd("Hybrid_Analysis")
# debugonce(object_subset)


# Hybrid_Sub <- object_subset(object=Combined,Conditions=NULL,Clusters=NULL,Cell_Types=c("Hybrid"))



# p1 <- plot_cells(Hybrid_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1)
# p2 <-plot_cells(Hybrid_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
# p3 <-plot_cells(Hybrid_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1 )
# pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
# print(plot_grid(p1, p2,p3,ncol = 3))
# dev.off()

# pdf(paste(Sys.Date(),project,"Cell_Type_tsne.pdf",sep="_"))
# print(p3)
# dev.off()
# pdf(paste(Sys.Date(),project,"Condition_tsne.pdf",sep="_"))
# print(p1)
# dev.off()
# pdf(paste(Sys.Date(),project,"Cluster_tsne.pdf",sep="_"))
# print(p2)
# dev.off()



# # =================================== DF Conditions =================================================
# dir.create("DF_Conditions")
# setwd("DF_Conditions")
# return_fun <- df_genes(Hybrid_Sub,"condition",top_n=15,logfc.threshold=0.25 ,n_cores=4)
# setwd("../")
# # ------------------------------------------------------------------------------------------------
# # =================================== DF Clusters =================================================
# dir.create("DF_Clusters")
# setwd("DF_Clusters")
# return_fun <- df_genes(Hybrid_Sub,"Cluster",top_n=15,logfc.threshold=0.25 ,n_cores=4)
# setwd("../")
# # ------------------------------------------------------------------------------------------------

# # =================================== Pseudotime =================================================
# dir.create("Pseudotime")
# setwd("Pseudotime")
# # debugonce(df_pseudotime)
# astro_pseudo <-df_pseudotime(Hybrid_Sub,reducedDim="DiffMap",reverse=FALSE,method="slingshot")
# setwd("../")
# # ------------------------------------------------------------------------------------------------
# setwd("../")
# # -----------------------------------------------------------------------------------------------















# # setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-20_seurat_elbow_FALSE")
# # Combined <- readRDS("Cell_Types_2019-11-20_seurat_elbow_FALSE.rds")
# # setwd("../")

# dir.create("Rescue")
# setwd("Rescue")
# Rescue_counts <- as.matrix(Combined@assays$RNA@counts)
# Corrected <- ComBat(Rescue_counts,Combined$condition)
# combat_edata2 = ComBat(dat=Rescue_counts, batch=Combined$condition, mod=NULL, par.prior=FALSE, mean.only=TRUE)
# f.out2 <- fastMNN(Rescue_counts, batch=Combined$condition)
# f.out2 <- logNormCounts(f.out2)
# manno <- runPCA(f.out2)
# manno.seurat <- as.Seurat(manno, counts = "counts", data = "logcounts")

# Rescue <- CreateSeuratObject(counts = combat_edata2, project = "all",
#                                  min.cells = 5,
#                                  min.features = 200)

# dim(Rescue)
# dim(Combined)
# Rescue$stim <- Combined$stim[colnames(Combined)%in%colnames(Rescue)]
# Rescue$condition <- Combined$condition[colnames(Combined)%in%colnames(Rescue)]

# # ====================== Normalization ====================
# Rescue <- NormalizeData(object = Rescue, normalization.method = "LogNormalize", scale.factor = 10000)
# # ----------------------------------------------


# # ====== Identification of highly variable features (feature selection)
# Rescue <- FindVariableFeatures(object = Rescue, selection.method = "vst", nfeatures = 2000)

# #Rescue <- ScaleData(object = Rescue, vars.to.regress = c("nUMI", "percent.mito"), display.progress = FALSE)

# # Identify the 10 most highly variable genes
# top10 <- head(x = VariableFeatures(object = Rescue), 10)

# # plot variable features with and without labels
# plot1 <- VariableFeaturePlot(object = Rescue)
# plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
# # CombinePlots(plots = list(plot1, plot2))
# pdf(paste(Sys.Date(),"_top10_var_feat_",Rescue$stim,".pdf"))
# print(plot2)
# dev.off()


# dir.create("Clustering")
# setwd("Clustering")
# Rescue <- reduce_dim(Rescue,project=project)$Combined

# pdf(paste(Sys.Date(),project,"tsne","Conditions.pdf",sep="_"))
# plot_cells(Rescue,target="condition",leg_pos="right",save=TRUE,ncol=1)
# dev.off()
# pdf(paste(Sys.Date(),project,"tsne","Cluster.pdf",sep="_"))
# # debugonce(plot_cells)
# plot_cells(Rescue,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
# dev.off()


# plot_nFeatures(Rescue,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)
# plot_tot_mRNA(Rescue,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)






# Rescue$Cell_Type <- as.vector(Rescue$Cluster) 
# Rescue$Cell_Type[Rescue$Cell_Type==4] <- "Microglia"
# # ======================================== Microglia Analysis  =================================
# dir.create("Microglia_Analysis")
# setwd("Microglia_Analysis")
# Micro_Sub <- object_subset(object=Rescue,Conditions=NULL,Clusters=c(4),Cell_Types="Microglia" )

# gene_list <- c("P2RY12","GJA1","MBP","LY6C2","TTR","ENPP2","PDGFRA","MEG3")
# plot_bar_cells(gene_list,object=Micro_Sub,save=TRUE)



# gene_list <- c("LGMN","MARCKS","P2RY12","FCRLS","CSF1R","SERINC3")
# plot_bar_cells(gene_list,object=Micro_Sub,save=TRUE,target="Cluster",title="Homeostatic")


# # =================================== DF Clusters =================================================
# dir.create("DF_Clusters")
# setwd("DF_Clusters")
# # debugonce(df_genes)
# return_fun <- df_genes(Micro_Sub,"Cluster",top_n=80,logfc.threshold=0.15 ,n_cores=4)
# setwd("../")




# dir.create("DF_Conditions")
# setwd("DF_Conditions")
# # debugonce(df_genes)
# return_fun <- df_genes(Micro_Sub,"condition",top_n=50,logfc.threshold=0.15 ,n_cores=4)
# setwd("../")








# # ===================== STEFANO 
# setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-25_seurat_elbow_FALSE_remove_ribsomal_TRUE")
# #saveRDS(Oihane,"Cell_Types_2019-11-25_seurat_elbow_FALSE_remove_ribsomal_TRUE.rds")
# Oihane <- readRDS("Cell_Types_2019-11-25_seurat_elbow_FALSE_remove_ribsomal_TRUE.rds")
# project ="MBSYN"
# dataset <- project

# plot_cells(Oihane,target="Cell_Type")


# dir.create("Microglia")
# setwd("Microglia")
# # ===== Subsetting =====
# Micro_Sub <- object_subset(object=Oihane,Conditions=NULL,Clusters=NULL,Cell_Types=c("Microglia") )
# # ===== DM Reduction ===
# Micro_Sub <- reduce_dim(Micro_Sub,project=project,resolution=c(1.2))$Combined

# gene_list <- c("P2RY12","GJA1","MBP","LY6C2","TTR","ENPP2","PDGFRA","MEG3")
# plot_bar_cells(gene_list,object=Micro_Sub,save=TRUE,target="Cluster")


# p1<-plot_cells(Micro_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
# p2<-plot_cells(Micro_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="umap")
# p3<-plot_cells(Micro_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="umap")

# pdf(paste(Sys.Date(),project,"umap.pdf",sep="_"),width=16,height=8)
# print(plot_grid(p1, p2,p3,ncol = 3))
# dev.off()

# p1<-plot_cells(Micro_Sub,target="condition",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
# p2<-plot_cells(Micro_Sub,target="Cluster",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")
# p3<-plot_cells(Micro_Sub,target="Cell_Type",leg_pos="right",save=TRUE,ncol=1,reduction="tsne")

# pdf(paste(Sys.Date(),project,"tsne.pdf",sep="_"),width=16,height=8)
# print(plot_grid(p1, p2,p3,ncol = 3))
# dev.off()




# plot_cells(Micro_Sub,target="Cluster")
# dir.create("DF_Clusters")
# setwd("DF_Clusters")



# # =============================== PAIRWISE DF ===============================================
# dir.create("DF_Pairwise")
# setwd("DF_Pairwise")
# Idents(Micro_Sub) <- Micro_Sub$Cluster
# cl_combinations <- combn(levels(Micro_Sub$Cluster),2)

# for(comb in 1:dim(cl_combinations)[2]){
#     idents <- as.numeric(cl_combinations[,comb])
#     ident.1 <- idents[1]
#     ident.2 <- idents[2]
#     DefaultAssay(Micro_Sub) <- "RNA"
#     Micro_Sub <- ScaleData(Micro_Sub)
#     pbmc.markers <- FindMarkers(object = Micro_Sub,ident.1=ident.1,ident.2=ident.2,
#                                            assay ="RNA",
#                                            logfc.threshold=0,
#                                            only.pos = TRUE,
#                                            test.use = "MAST",latent.vars = c("nCount_RNA"))
#     pbmc.markers$gene <- rownames(pbmc.markers)
#     top10 <- pbmc.markers %>% top_n(n = 50, wt = abs(avg_logFC))
#     top10_genes<- top10$gene
#     temp <- Micro_Sub[,Micro_Sub$Cluster%in%c(ident.1,ident.2)]
#     temp$Cluster <- as.factor(as.vector(temp$Cluster))
#     # debugonce(annotated_heat)
#     annotated_heat(object=temp,
#                       row_annotation=c(1),
#                       gene_list=top10_genes,
#                       gene_list_name="DF_genes",
#                       title=paste(cl_combinations[,comb],collapse = "_"),
#                       ordering="Cluster")

#     DefaultAssay(Micro_Sub) <- "integrated"

#     pbmc.markers[c("LGMN","MARCKS","P2RY12","FCRLS","CSF1R","SERINC3"),]
# }




# Homeostatic <- c(grep("FCRLS",return_fun$degs$gene),
# grep("LGMN",return_fun$degs$gene),
# grep("MARCKS",return_fun$degs$gene),
# grep("CSF1R",return_fun$degs$gene),
# grep("P2RY12",return_fun$degs$gene),
# grep("SERINC3",return_fun$degs$gene))

# return_fun$degs[Homeostatic,]
# # ----------------------------------------------------------------------------------------------




micro_mat  <- as.matrix(Micro_Sub2@assays$RNA@counts)
micro_cl <- Micro_Sub2$Cluster
object <- seurat_to_monocle(Micro_Sub2)


all_diff_test_res_condition <- differentialGeneTest(object, fullModelFormulaStr=paste("~",target,sep=""),cores=n_cores, reducedModelFormulaStr ="~num_genes_expressed")
# == Reduce Matrix (remove not significant genes)
signif_genes <-all_diff_test_res_condition
monocle_helper <- df_genes_logfc(object,target,signif_genes=signif_genes,top_n=15,qval_thres=0.05,fc_thres=logfc.threshold,each_cl=TRUE,n_cores=4)
pbmc.markers <- monocle_helper$df_pval_genes
colnames(pbmc.markers)[colnames(pbmc.markers)=="gene_short_name"] <- "gene"
top10_genes <- monocle_helper$sig_genes