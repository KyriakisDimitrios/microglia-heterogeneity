library(ICSWrapper)
library(scater)
library(sctransform)
library(Seurat)
library(scran)
set.seed(123)
tool="seurat"
project ="Michi_Data"
dataset <- project
Data_select <- data_selection(project)

WORKDIR <- Data_select$WORKDIR
list_of_files <- Data_select$list_of_files
condition_names <- Data_select$condition_names
organism<- Data_select$organism
file<- Data_select$file
data_10x<- Data_select$data_10x

setwd(Data_select$WORKDIR)



colormap_d<- c('#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6','#6a3d9a','#ffff99','#b15928',"black","gray")
color_cond  <- c(brewer.pal(8,"Dark2"),"black","gray","magenta4","seagreen4")
color_cond  <- c(brewer.pal(5,"Set1"),"black","gray","magenta4","seagreen4",brewer.pal(8,"Dark2"))
color_clust <- c(brewer.pal(12,"Paired")[-11],"black","gray","magenta4","seagreen4",brewer.pal(9,"Set1"))
color_clust <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")
color_cells <- c(brewer.pal(9,"Set1")[-6],"goldenrod4","darkblue","seagreen4")
color_list <- list(condition=color_cond,Cluster=color_clust,Cell_Type=color_cells,State=color_clust)
# color_cells <-primary.colors(15, steps = 3, no.white = TRUE)



# ================================ SETTING UP ======================================== #
# Number of cells to use
imputation = FALSE
remove_mt=TRUE
remove_ribsomal=TRUE
n_cores=5
elbow = TRUE


# setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-20_seurat_elbow_FALSE")
# Combined <- readRDS("Cell_Types_2019-11-20_seurat_elbow_FALSE.rds")

NewDir <- paste0(Sys.Date(),"_",tool,"_elbow_",elbow,"_remove_ribsomal_",remove_ribsomal)

dir.create(NewDir)
setwd(NewDir)


# setwd("C:/Users/dimitrios.kyriakis/Desktop/PhD/Projects/MBSYN/2019-11-13_seurat_elbow_FALSE_SAVER")

# ==============================================================================================
# ================================ Setup the Seurat objects ====================================
# ==============================================================================================
# ======== Perform an integrated analysis ====
dir.create("QC")
setwd("QC")
# debugonce(load_files)
Return_fun <- create_cds(list_of_files=list_of_files,
                         condition_names=condition_names,
                         min.features =200,min.cells=5,remove_mt=TRUE,data_10x=data_10x, elbow = elbow,tool=tool,imputation=imputation)

Combined  <- Return_fun$Combined
Data_List <- Return_fun$Data_List
setwd("../")

# ----------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------

saveRDS(Combined,paste0("Merged_",NewDir,".rds"))



# ======================================= Clustering  ==========================================
# ==============================================================================================
dir.create("Clustering")
setwd("Clustering")
# Combined <- ReduceDim(Combined,method="umap",project=project)$Combined
# debugonce(reduce_dim)
Combined <- reduce_dim(Combined,project=project)$Combined

pdf(paste(Sys.Date(),project,"tsne","Conditions.pdf",sep="_"))
plot_cells(Combined,target="condition",leg_pos="right",save=TRUE,ncol=1)
dev.off()
pdf(paste(Sys.Date(),project,"tsne","Cluster.pdf",sep="_"))
# debugonce(plot_cells)
plot_cells(Combined,target="Cluster",leg_pos="right",save=TRUE,ncol=1)
dev.off()


plot_nFeatures(Combined,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)
plot_tot_mRNA(Combined,title="",save=TRUE,tiff=FALSE,reduce="t-SNE",p3D=FALSE)


if(tolower(tool)=="seurat" & elbow){
    p3 <- DimPlot(object = Combined, reduction = "umap", group.by = "condition",cols = color_cond)
    p4 <- DimPlot(object = Combined, reduction = "umap", label = TRUE,cols = color_clust)
    pdf(paste(Sys.Date(),project,"umap","Seurat_Conditions.pdf",sep="_"))
    print(p3)
    dev.off()
    pdf(paste(Sys.Date(),project,"umap","Seurat_Clusters.pdf",sep="_"))
    print(p4)
    dev.off()
}

# ------------------------------------------------------------------------------------------------

setwd("../")
saveRDS(Combined,paste0("Clustered_",NewDir,".rds"))


# =================================== DF Conditions =================================================
dir.create("DF_Conditions")
setwd("DF_Conditions")
# debugonce(df_genes)
return_fun <- df_genes(Combined,"condition",top_n=15,logfc.threshold=0, n_cores=4,only.pos =TRUE)

setwd("../")
# ------------------------------------------------------------------------------------------------



# =============================== PAIRWISE DF ===============================================
# =============================== PAIRWISE DF ===============================================
dir.create("DF_Pairwise")
setwd("DF_Pairwise")
Idents(Combined) <- Combined$condition
cl_combinations <- combn(levels(Combined$condition),2)


pairwise_df <- function (comb){
	target <- "condition"
    idents <- as.vector(cl_combinations[,comb])
    ident.1 <- idents[1]
    print(ident.1)
    
    ident.2 <- idents[2]
    DefaultAssay(Combined) <- "RNA"
    Combined <- ScaleData(Combined)
    pbmc.markers <- FindMarkers(object = Combined,ident.1=ident.1,ident.2=ident.2,
                                           assay ="RNA",
                                           logfc.threshold=0,
                                           only.pos = FALSE,
                                           test.use = "MAST",latent.vars = c("nCount_RNA"))
    pbmc.markers$gene <- rownames(pbmc.markers)
    top10 <- pbmc.markers %>% top_n(n = 50, wt = abs(avg_logFC))
    top10_genes<- unique(top10$gene)
    temp <- Combined[,Combined$condition%in%c(ident.1,ident.2)]
    temp$condition <- as.factor(as.vector(temp$condition))
    # debugonce(annotated_heat)
    title <- paste(cl_combinations[,comb],collapse = "_")
    annotated_heat(object=temp,
                      row_annotation=c(1),
                      gene_list=top10_genes,
                      gene_list_name="DF_genes",
                      title=title,
                      ordering="condition")

    DefaultAssay(Combined) <- "integrated"
    write.table(pbmc.markers, file = paste0(Sys.Date(),"_TO_EXP_each_",target,"_",title,".tsv"),row.names=FALSE, na="", sep="\t")
}

mclapply(c(1:dim(cl_combinations)[2]),pairwise_df,mc.cores=4)


# for(comb in 1:dim(cl_combinations)[2]){
#     idents <- as.vector(cl_combinations[,comb])
#     ident.1 <- idents[1]
#     ident.2 <- idents[2]
#     DefaultAssay(Combined) <- "RNA"
#     Combined <- ScaleData(Combined)
#     pbmc.markers <- FindMarkers(object = Combined,ident.1=ident.1,ident.2=ident.2,
#                                            assay ="RNA",
#                                            logfc.threshold=0,
#                                            only.pos = FALSE,
#                                            test.use = "MAST",latent.vars = c("nCount_RNA"))
#     pbmc.markers$gene <- rownames(pbmc.markers)
#     top10 <- pbmc.markers %>% top_n(n = 50, wt = abs(avg_logFC))
#     top10_genes<- unique(top10$gene)
#     temp <- Combined[,Combined$condition%in%c(ident.1,ident.2)]
#     temp$condition <- as.factor(as.vector(temp$condition))
#     # debugonce(annotated_heat)
#     title <- paste(cl_combinations[,comb],collapse = "_")
#     annotated_heat(object=temp,
#                       row_annotation=c(1),
#                       gene_list=top10_genes,
#                       gene_list_name="DF_genes",
#                       title=title,
#                       ordering="condition")

#     DefaultAssay(Combined) <- "integrated"
#     write.table(pbmc.markers, file = paste0(Sys.Date(),"_TO_EXP_each_",target,"_",title,".tsv"),row.names=FALSE, na="", sep="\t")

# }


# signif_markers <- pbmc.markers[pbmc.markers$p_val_adj<0.01,]
# signif_markers[order(abs(signif_markers$avg_logFC)),]


setwd("../")
# ----------------------------------------------------------------------------------------------


